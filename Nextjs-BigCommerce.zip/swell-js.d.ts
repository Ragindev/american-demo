declare module 'swell-js'
