export { default } from './Head'
