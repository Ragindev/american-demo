export { default } from './PaymentWidget'
