exports.id = "components_auth_SignUpView_tsx";
exports.ids = ["components_auth_SignUpView_tsx"];
exports.modules = {

/***/ "./components/auth/SignUpView.tsx":
/*!****************************************!*\
  !*** ./components/auth/SignUpView.tsx ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! email-validator */ "email-validator");
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(email_validator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @components/icons */ "./components/icons/index.ts");
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/ui/context */ "./components/ui/context.tsx");
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/ui */ "./components/ui/index.ts");
/* harmony import */ var _framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @framework/auth/use-signup */ "./framework/bigcommerce/auth/use-signup.tsx");

var _jsxFileName = "D:\\RAGIN\\AT\\Nextjs-BigCommerce\\components\\auth\\SignUpView.tsx";







const SignUpView = () => {
  // Form State
  const {
    0: email,
    1: setEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: password,
    1: setPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: firstName,
    1: setFirstName
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: lastName,
    1: setLastName
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: message,
    1: setMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: dirty,
    1: setDirty
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: disabled,
    1: setDisabled
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const signup = (0,_framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_3__.default)();
  const {
    setModalView,
    closeModal
  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_4__.useUI)();

  const handleSignup = async e => {
    e.preventDefault();

    if (!dirty && !disabled) {
      setDirty(true);
      handleValidation();
    }

    try {
      setLoading(true);
      setMessage('');
      await signup({
        email,
        firstName,
        lastName,
        password
      });
      setLoading(false);
      closeModal();
    } catch ({
      errors
    }) {
      setMessage(errors[0].message);
      setLoading(false);
    }
  };

  const handleValidation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
    // Test for Alphanumeric password
    const validPassword = /^(?=.*[a-zA-Z])(?=.*[0-9])/.test(password); // Unable to send form unless fields are valid.

    if (dirty) {
      setDisabled(!(0,email_validator__WEBPACK_IMPORTED_MODULE_2__.validate)(email) || password.length < 7 || !validPassword);
    }
  }, [email, password, dirty]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    handleValidation();
  }, [handleValidation]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("form", {
    onSubmit: handleSignup,
    className: "w-80 flex flex-col justify-between p-3",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex justify-center pb-12 ",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Logo, {
        width: "64px",
        height: "64px"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 68,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex flex-col space-y-4",
      children: [message && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-red border border-red p-3",
        children: message
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Input, {
        placeholder: "First Name",
        onChange: setFirstName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Input, {
        placeholder: "Last Name",
        onChange: setLastName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Input, {
        type: "email",
        placeholder: "Email",
        onChange: setEmail
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Input, {
        type: "password",
        placeholder: "Password",
        onChange: setPassword
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "text-accent-8",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
          className: "inline-block align-middle ",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_icons__WEBPACK_IMPORTED_MODULE_6__.Info, {
            width: "15",
            height: "15"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, undefined), ' ', /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
          className: "leading-6 text-sm",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("strong", {
            children: "Info"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, undefined), ": Passwords must be longer than 7 chars and include numbers.", ' ']
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 83,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "pt-2 w-full flex flex-col",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_5__.Button, {
          variant: "slim",
          type: "submit",
          loading: loading,
          disabled: disabled,
          children: "Sign Up"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 88,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "pt-1 text-center text-sm",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
          className: "text-accent-7",
          children: "Do you have an account?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 11
        }, undefined), ` `, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: "text-accent-9 font-bold hover:underline cursor-pointer",
          onClick: () => setModalView('LOGIN_VIEW'),
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 102,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 64,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SignUpView);

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9jb21wb25lbnRzL2F1dGgvU2lnblVwVmlldy50c3giXSwibmFtZXMiOlsiU2lnblVwVmlldyIsImVtYWlsIiwic2V0RW1haWwiLCJ1c2VTdGF0ZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJmaXJzdE5hbWUiLCJzZXRGaXJzdE5hbWUiLCJsYXN0TmFtZSIsInNldExhc3ROYW1lIiwibG9hZGluZyIsInNldExvYWRpbmciLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsImRpcnR5Iiwic2V0RGlydHkiLCJkaXNhYmxlZCIsInNldERpc2FibGVkIiwic2lnbnVwIiwidXNlU2lnbnVwIiwic2V0TW9kYWxWaWV3IiwiY2xvc2VNb2RhbCIsInVzZVVJIiwiaGFuZGxlU2lnbnVwIiwiZSIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlVmFsaWRhdGlvbiIsImVycm9ycyIsInVzZUNhbGxiYWNrIiwidmFsaWRQYXNzd29yZCIsInRlc3QiLCJ2YWxpZGF0ZSIsImxlbmd0aCIsInVzZUVmZmVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBLE1BQU1BLFVBQXFCLEdBQUcsTUFBTTtBQUNsQztBQUNBLFFBQU07QUFBQSxPQUFDQyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQkMsK0NBQVEsQ0FBQyxFQUFELENBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCRiwrQ0FBUSxDQUFDLEVBQUQsQ0FBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0csU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJKLCtDQUFRLENBQUMsRUFBRCxDQUExQztBQUNBLFFBQU07QUFBQSxPQUFDSyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQk4sK0NBQVEsQ0FBQyxFQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNPLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCUiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQ1MsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0JWLCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDVyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQlosK0NBQVEsQ0FBQyxLQUFELENBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUNhLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCZCwrQ0FBUSxDQUFDLEtBQUQsQ0FBeEM7QUFFQSxRQUFNZSxNQUFNLEdBQUdDLG1FQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFFQyxnQkFBRjtBQUFnQkM7QUFBaEIsTUFBK0JDLDZEQUFLLEVBQTFDOztBQUVBLFFBQU1DLFlBQVksR0FBRyxNQUFPQyxDQUFQLElBQWdEO0FBQ25FQSxLQUFDLENBQUNDLGNBQUY7O0FBRUEsUUFBSSxDQUFDWCxLQUFELElBQVUsQ0FBQ0UsUUFBZixFQUF5QjtBQUN2QkQsY0FBUSxDQUFDLElBQUQsQ0FBUjtBQUNBVyxzQkFBZ0I7QUFDakI7O0FBRUQsUUFBSTtBQUNGZixnQkFBVSxDQUFDLElBQUQsQ0FBVjtBQUNBRSxnQkFBVSxDQUFDLEVBQUQsQ0FBVjtBQUNBLFlBQU1LLE1BQU0sQ0FBQztBQUNYakIsYUFEVztBQUVYSyxpQkFGVztBQUdYRSxnQkFIVztBQUlYSjtBQUpXLE9BQUQsQ0FBWjtBQU1BTyxnQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNBVSxnQkFBVTtBQUNYLEtBWEQsQ0FXRSxPQUFPO0FBQUVNO0FBQUYsS0FBUCxFQUFtQjtBQUNuQmQsZ0JBQVUsQ0FBQ2MsTUFBTSxDQUFDLENBQUQsQ0FBTixDQUFVZixPQUFYLENBQVY7QUFDQUQsZ0JBQVUsQ0FBQyxLQUFELENBQVY7QUFDRDtBQUNGLEdBdkJEOztBQXlCQSxRQUFNZSxnQkFBZ0IsR0FBR0Usa0RBQVcsQ0FBQyxNQUFNO0FBQ3pDO0FBQ0EsVUFBTUMsYUFBYSxHQUFHLDZCQUE2QkMsSUFBN0IsQ0FBa0MxQixRQUFsQyxDQUF0QixDQUZ5QyxDQUl6Qzs7QUFDQSxRQUFJVSxLQUFKLEVBQVc7QUFDVEcsaUJBQVcsQ0FBQyxDQUFDYyx5REFBUSxDQUFDOUIsS0FBRCxDQUFULElBQW9CRyxRQUFRLENBQUM0QixNQUFULEdBQWtCLENBQXRDLElBQTJDLENBQUNILGFBQTdDLENBQVg7QUFDRDtBQUNGLEdBUm1DLEVBUWpDLENBQUM1QixLQUFELEVBQVFHLFFBQVIsRUFBa0JVLEtBQWxCLENBUmlDLENBQXBDO0FBVUFtQixrREFBUyxDQUFDLE1BQU07QUFDZFAsb0JBQWdCO0FBQ2pCLEdBRlEsRUFFTixDQUFDQSxnQkFBRCxDQUZNLENBQVQ7QUFJQSxzQkFDRTtBQUNFLFlBQVEsRUFBRUgsWUFEWjtBQUVFLGFBQVMsRUFBQyx3Q0FGWjtBQUFBLDRCQUlFO0FBQUssZUFBUyxFQUFDLDRCQUFmO0FBQUEsNkJBQ0UsOERBQUMsZ0RBQUQ7QUFBTSxhQUFLLEVBQUMsTUFBWjtBQUFtQixjQUFNLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkYsZUFPRTtBQUFLLGVBQVMsRUFBQyx5QkFBZjtBQUFBLGlCQUNHWCxPQUFPLGlCQUNOO0FBQUssaUJBQVMsRUFBQyxnQ0FBZjtBQUFBLGtCQUFpREE7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUlFLDhEQUFDLGlEQUFEO0FBQU8sbUJBQVcsRUFBQyxZQUFuQjtBQUFnQyxnQkFBUSxFQUFFTDtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBS0UsOERBQUMsaURBQUQ7QUFBTyxtQkFBVyxFQUFDLFdBQW5CO0FBQStCLGdCQUFRLEVBQUVFO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFNRSw4REFBQyxpREFBRDtBQUFPLFlBQUksRUFBQyxPQUFaO0FBQW9CLG1CQUFXLEVBQUMsT0FBaEM7QUFBd0MsZ0JBQVEsRUFBRVA7QUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORixlQU9FLDhEQUFDLGlEQUFEO0FBQU8sWUFBSSxFQUFDLFVBQVo7QUFBdUIsbUJBQVcsRUFBQyxVQUFuQztBQUE4QyxnQkFBUSxFQUFFRztBQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGLGVBUUU7QUFBTSxpQkFBUyxFQUFDLGVBQWhCO0FBQUEsZ0NBQ0U7QUFBTSxtQkFBUyxFQUFDLDRCQUFoQjtBQUFBLGlDQUNFLDhEQUFDLG1EQUFEO0FBQU0saUJBQUssRUFBQyxJQUFaO0FBQWlCLGtCQUFNLEVBQUM7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsRUFHVSxHQUhWLGVBSUU7QUFBTSxtQkFBUyxFQUFDLG1CQUFoQjtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGtFQUVtQixHQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBaUJFO0FBQUssaUJBQVMsRUFBQywyQkFBZjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQ0UsaUJBQU8sRUFBQyxNQURWO0FBRUUsY0FBSSxFQUFDLFFBRlA7QUFHRSxpQkFBTyxFQUFFSyxPQUhYO0FBSUUsa0JBQVEsRUFBRU0sUUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGLGVBNEJFO0FBQU0saUJBQVMsRUFBQywwQkFBaEI7QUFBQSxnQ0FDRTtBQUFNLG1CQUFTLEVBQUMsZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsRUFFSSxHQUZKLGVBR0U7QUFDRSxtQkFBUyxFQUFDLHdEQURaO0FBRUUsaUJBQU8sRUFBRSxNQUFNSSxZQUFZLENBQUMsWUFBRCxDQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWlERCxDQXRHRDs7QUF3R0EsK0RBQWVwQixVQUFmLEUiLCJmaWxlIjoiY29tcG9uZW50c19hdXRoX1NpZ25VcFZpZXdfdHN4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHZhbGlkYXRlIH0gZnJvbSAnZW1haWwtdmFsaWRhdG9yJ1xyXG5pbXBvcnQgeyBJbmZvIH0gZnJvbSAnQGNvbXBvbmVudHMvaWNvbnMnXHJcbmltcG9ydCB7IHVzZVVJIH0gZnJvbSAnQGNvbXBvbmVudHMvdWkvY29udGV4dCdcclxuaW1wb3J0IHsgTG9nbywgQnV0dG9uLCBJbnB1dCB9IGZyb20gJ0Bjb21wb25lbnRzL3VpJ1xyXG5pbXBvcnQgdXNlU2lnbnVwIGZyb20gJ0BmcmFtZXdvcmsvYXV0aC91c2Utc2lnbnVwJ1xyXG5cclxuaW50ZXJmYWNlIFByb3BzIHt9XHJcblxyXG5jb25zdCBTaWduVXBWaWV3OiBGQzxQcm9wcz4gPSAoKSA9PiB7XHJcbiAgLy8gRm9ybSBTdGF0ZVxyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZmlyc3ROYW1lLCBzZXRGaXJzdE5hbWVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2xhc3ROYW1lLCBzZXRMYXN0TmFtZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZGlydHksIHNldERpcnR5XSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtkaXNhYmxlZCwgc2V0RGlzYWJsZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IHNpZ251cCA9IHVzZVNpZ251cCgpXHJcbiAgY29uc3QgeyBzZXRNb2RhbFZpZXcsIGNsb3NlTW9kYWwgfSA9IHVzZVVJKClcclxuXHJcbiAgY29uc3QgaGFuZGxlU2lnbnVwID0gYXN5bmMgKGU6IFJlYWN0LlN5bnRoZXRpY0V2ZW50PEV2ZW50VGFyZ2V0PikgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXHJcblxyXG4gICAgaWYgKCFkaXJ0eSAmJiAhZGlzYWJsZWQpIHtcclxuICAgICAgc2V0RGlydHkodHJ1ZSlcclxuICAgICAgaGFuZGxlVmFsaWRhdGlvbigpXHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgICBzZXRNZXNzYWdlKCcnKVxyXG4gICAgICBhd2FpdCBzaWdudXAoe1xyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIGZpcnN0TmFtZSxcclxuICAgICAgICBsYXN0TmFtZSxcclxuICAgICAgICBwYXNzd29yZCxcclxuICAgICAgfSlcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgICAgY2xvc2VNb2RhbCgpXHJcbiAgICB9IGNhdGNoICh7IGVycm9ycyB9KSB7XHJcbiAgICAgIHNldE1lc3NhZ2UoZXJyb3JzWzBdLm1lc3NhZ2UpXHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVWYWxpZGF0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgLy8gVGVzdCBmb3IgQWxwaGFudW1lcmljIHBhc3N3b3JkXHJcbiAgICBjb25zdCB2YWxpZFBhc3N3b3JkID0gL14oPz0uKlthLXpBLVpdKSg/PS4qWzAtOV0pLy50ZXN0KHBhc3N3b3JkKVxyXG5cclxuICAgIC8vIFVuYWJsZSB0byBzZW5kIGZvcm0gdW5sZXNzIGZpZWxkcyBhcmUgdmFsaWQuXHJcbiAgICBpZiAoZGlydHkpIHtcclxuICAgICAgc2V0RGlzYWJsZWQoIXZhbGlkYXRlKGVtYWlsKSB8fCBwYXNzd29yZC5sZW5ndGggPCA3IHx8ICF2YWxpZFBhc3N3b3JkKVxyXG4gICAgfVxyXG4gIH0sIFtlbWFpbCwgcGFzc3dvcmQsIGRpcnR5XSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGhhbmRsZVZhbGlkYXRpb24oKVxyXG4gIH0sIFtoYW5kbGVWYWxpZGF0aW9uXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtXHJcbiAgICAgIG9uU3VibWl0PXtoYW5kbGVTaWdudXB9XHJcbiAgICAgIGNsYXNzTmFtZT1cInctODAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcC0zXCJcclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHBiLTEyIFwiPlxyXG4gICAgICAgIDxMb2dvIHdpZHRoPVwiNjRweFwiIGhlaWdodD1cIjY0cHhcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIHttZXNzYWdlICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQgYm9yZGVyIGJvcmRlci1yZWQgcC0zXCI+e21lc3NhZ2V9PC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJGaXJzdCBOYW1lXCIgb25DaGFuZ2U9e3NldEZpcnN0TmFtZX0gLz5cclxuICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJMYXN0IE5hbWVcIiBvbkNoYW5nZT17c2V0TGFzdE5hbWV9IC8+XHJcbiAgICAgICAgPElucHV0IHR5cGU9XCJlbWFpbFwiIHBsYWNlaG9sZGVyPVwiRW1haWxcIiBvbkNoYW5nZT17c2V0RW1haWx9IC8+XHJcbiAgICAgICAgPElucHV0IHR5cGU9XCJwYXNzd29yZFwiIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIiBvbkNoYW5nZT17c2V0UGFzc3dvcmR9IC8+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtOFwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIGFsaWduLW1pZGRsZSBcIj5cclxuICAgICAgICAgICAgPEluZm8gd2lkdGg9XCIxNVwiIGhlaWdodD1cIjE1XCIgLz5cclxuICAgICAgICAgIDwvc3Bhbj57JyAnfVxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVhZGluZy02IHRleHQtc21cIj5cclxuICAgICAgICAgICAgPHN0cm9uZz5JbmZvPC9zdHJvbmc+OiBQYXNzd29yZHMgbXVzdCBiZSBsb25nZXIgdGhhbiA3IGNoYXJzIGFuZFxyXG4gICAgICAgICAgICBpbmNsdWRlIG51bWJlcnMueycgJ31cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIHctZnVsbCBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzbGltXCJcclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgU2lnbiBVcFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB0LTEgdGV4dC1jZW50ZXIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtN1wiPkRvIHlvdSBoYXZlIGFuIGFjY291bnQ/PC9zcGFuPlxyXG4gICAgICAgICAge2AgYH1cclxuICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYWNjZW50LTkgZm9udC1ib2xkIGhvdmVyOnVuZGVybGluZSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsVmlldygnTE9HSU5fVklFVycpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBMb2cgSW5cclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2lnblVwVmlld1xyXG4iXSwic291cmNlUm9vdCI6IiJ9