(function() {
var exports = {};
exports.id = "pages/api/cart";
exports.ids = ["pages/api/cart"];
exports.modules = {

/***/ "./framework/bigcommerce/api/endpoints/cart/add-item.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/cart/add-item.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
/* harmony import */ var _utils_parse_item__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/parse-item */ "./framework/bigcommerce/api/utils/parse-item.ts");
/* harmony import */ var _utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/get-cart-cookie */ "./framework/bigcommerce/api/utils/get-cart-cookie.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const addItem = async ({
  res,
  body: {
    cartId,
    item
  },
  config
}) => {
  if (!item) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Missing item'
      }]
    });
  }

  if (!item.quantity) item.quantity = 1;
  const options = {
    method: 'POST',
    body: JSON.stringify(_objectSpread({
      line_items: [(0,_utils_parse_item__WEBPACK_IMPORTED_MODULE_0__.parseCartItem)(item)]
    }, !cartId && config.storeChannelId ? {
      channel_id: config.storeChannelId
    } : {}))
  };
  const {
    data
  } = cartId ? await config.storeApiFetch(`/v3/carts/${cartId}/items?include=line_items.physical_items.options`, options) : await config.storeApiFetch('/v3/carts?include=line_items.physical_items.options', options); // Create or update the cart cookie

  res.setHeader('Set-Cookie', (0,_utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__.default)(config.cartCookie, data.id, config.cartCookieMaxAge));
  res.status(200).json({
    data: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_2__.normalizeCart)(data)
  });
};

/* harmony default export */ __webpack_exports__["default"] = (addItem);

/***/ }),

/***/ "./framework/bigcommerce/api/endpoints/cart/get-cart.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/cart/get-cart.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
/* harmony import */ var _utils_errors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/errors */ "./framework/bigcommerce/api/utils/errors.ts");
/* harmony import */ var _utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/get-cart-cookie */ "./framework/bigcommerce/api/utils/get-cart-cookie.ts");




// Return current cart info
const getCart = async ({
  res,
  body: {
    cartId
  },
  config
}) => {
  let result = {};

  if (cartId) {
    try {
      result = await config.storeApiFetch(`/v3/carts/${cartId}?include=line_items.physical_items.options`);
    } catch (error) {
      if (error instanceof _utils_errors__WEBPACK_IMPORTED_MODULE_0__.BigcommerceApiError && error.status === 404) {
        // Remove the cookie if it exists but the cart wasn't found
        res.setHeader('Set-Cookie', (0,_utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__.default)(config.cartCookie));
      } else {
        throw error;
      }
    }
  }

  res.status(200).json({
    data: result.data ? (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_2__.normalizeCart)(result.data) : null
  });
};

/* harmony default export */ __webpack_exports__["default"] = (getCart);

/***/ }),

/***/ "./framework/bigcommerce/api/endpoints/cart/index.ts":
/*!***********************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/cart/index.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "handlers": function() { return /* binding */ handlers; }
/* harmony export */ });
/* harmony import */ var _commerce_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @commerce/api */ "./framework/commerce/api/index.ts");
/* harmony import */ var _commerce_api_endpoints_cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @commerce/api/endpoints/cart */ "./framework/commerce/api/endpoints/cart.ts");
/* harmony import */ var _get_cart__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-cart */ "./framework/bigcommerce/api/endpoints/cart/get-cart.ts");
/* harmony import */ var _add_item__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-item */ "./framework/bigcommerce/api/endpoints/cart/add-item.ts");
/* harmony import */ var _update_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./update-item */ "./framework/bigcommerce/api/endpoints/cart/update-item.ts");
/* harmony import */ var _remove_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./remove-item */ "./framework/bigcommerce/api/endpoints/cart/remove-item.ts");






const handlers = {
  getCart: _get_cart__WEBPACK_IMPORTED_MODULE_0__.default,
  addItem: _add_item__WEBPACK_IMPORTED_MODULE_1__.default,
  updateItem: _update_item__WEBPACK_IMPORTED_MODULE_2__.default,
  removeItem: _remove_item__WEBPACK_IMPORTED_MODULE_3__.default
};
const cartApi = (0,_commerce_api__WEBPACK_IMPORTED_MODULE_4__.createEndpoint)({
  handler: _commerce_api_endpoints_cart__WEBPACK_IMPORTED_MODULE_5__.default,
  handlers
});
/* harmony default export */ __webpack_exports__["default"] = (cartApi);

/***/ }),

/***/ "./framework/bigcommerce/api/endpoints/cart/remove-item.ts":
/*!*****************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/cart/remove-item.ts ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
/* harmony import */ var _utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/get-cart-cookie */ "./framework/bigcommerce/api/utils/get-cart-cookie.ts");



const removeItem = async ({
  res,
  body: {
    cartId,
    itemId
  },
  config
}) => {
  var _result$data;

  if (!cartId || !itemId) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const result = await config.storeApiFetch(`/v3/carts/${cartId}/items/${itemId}?include=line_items.physical_items.options`, {
    method: 'DELETE'
  });
  const data = (_result$data = result === null || result === void 0 ? void 0 : result.data) !== null && _result$data !== void 0 ? _result$data : null;
  res.setHeader('Set-Cookie', data ? // Update the cart cookie
  (0,_utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_0__.default)(config.cartCookie, cartId, config.cartCookieMaxAge) : // Remove the cart cookie if the cart was removed (empty items)
  (0,_utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_0__.default)(config.cartCookie));
  res.status(200).json({
    data: data && (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_1__.normalizeCart)(data)
  });
};

/* harmony default export */ __webpack_exports__["default"] = (removeItem);

/***/ }),

/***/ "./framework/bigcommerce/api/endpoints/cart/update-item.ts":
/*!*****************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/cart/update-item.ts ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
/* harmony import */ var _utils_parse_item__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/parse-item */ "./framework/bigcommerce/api/utils/parse-item.ts");
/* harmony import */ var _utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/get-cart-cookie */ "./framework/bigcommerce/api/utils/get-cart-cookie.ts");




const updateItem = async ({
  res,
  body: {
    cartId,
    itemId,
    item
  },
  config
}) => {
  if (!cartId || !itemId || !item) {
    return res.status(400).json({
      data: null,
      errors: [{
        message: 'Invalid request'
      }]
    });
  }

  const {
    data
  } = await config.storeApiFetch(`/v3/carts/${cartId}/items/${itemId}?include=line_items.physical_items.options`, {
    method: 'PUT',
    body: JSON.stringify({
      line_item: (0,_utils_parse_item__WEBPACK_IMPORTED_MODULE_0__.parseCartItem)(item)
    })
  }); // Update the cart cookie

  res.setHeader('Set-Cookie', (0,_utils_get_cart_cookie__WEBPACK_IMPORTED_MODULE_1__.default)(config.cartCookie, cartId, config.cartCookieMaxAge));
  res.status(200).json({
    data: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_2__.normalizeCart)(data)
  });
};

/* harmony default export */ __webpack_exports__["default"] = (updateItem);

/***/ }),

/***/ "./framework/bigcommerce/api/fragments/category-tree.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/fragments/category-tree.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "categoryTreeItemFragment": function() { return /* binding */ categoryTreeItemFragment; }
/* harmony export */ });
const categoryTreeItemFragment =
/* GraphQL */
`
  fragment categoryTreeItem on CategoryTreeItem {
    entityId
    name
    path
    description
    productCount
  }
`;

/***/ }),

/***/ "./framework/bigcommerce/api/fragments/product.ts":
/*!********************************************************!*\
  !*** ./framework/bigcommerce/api/fragments/product.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "productPrices": function() { return /* binding */ productPrices; },
/* harmony export */   "swatchOptionFragment": function() { return /* binding */ swatchOptionFragment; },
/* harmony export */   "multipleChoiceOptionFragment": function() { return /* binding */ multipleChoiceOptionFragment; },
/* harmony export */   "productInfoFragment": function() { return /* binding */ productInfoFragment; },
/* harmony export */   "productConnectionFragment": function() { return /* binding */ productConnectionFragment; }
/* harmony export */ });
const productPrices =
/* GraphQL */
`
  fragment productPrices on Prices {
    price {
      value
      currencyCode
    }
    salePrice {
      value
      currencyCode
    }
    retailPrice {
      value
      currencyCode
    }
  }
`;
const swatchOptionFragment =
/* GraphQL */
`
  fragment swatchOption on SwatchOptionValue {
    isDefault
    hexColors
  }
`;
const multipleChoiceOptionFragment =
/* GraphQL */
`
  fragment multipleChoiceOption on MultipleChoiceOption {
    values {
      edges {
        node {
          label
          ...swatchOption
        }
      }
    }
  }

  ${swatchOptionFragment}
`;
const productInfoFragment =
/* GraphQL */
`
  fragment productInfo on Product {
    entityId
    name
    path
    brand {
      entityId
    }
    description
    prices {
      ...productPrices
    }
    images {
      edges {
        node {
          urlOriginal
          altText
          isDefault
        }
      }
    }
    variants {
      edges {
        node {
          entityId
          defaultImage {
            urlOriginal
            altText
            isDefault
          }
        }
      }
    }
    productOptions {
      edges {
        node {
          __typename
          entityId
          displayName
          ...multipleChoiceOption
        }
      }
    }
    localeMeta: metafields(namespace: $locale, keys: ["name", "description"])
      @include(if: $hasLocale) {
      edges {
        node {
          key
          value
        }
      }
    }
  }

  ${productPrices}
  ${multipleChoiceOptionFragment}
`;
const productConnectionFragment =
/* GraphQL */
`
  fragment productConnnection on ProductConnection {
    pageInfo {
      startCursor
      endCursor
    }
    edges {
      cursor
      node {
        ...productInfo
      }
    }
  }

  ${productInfoFragment}
`;

/***/ }),

/***/ "./framework/bigcommerce/api/index.ts":
/*!********************************************!*\
  !*** ./framework/bigcommerce/api/index.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "provider": function() { return /* binding */ provider; },
/* harmony export */   "getCommerceApi": function() { return /* binding */ getCommerceApi; }
/* harmony export */ });
/* harmony import */ var _commerce_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @commerce/api */ "./framework/commerce/api/index.ts");
/* harmony import */ var _utils_fetch_graphql_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/fetch-graphql-api */ "./framework/bigcommerce/api/utils/fetch-graphql-api.ts");
/* harmony import */ var _utils_fetch_store_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/fetch-store-api */ "./framework/bigcommerce/api/utils/fetch-store-api.ts");
/* harmony import */ var _operations_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./operations/login */ "./framework/bigcommerce/api/operations/login.ts");
/* harmony import */ var _operations_get_all_pages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./operations/get-all-pages */ "./framework/bigcommerce/api/operations/get-all-pages.ts");
/* harmony import */ var _operations_get_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./operations/get-page */ "./framework/bigcommerce/api/operations/get-page.ts");
/* harmony import */ var _operations_get_site_info__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./operations/get-site-info */ "./framework/bigcommerce/api/operations/get-site-info.ts");
/* harmony import */ var _operations_get_customer_wishlist__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./operations/get-customer-wishlist */ "./framework/bigcommerce/api/operations/get-customer-wishlist.ts");
/* harmony import */ var _operations_get_all_product_paths__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./operations/get-all-product-paths */ "./framework/bigcommerce/api/operations/get-all-product-paths.ts");
/* harmony import */ var _operations_get_all_products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./operations/get-all-products */ "./framework/bigcommerce/api/operations/get-all-products.ts");
/* harmony import */ var _operations_get_product__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./operations/get-product */ "./framework/bigcommerce/api/operations/get-product.ts");
var _process$env$BIGCOMME;












const API_URL = process.env.BIGCOMMERCE_STOREFRONT_API_URL;
const API_TOKEN = process.env.BIGCOMMERCE_STOREFRONT_API_TOKEN;
const STORE_API_URL = process.env.BIGCOMMERCE_STORE_API_URL;
const STORE_API_TOKEN = process.env.BIGCOMMERCE_STORE_API_TOKEN;
const STORE_API_CLIENT_ID = process.env.BIGCOMMERCE_STORE_API_CLIENT_ID;
const STORE_CHANNEL_ID = process.env.BIGCOMMERCE_CHANNEL_ID;
const STORE_URL = process.env.BIGCOMMERCE_STORE_URL;
const CLIENT_SECRET = process.env.BIGCOMMERCE_STORE_API_CLIENT_SECRET;
const STOREFRONT_HASH = process.env.BIGCOMMERCE_STORE_API_STORE_HASH;

if (!API_URL) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_URL is missing and it's required to access your store`);
}

if (!API_TOKEN) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_TOKEN is missing and it's required to access your store`);
}

if (!(STORE_API_URL && STORE_API_TOKEN && STORE_API_CLIENT_ID)) {
  throw new Error(`The environment variables BIGCOMMERCE_STORE_API_URL, BIGCOMMERCE_STORE_API_TOKEN, BIGCOMMERCE_STORE_API_CLIENT_ID have to be set in order to access the REST API of your store`);
}

const ONE_DAY = 60 * 60 * 24;
const config = {
  commerceUrl: API_URL,
  apiToken: API_TOKEN,
  customerCookie: 'SHOP_TOKEN',
  cartCookie: (_process$env$BIGCOMME = process.env.BIGCOMMERCE_CART_COOKIE) !== null && _process$env$BIGCOMME !== void 0 ? _process$env$BIGCOMME : 'bc_cartId',
  cartCookieMaxAge: ONE_DAY * 30,
  fetch: (0,_utils_fetch_graphql_api__WEBPACK_IMPORTED_MODULE_0__.default)(() => getCommerceApi().getConfig()),
  applyLocale: true,
  // REST API only
  storeApiUrl: STORE_API_URL,
  storeApiToken: STORE_API_TOKEN,
  storeApiClientId: STORE_API_CLIENT_ID,
  storeChannelId: STORE_CHANNEL_ID,
  storeUrl: STORE_URL,
  storeApiClientSecret: CLIENT_SECRET,
  storeHash: STOREFRONT_HASH,
  storeApiFetch: (0,_utils_fetch_store_api__WEBPACK_IMPORTED_MODULE_1__.default)(() => getCommerceApi().getConfig())
};
const operations = {
  login: _operations_login__WEBPACK_IMPORTED_MODULE_2__.default,
  getAllPages: _operations_get_all_pages__WEBPACK_IMPORTED_MODULE_3__.default,
  getPage: _operations_get_page__WEBPACK_IMPORTED_MODULE_4__.default,
  getSiteInfo: _operations_get_site_info__WEBPACK_IMPORTED_MODULE_5__.default,
  getCustomerWishlist: _operations_get_customer_wishlist__WEBPACK_IMPORTED_MODULE_6__.default,
  getAllProductPaths: _operations_get_all_product_paths__WEBPACK_IMPORTED_MODULE_7__.default,
  getAllProducts: _operations_get_all_products__WEBPACK_IMPORTED_MODULE_8__.default,
  getProduct: _operations_get_product__WEBPACK_IMPORTED_MODULE_9__.default
};
const provider = {
  config,
  operations
};
function getCommerceApi(customProvider = provider) {
  return (0,_commerce_api__WEBPACK_IMPORTED_MODULE_10__.getCommerceApi)(customProvider);
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-pages.ts":
/*!***************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-pages.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getAllPagesOperation; }
/* harmony export */ });
function getAllPagesOperation({
  commerce
}) {
  async function getAllPages({
    config,
    preview
  } = {}) {
    var _ref;

    const cfg = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch('/v3/content/pages');
    const pages = (_ref = data) !== null && _ref !== void 0 ? _ref : [];
    return {
      pages: preview ? pages : pages.filter(p => p.is_visible)
    };
  }

  return getAllPages;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-product-paths.ts":
/*!***********************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-product-paths.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAllProductPathsQuery": function() { return /* binding */ getAllProductPathsQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductPathsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");

const getAllProductPathsQuery =
/* GraphQL */
`
  query getAllProductPaths($first: Int = 100) {
    site {
      products(first: $first) {
        edges {
          node {
            path
          }
        }
      }
    }
  }
`;
function getAllProductPathsOperation({
  commerce
}) {
  async function getAllProductPaths({
    query = getAllProductPathsQuery,
    variables,
    config
  } = {}) {
    var _data$site, _data$site$products;

    config = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const products = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$products = _data$site.products) === null || _data$site$products === void 0 ? void 0 : _data$site$products.edges;
    return {
      products: (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_0__.default)(products).map(({
        node
      }) => node)
    };
  }

  return getAllProductPaths;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-products.ts":
/*!******************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-products.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAllProductsQuery": function() { return /* binding */ getAllProductsQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");
/* harmony import */ var _utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/set-product-locale-meta */ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts");
/* harmony import */ var _fragments_product__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/product */ "./framework/bigcommerce/api/fragments/product.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");




const getAllProductsQuery =
/* GraphQL */
`
  query getAllProducts(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $entityIds: [Int!]
    $first: Int = 10
    $products: Boolean = false
    $featuredProducts: Boolean = false
    $bestSellingProducts: Boolean = false
    $newestProducts: Boolean = false
  ) {
    site {
      products(first: $first, entityIds: $entityIds) @include(if: $products) {
        ...productConnnection
      }
      featuredProducts(first: $first) @include(if: $featuredProducts) {
        ...productConnnection
      }
      bestSellingProducts(first: $first) @include(if: $bestSellingProducts) {
        ...productConnnection
      }
      newestProducts(first: $first) @include(if: $newestProducts) {
        ...productConnnection
      }
    }
  }

  ${_fragments_product__WEBPACK_IMPORTED_MODULE_0__.productConnectionFragment}
`;

function getProductsType(relevance) {
  switch (relevance) {
    case 'featured':
      return 'featuredProducts';

    case 'best_selling':
      return 'bestSellingProducts';

    case 'newest':
      return 'newestProducts';

    default:
      return 'products';
  }
}

function getAllProductsOperation({
  commerce
}) {
  async function getAllProducts({
    query = getAllProductsQuery,
    variables: vars = {},
    config: cfg
  } = {}) {
    var _data$site, _data$site$field;

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const field = getProductsType(vars.relevance);
    const variables = {
      locale,
      hasLocale: !!locale
    };
    variables[field] = true;
    if (vars.first) variables.first = vars.first;
    if (vars.ids) variables.entityIds = vars.ids.map(id => Number(id)); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const edges = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$field = _data$site[field]) === null || _data$site$field === void 0 ? void 0 : _data$site$field.edges;
    const products = (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_1__.default)(edges);

    if (locale && config.applyLocale) {
      products.forEach(product => {
        if (product.node) (0,_utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_2__.default)(product.node);
      });
    }

    return {
      products: products.map(({
        node
      }) => (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_3__.normalizeProduct)(node))
    };
  }

  return getAllProducts;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-customer-wishlist.ts":
/*!***********************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-customer-wishlist.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getCustomerWishlistOperation; }
/* harmony export */ });
function getCustomerWishlistOperation({
  commerce
}) {
  async function getCustomerWishlist({
    config,
    variables,
    includeProducts
  }) {
    var _wishlist$items;

    config = commerce.getConfig(config);
    const {
      data = []
    } = await config.storeApiFetch(`/v3/wishlists?customer_id=${variables.customerId}`);
    const wishlist = data[0];

    if (includeProducts && wishlist !== null && wishlist !== void 0 && (_wishlist$items = wishlist.items) !== null && _wishlist$items !== void 0 && _wishlist$items.length) {
      var _wishlist$items2;

      const ids = (_wishlist$items2 = wishlist.items) === null || _wishlist$items2 === void 0 ? void 0 : _wishlist$items2.map(item => item !== null && item !== void 0 && item.product_id ? String(item === null || item === void 0 ? void 0 : item.product_id) : null).filter(id => !!id);

      if (ids !== null && ids !== void 0 && ids.length) {
        const graphqlData = await commerce.getAllProducts({
          variables: {
            first: 50,
            ids
          },
          config
        }); // Put the products in an object that we can use to get them by id

        const productsById = graphqlData.products.reduce((prods, p) => {
          prods[Number(p.id)] = p;
          return prods;
        }, {}); // Populate the wishlist items with the graphql products

        wishlist.items.forEach(item => {
          const product = item && productsById[item.product_id];

          if (item && product) {
            // @ts-ignore Fix this type when the wishlist type is properly defined
            item.product = product;
          }
        });
      }
    }

    return {
      wishlist: wishlist
    };
  }

  return getCustomerWishlist;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-page.ts":
/*!**********************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-page.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getPageOperation; }
/* harmony export */ });
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");

function getPageOperation({
  commerce
}) {
  async function getPage({
    url,
    variables,
    config,
    preview
  }) {
    const cfg = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch(url || `/v3/content/pages?id=${variables.id}&include=body`);
    const firstPage = data === null || data === void 0 ? void 0 : data[0];
    const page = firstPage;

    if (preview || page !== null && page !== void 0 && page.is_visible) {
      return {
        page: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_0__.normalizePage)(page)
      };
    }

    return {};
  }

  return getPage;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-product.ts":
/*!*************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-product.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getProductQuery": function() { return /* binding */ getProductQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductPathsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/set-product-locale-meta */ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts");
/* harmony import */ var _fragments_product__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/product */ "./framework/bigcommerce/api/fragments/product.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const getProductQuery =
/* GraphQL */
`
  query getProduct(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $path: String!
  ) {
    site {
      route(path: $path) {
        node {
          __typename
          ... on Product {
            ...productInfo
            variants {
              edges {
                node {
                  entityId
                  defaultImage {
                    urlOriginal
                    altText
                    isDefault
                  }
                  prices {
                    ...productPrices
                  }
                  inventory {
                    aggregated {
                      availableToSell
                      warningLevel
                    }
                    isInStock
                  }
                  productOptions {
                    edges {
                      node {
                        __typename
                        entityId
                        displayName
                        ...multipleChoiceOption
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  ${_fragments_product__WEBPACK_IMPORTED_MODULE_0__.productInfoFragment}
`; // TODO: See if this type is useful for defining the Product type
// export type ProductNode = Extract<
//   GetProductQuery['site']['route']['node'],
//   { __typename: 'Product' }
// >

function getAllProductPathsOperation({
  commerce
}) {
  async function getProduct(_ref) {
    var _data$site, _data$site$route;

    let {
      query = getProductQuery,
      variables: {
        slug
      },
      config: cfg
    } = _ref,
        vars = _objectWithoutProperties(_ref.variables, ["slug"]);

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const variables = {
      locale,
      hasLocale: !!locale,
      path: slug ? `/${slug}/` : vars.path
    };
    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const product = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$route = _data$site.route) === null || _data$site$route === void 0 ? void 0 : _data$site$route.node;

    if ((product === null || product === void 0 ? void 0 : product.__typename) === 'Product') {
      if (locale && config.applyLocale) {
        (0,_utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_1__.default)(product);
      }

      return {
        product: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_2__.normalizeProduct)(product)
      };
    }

    return {};
  }

  return getProduct;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-site-info.ts":
/*!***************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-site-info.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getSiteInfoQuery": function() { return /* binding */ getSiteInfoQuery; },
/* harmony export */   "default": function() { return /* binding */ getSiteInfoOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");
/* harmony import */ var _fragments_category_tree__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/category-tree */ "./framework/bigcommerce/api/fragments/category-tree.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");


 // Get 3 levels of categories

const getSiteInfoQuery =
/* GraphQL */
`
  query getSiteInfo {
    site {
      categoryTree {
        ...categoryTreeItem
        children {
          ...categoryTreeItem
          children {
            ...categoryTreeItem
          }
        }
      }
      brands {
        pageInfo {
          startCursor
          endCursor
        }
        edges {
          cursor
          node {
            entityId
            name
            defaultImage {
              urlOriginal
              altText
            }
            pageTitle
            metaDesc
            metaKeywords
            searchKeywords
            path
          }
        }
      }
    }
  }
  ${_fragments_category_tree__WEBPACK_IMPORTED_MODULE_0__.categoryTreeItemFragment}
`;
function getSiteInfoOperation({
  commerce
}) {
  async function getSiteInfo({
    query = getSiteInfoQuery,
    config
  } = {}) {
    var _data$site, _data$site$brands;

    const cfg = commerce.getConfig(config);
    const {
      data
    } = await cfg.fetch(query);
    const categories = data.site.categoryTree.map(_lib_normalize__WEBPACK_IMPORTED_MODULE_1__.normalizeCategory);
    const brands = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$brands = _data$site.brands) === null || _data$site$brands === void 0 ? void 0 : _data$site$brands.edges;
    return {
      categories: categories !== null && categories !== void 0 ? categories : [],
      brands: (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_2__.default)(brands)
    };
  }

  return getSiteInfo;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/login.ts":
/*!*******************************************************!*\
  !*** ./framework/bigcommerce/api/operations/login.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loginMutation": function() { return /* binding */ loginMutation; },
/* harmony export */   "default": function() { return /* binding */ loginOperation; }
/* harmony export */ });
/* harmony import */ var _utils_concat_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/concat-cookie */ "./framework/bigcommerce/api/utils/concat-cookie.ts");

const loginMutation =
/* GraphQL */
`
  mutation login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      result
    }
  }
`;
function loginOperation({
  commerce
}) {
  async function login({
    query = loginMutation,
    variables,
    res: response,
    config
  }) {
    var _data$login;

    config = commerce.getConfig(config);
    const {
      data,
      res
    } = await config.fetch(query, {
      variables
    }); // Bigcommerce returns a Set-Cookie header with the auth cookie

    let cookie = res.headers.get('Set-Cookie');

    if (cookie && typeof cookie === 'string') {
      // In development, don't set a secure cookie or the browser will ignore it
      if (true) {
        cookie = cookie.replace('; Secure', ''); // SameSite=none can't be set unless the cookie is Secure
        // bc seems to sometimes send back SameSite=None rather than none so make
        // this case insensitive

        cookie = cookie.replace(/; SameSite=none/gi, '; SameSite=lax');
      }

      response.setHeader('Set-Cookie', (0,_utils_concat_cookie__WEBPACK_IMPORTED_MODULE_0__.default)(response.getHeader('Set-Cookie'), cookie));
    }

    return {
      result: (_data$login = data.login) === null || _data$login === void 0 ? void 0 : _data$login.result
    };
  }

  return login;
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/concat-cookie.ts":
/*!**********************************************************!*\
  !*** ./framework/bigcommerce/api/utils/concat-cookie.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ concatHeader; }
/* harmony export */ });
function concatHeader(prev, val) {
  if (!val) return prev;
  if (!prev) return val;
  if (Array.isArray(prev)) return prev.concat(String(val));
  prev = String(prev);
  if (Array.isArray(val)) return [prev].concat(val);
  return [prev, String(val)];
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/errors.ts":
/*!***************************************************!*\
  !*** ./framework/bigcommerce/api/utils/errors.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BigcommerceGraphQLError": function() { return /* binding */ BigcommerceGraphQLError; },
/* harmony export */   "BigcommerceApiError": function() { return /* binding */ BigcommerceApiError; },
/* harmony export */   "BigcommerceNetworkError": function() { return /* binding */ BigcommerceNetworkError; }
/* harmony export */ });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// Used for GraphQL errors
class BigcommerceGraphQLError extends Error {}
class BigcommerceApiError extends Error {
  constructor(msg, res, data) {
    super(msg);

    _defineProperty(this, "status", void 0);

    _defineProperty(this, "res", void 0);

    _defineProperty(this, "data", void 0);

    this.name = 'BigcommerceApiError';
    this.status = res.status;
    this.res = res;
    this.data = data;
  }

}
class BigcommerceNetworkError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'BigcommerceNetworkError';
  }

}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch-graphql-api.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch-graphql-api.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @commerce/utils/errors */ "./framework/commerce/utils/errors.ts");
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fetch */ "./framework/bigcommerce/api/utils/fetch.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchGraphqlApi = getConfig => async (query, {
  variables,
  preview
} = {}, fetchOptions) => {
  // log.warn(query)
  const config = getConfig();
  const res = await (0,_fetch__WEBPACK_IMPORTED_MODULE_0__.default)(config.commerceUrl + (preview ? '/preview' : ''), _objectSpread(_objectSpread({}, fetchOptions), {}, {
    method: 'POST',
    headers: _objectSpread(_objectSpread({
      Authorization: `Bearer ${config.apiToken}`
    }, fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.headers), {}, {
      'Content-Type': 'application/json'
    }),
    body: JSON.stringify({
      query,
      variables
    })
  }));
  const json = await res.json();

  if (json.errors) {
    var _json$errors;

    throw new _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__.FetcherError({
      errors: (_json$errors = json.errors) !== null && _json$errors !== void 0 ? _json$errors : [{
        message: 'Failed to fetch Bigcommerce API'
      }],
      status: res.status
    });
  }

  return {
    data: json.data,
    res
  };
};

/* harmony default export */ __webpack_exports__["default"] = (fetchGraphqlApi);

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch-store-api.ts":
/*!************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch-store-api.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./framework/bigcommerce/api/utils/errors.ts");
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fetch */ "./framework/bigcommerce/api/utils/fetch.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchStoreApi = getConfig => async (endpoint, options) => {
  const config = getConfig();
  let res;

  try {
    res = await (0,_fetch__WEBPACK_IMPORTED_MODULE_0__.default)(config.storeApiUrl + endpoint, _objectSpread(_objectSpread({}, options), {}, {
      headers: _objectSpread(_objectSpread({}, options === null || options === void 0 ? void 0 : options.headers), {}, {
        'Content-Type': 'application/json',
        'X-Auth-Token': config.storeApiToken,
        'X-Auth-Client': config.storeApiClientId
      })
    }));
  } catch (error) {
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceNetworkError(`Fetch to Bigcommerce failed: ${error.message}`);
  }

  const contentType = res.headers.get('Content-Type');
  const isJSON = contentType === null || contentType === void 0 ? void 0 : contentType.includes('application/json');

  if (!res.ok) {
    const data = isJSON ? await res.json() : await getTextOrNull(res);
    const headers = getRawHeaders(res);
    const msg = `Big Commerce API error (${res.status}) \nHeaders: ${JSON.stringify(headers, null, 2)}\n${typeof data === 'string' ? data : JSON.stringify(data, null, 2)}`;
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceApiError(msg, res, data);
  }

  if (res.status !== 204 && !isJSON) {
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceApiError(`Fetch to Bigcommerce API failed, expected JSON content but found: ${contentType}`, res);
  } // If something was removed, the response will be empty


  return res.status === 204 ? null : await res.json();
};

/* harmony default export */ __webpack_exports__["default"] = (fetchStoreApi);

function getRawHeaders(res) {
  const headers = {};
  res.headers.forEach((value, key) => {
    headers[key] = value;
  });
  return headers;
}

function getTextOrNull(res) {
  try {
    return res.text();
  } catch (err) {
    return null;
  }
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch.ts":
/*!**************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vercel_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @vercel/fetch */ "@vercel/fetch");
/* harmony import */ var _vercel_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_vercel_fetch__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (_vercel_fetch__WEBPACK_IMPORTED_MODULE_0___default()());

/***/ }),

/***/ "./framework/bigcommerce/api/utils/filter-edges.ts":
/*!*********************************************************!*\
  !*** ./framework/bigcommerce/api/utils/filter-edges.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ filterEdges; }
/* harmony export */ });
function filterEdges(edges) {
  var _edges$filter;

  return (_edges$filter = edges === null || edges === void 0 ? void 0 : edges.filter(edge => !!edge)) !== null && _edges$filter !== void 0 ? _edges$filter : [];
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/get-cart-cookie.ts":
/*!************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/get-cart-cookie.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getCartCookie; }
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ "cookie");
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

function getCartCookie(name, cartId, maxAge) {
  const options = cartId && maxAge ? {
    maxAge,
    expires: new Date(Date.now() + maxAge * 1000),
    secure: false,
    path: '/',
    sameSite: 'lax'
  } : {
    maxAge: -1,
    path: '/'
  }; // Removes the cookie

  return (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, cartId || '', options);
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/parse-item.ts":
/*!*******************************************************!*\
  !*** ./framework/bigcommerce/api/utils/parse-item.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseWishlistItem": function() { return /* binding */ parseWishlistItem; },
/* harmony export */   "parseCartItem": function() { return /* binding */ parseCartItem; }
/* harmony export */ });
const parseWishlistItem = item => ({
  product_id: Number(item.productId),
  variant_id: Number(item.variantId)
});
const parseCartItem = item => ({
  quantity: item.quantity,
  product_id: Number(item.productId),
  variant_id: Number(item.variantId),
  option_selections: item.optionSelections
});

/***/ }),

/***/ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts":
/*!********************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/set-product-locale-meta.ts ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ setProductLocaleMeta; }
/* harmony export */ });
function setProductLocaleMeta(node) {
  var _node$localeMeta;

  if ((_node$localeMeta = node.localeMeta) !== null && _node$localeMeta !== void 0 && _node$localeMeta.edges) {
    node.localeMeta.edges = node.localeMeta.edges.filter(edge => {
      var _edge$node;

      const {
        key,
        value
      } = (_edge$node = edge === null || edge === void 0 ? void 0 : edge.node) !== null && _edge$node !== void 0 ? _edge$node : {};

      if (key && key in node) {
        ;
        node[key] = value;
        return false;
      }

      return true;
    });

    if (!node.localeMeta.edges.length) {
      delete node.localeMeta;
    }
  }
}

/***/ }),

/***/ "./framework/bigcommerce/lib/get-slug.ts":
/*!***********************************************!*\
  !*** ./framework/bigcommerce/lib/get-slug.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = path => path.replace(/^\/|\/$/g, '');

/* harmony default export */ __webpack_exports__["default"] = (getSlug);

/***/ }),

/***/ "./framework/bigcommerce/lib/immutability.ts":
/*!***************************************************!*\
  !*** ./framework/bigcommerce/lib/immutability.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var immutability_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! immutability-helper */ "immutability-helper");
/* harmony import */ var immutability_helper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(immutability_helper__WEBPACK_IMPORTED_MODULE_0__);

const c = new immutability_helper__WEBPACK_IMPORTED_MODULE_0__.Context();
c.extend('$auto', function (value, object) {
  return object ? c.update(object, value) : c.update({}, value);
});
c.extend('$autoArray', function (value, object) {
  return object ? c.update(object, value) : c.update([], value);
});
/* harmony default export */ __webpack_exports__["default"] = (c.update);

/***/ }),

/***/ "./framework/bigcommerce/lib/normalize.ts":
/*!************************************************!*\
  !*** ./framework/bigcommerce/lib/normalize.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "normalizeProduct": function() { return /* binding */ normalizeProduct; },
/* harmony export */   "normalizePage": function() { return /* binding */ normalizePage; },
/* harmony export */   "normalizeCart": function() { return /* binding */ normalizeCart; },
/* harmony export */   "normalizeCategory": function() { return /* binding */ normalizeCategory; }
/* harmony export */ });
/* harmony import */ var _immutability__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./immutability */ "./framework/bigcommerce/lib/immutability.ts");
/* harmony import */ var _get_slug__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-slug */ "./framework/bigcommerce/lib/get-slug.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




function normalizeProductOption(productOption) {
  const {
    node: {
      entityId,
      values: {
        edges = []
      } = {}
    }
  } = productOption,
        rest = _objectWithoutProperties(productOption.node, ["entityId", "values"]);

  return _objectSpread({
    id: entityId,
    values: edges === null || edges === void 0 ? void 0 : edges.map(({
      node
    }) => node)
  }, rest);
}

function normalizeProduct(productNode) {
  const {
    entityId: id,
    productOptions,
    prices,
    path,
    id: _,
    options: _0
  } = productNode;
  return (0,_immutability__WEBPACK_IMPORTED_MODULE_0__.default)(productNode, {
    id: {
      $set: String(id)
    },
    images: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map((_ref) => {
        let {
          node: {
            urlOriginal,
            altText
          }
        } = _ref,
            rest = _objectWithoutProperties(_ref.node, ["urlOriginal", "altText"]);

        return _objectSpread({
          url: urlOriginal,
          alt: altText
        }, rest);
      })
    },
    variants: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map((_ref2) => {
        let {
          node: {
            entityId,
            productOptions
          }
        } = _ref2,
            rest = _objectWithoutProperties(_ref2.node, ["entityId", "productOptions"]);

        return _objectSpread({
          id: entityId,
          options: productOptions !== null && productOptions !== void 0 && productOptions.edges ? productOptions.edges.map(normalizeProductOption) : []
        }, rest);
      })
    },
    options: {
      $set: productOptions.edges ? productOptions === null || productOptions === void 0 ? void 0 : productOptions.edges.map(normalizeProductOption) : []
    },
    brand: {
      $apply: brand => brand !== null && brand !== void 0 && brand.entityId ? brand === null || brand === void 0 ? void 0 : brand.entityId : null
    },
    slug: {
      $set: path === null || path === void 0 ? void 0 : path.replace(/^\/+|\/+$/g, '')
    },
    price: {
      $set: {
        value: prices === null || prices === void 0 ? void 0 : prices.price.value,
        currencyCode: prices === null || prices === void 0 ? void 0 : prices.price.currencyCode
      }
    },
    $unset: ['entityId']
  });
}
function normalizePage(page) {
  return {
    id: String(page.id),
    name: page.name,
    is_visible: page.is_visible,
    sort_order: page.sort_order,
    body: page.body
  };
}
function normalizeCart(data) {
  var _data$discounts;

  return {
    id: data.id,
    customerId: String(data.customer_id),
    email: data.email,
    createdAt: data.created_time,
    currency: data.currency,
    taxesIncluded: data.tax_included,
    lineItems: [...data.line_items.physical_items.map(normalizeLineItem), ...data.line_items.digital_items.map(normalizeLineItem)],
    lineItemsSubtotalPrice: data.base_amount,
    subtotalPrice: data.base_amount + data.discount_amount,
    totalPrice: data.cart_amount,
    discounts: (_data$discounts = data.discounts) === null || _data$discounts === void 0 ? void 0 : _data$discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeLineItem(item) {
  return {
    id: item.id,
    variantId: String(item.variant_id),
    productId: String(item.product_id),
    name: item.name,
    quantity: item.quantity,
    variant: {
      id: String(item.variant_id),
      sku: item.sku,
      name: item.name,
      image: {
        url: item.image_url
      },
      requiresShipping: item.is_require_shipping,
      price: item.sale_price,
      listPrice: item.list_price
    },
    path: item.url.split('/')[3],
    discounts: item.discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeCategory(category) {
  return {
    id: `${category.entityId}`,
    name: category.name,
    slug: (0,_get_slug__WEBPACK_IMPORTED_MODULE_1__.default)(category.path),
    path: category.path
  };
}

/***/ }),

/***/ "./framework/commerce/api/endpoints/cart.ts":
/*!**************************************************!*\
  !*** ./framework/commerce/api/endpoints/cart.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/errors */ "./framework/commerce/api/utils/errors.ts");
/* harmony import */ var _utils_is_allowed_operation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/is-allowed-operation */ "./framework/commerce/api/utils/is-allowed-operation.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const cartEndpoint = async ctx => {
  const {
    req,
    res,
    handlers,
    config
  } = ctx;

  if (!(0,_utils_is_allowed_operation__WEBPACK_IMPORTED_MODULE_0__.default)(req, res, {
    GET: handlers['getCart'],
    POST: handlers['addItem'],
    PUT: handlers['updateItem'],
    DELETE: handlers['removeItem']
  })) {
    return;
  }

  const {
    cookies
  } = req;
  const cartId = cookies[config.cartCookie];

  try {
    // Return current cart info
    if (req.method === 'GET') {
      const body = {
        cartId
      };
      return await handlers['getCart'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Create or add an item to the cart


    if (req.method === 'POST') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['addItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Update item in cart


    if (req.method === 'PUT') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['updateItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    } // Remove an item from the cart


    if (req.method === 'DELETE') {
      const body = _objectSpread(_objectSpread({}, req.body), {}, {
        cartId
      });

      return await handlers['removeItem'](_objectSpread(_objectSpread({}, ctx), {}, {
        body
      }));
    }
  } catch (error) {
    console.error(error);
    const message = error instanceof _utils_errors__WEBPACK_IMPORTED_MODULE_1__.CommerceAPIError ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ __webpack_exports__["default"] = (cartEndpoint);

/***/ }),

/***/ "./framework/commerce/api/index.ts":
/*!*****************************************!*\
  !*** ./framework/commerce/api/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceAPICore": function() { return /* binding */ CommerceAPICore; },
/* harmony export */   "getCommerceApi": function() { return /* binding */ getCommerceApi; },
/* harmony export */   "getEndpoint": function() { return /* binding */ getEndpoint; },
/* harmony export */   "createEndpoint": function() { return /* binding */ createEndpoint; }
/* harmony export */ });
/* harmony import */ var _operations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./operations */ "./framework/commerce/api/operations.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class CommerceAPICore {
  constructor(provider) {
    this.provider = provider;
  }

  getConfig(userConfig = {}) {
    return Object.entries(userConfig).reduce((cfg, [key, value]) => Object.assign(cfg, {
      [key]: value
    }), _objectSpread({}, this.provider.config));
  }

  setConfig(newConfig) {
    Object.assign(this.provider.config, newConfig);
  }

}
function getCommerceApi(customProvider) {
  const commerce = Object.assign(new CommerceAPICore(customProvider), _operations__WEBPACK_IMPORTED_MODULE_0__.defaultOperations);
  const ops = customProvider.operations;
  _operations__WEBPACK_IMPORTED_MODULE_0__.OPERATIONS.forEach(k => {
    const op = ops[k];

    if (op) {
      commerce[k] = op({
        commerce
      });
    }
  });
  return commerce;
}
function getEndpoint(commerce, context) {
  const cfg = commerce.getConfig(context.config);
  return function apiHandler(req, res) {
    var _context$options;

    return context.handler({
      req,
      res,
      commerce,
      config: cfg,
      handlers: context.handlers,
      options: (_context$options = context.options) !== null && _context$options !== void 0 ? _context$options : {}
    });
  };
}
const createEndpoint = endpoint => (commerce, context) => {
  return getEndpoint(commerce, _objectSpread(_objectSpread({}, endpoint), context));
};

/***/ }),

/***/ "./framework/commerce/api/operations.ts":
/*!**********************************************!*\
  !*** ./framework/commerce/api/operations.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OPERATIONS": function() { return /* binding */ OPERATIONS; },
/* harmony export */   "defaultOperations": function() { return /* binding */ defaultOperations; }
/* harmony export */ });
const noop = () => {
  throw new Error('Not implemented');
};

const OPERATIONS = ['login', 'getAllPages', 'getPage', 'getSiteInfo', 'getCustomerWishlist', 'getAllProductPaths', 'getAllProducts', 'getProduct'];
const defaultOperations = OPERATIONS.reduce((ops, k) => {
  ops[k] = noop;
  return ops;
}, {});

/***/ }),

/***/ "./framework/commerce/api/utils/errors.ts":
/*!************************************************!*\
  !*** ./framework/commerce/api/utils/errors.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceAPIError": function() { return /* binding */ CommerceAPIError; },
/* harmony export */   "CommerceNetworkError": function() { return /* binding */ CommerceNetworkError; }
/* harmony export */ });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class CommerceAPIError extends Error {
  constructor(msg, res, data) {
    super(msg);

    _defineProperty(this, "status", void 0);

    _defineProperty(this, "res", void 0);

    _defineProperty(this, "data", void 0);

    this.name = 'CommerceApiError';
    this.status = res.status;
    this.res = res;
    this.data = data;
  }

}
class CommerceNetworkError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'CommerceNetworkError';
  }

}

/***/ }),

/***/ "./framework/commerce/api/utils/is-allowed-method.ts":
/*!***********************************************************!*\
  !*** ./framework/commerce/api/utils/is-allowed-method.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ isAllowedMethod; }
/* harmony export */ });
function isAllowedMethod(req, res, allowedMethods) {
  const methods = allowedMethods.includes('OPTIONS') ? allowedMethods : [...allowedMethods, 'OPTIONS'];

  if (!req.method || !methods.includes(req.method)) {
    res.status(405);
    res.setHeader('Allow', methods.join(', '));
    res.end();
    return false;
  }

  if (req.method === 'OPTIONS') {
    res.status(200);
    res.setHeader('Allow', methods.join(', '));
    res.setHeader('Content-Length', '0');
    res.end();
    return false;
  }

  return true;
}

/***/ }),

/***/ "./framework/commerce/api/utils/is-allowed-operation.ts":
/*!**************************************************************!*\
  !*** ./framework/commerce/api/utils/is-allowed-operation.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ isAllowedOperation; }
/* harmony export */ });
/* harmony import */ var _is_allowed_method__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./is-allowed-method */ "./framework/commerce/api/utils/is-allowed-method.ts");

function isAllowedOperation(req, res, allowedOperations) {
  const methods = Object.keys(allowedOperations);
  const allowedMethods = methods.reduce((arr, method) => {
    if (allowedOperations[method]) {
      arr.push(method);
    }

    return arr;
  }, []);
  return (0,_is_allowed_method__WEBPACK_IMPORTED_MODULE_0__.default)(req, res, allowedMethods);
}

/***/ }),

/***/ "./framework/commerce/utils/errors.ts":
/*!********************************************!*\
  !*** ./framework/commerce/utils/errors.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceError": function() { return /* binding */ CommerceError; },
/* harmony export */   "ValidationError": function() { return /* binding */ ValidationError; },
/* harmony export */   "FetcherError": function() { return /* binding */ FetcherError; }
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class CommerceError extends Error {
  constructor({
    message,
    code,
    errors
  }) {
    const error = message ? _objectSpread({
      message
    }, code ? {
      code
    } : {}) : errors[0];
    super(error.message);

    _defineProperty(this, "code", void 0);

    _defineProperty(this, "errors", void 0);

    this.errors = message ? [error] : errors;
    if (error.code) this.code = error.code;
  }

} // Used for errors that come from a bad implementation of the hooks

class ValidationError extends CommerceError {
  constructor(options) {
    super(options);
    this.code = 'validation_error';
  }

}
class FetcherError extends CommerceError {
  constructor(options) {
    super(options);

    _defineProperty(this, "status", void 0);

    this.status = options.status;
  }

}

/***/ }),

/***/ "./lib/api/commerce.ts":
/*!*****************************!*\
  !*** ./lib/api/commerce.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _framework_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @framework/api */ "./framework/bigcommerce/api/index.ts");

/* harmony default export */ __webpack_exports__["default"] = ((0,_framework_api__WEBPACK_IMPORTED_MODULE_0__.getCommerceApi)());

/***/ }),

/***/ "./pages/api/cart.ts":
/*!***************************!*\
  !*** ./pages/api/cart.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _framework_api_endpoints_cart__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @framework/api/endpoints/cart */ "./framework/bigcommerce/api/endpoints/cart/index.ts");
/* harmony import */ var _lib_api_commerce__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lib/api/commerce */ "./lib/api/commerce.ts");


/* harmony default export */ __webpack_exports__["default"] = ((0,_framework_api_endpoints_cart__WEBPACK_IMPORTED_MODULE_0__.default)(_lib_api_commerce__WEBPACK_IMPORTED_MODULE_1__.default));

/***/ }),

/***/ "@vercel/fetch":
/*!********************************!*\
  !*** external "@vercel/fetch" ***!
  \********************************/
/***/ (function(module) {

"use strict";
module.exports = require("@vercel/fetch");;

/***/ }),

/***/ "cookie":
/*!*************************!*\
  !*** external "cookie" ***!
  \*************************/
/***/ (function(module) {

"use strict";
module.exports = require("cookie");;

/***/ }),

/***/ "immutability-helper":
/*!**************************************!*\
  !*** external "immutability-helper" ***!
  \**************************************/
/***/ (function(module) {

"use strict";
module.exports = require("immutability-helper");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/cart.ts"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jYXJ0L2FkZC1pdGVtLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvZW5kcG9pbnRzL2NhcnQvZ2V0LWNhcnQudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9lbmRwb2ludHMvY2FydC9pbmRleC50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jYXJ0L3JlbW92ZS1pdGVtLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvZW5kcG9pbnRzL2NhcnQvdXBkYXRlLWl0ZW0udHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9mcmFnbWVudHMvY2F0ZWdvcnktdHJlZS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL2ZyYWdtZW50cy9wcm9kdWN0LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1hbGwtcGFnZXMudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1hbGwtcHJvZHVjdC1wYXRocy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL29wZXJhdGlvbnMvZ2V0LWFsbC1wcm9kdWN0cy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL29wZXJhdGlvbnMvZ2V0LWN1c3RvbWVyLXdpc2hsaXN0LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvb3BlcmF0aW9ucy9nZXQtcGFnZS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL29wZXJhdGlvbnMvZ2V0LXByb2R1Y3QudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1zaXRlLWluZm8udHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2xvZ2luLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvY29uY2F0LWNvb2tpZS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL3V0aWxzL2Vycm9ycy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL3V0aWxzL2ZldGNoLWdyYXBocWwtYXBpLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvZmV0Y2gtc3RvcmUtYXBpLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvZmV0Y2gudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS91dGlscy9maWx0ZXItZWRnZXMudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS91dGlscy9nZXQtY2FydC1jb29raWUudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS91dGlscy9wYXJzZS1pdGVtLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2xpYi9nZXQtc2x1Zy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvbGliL2ltbXV0YWJpbGl0eS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvbGliL25vcm1hbGl6ZS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jYXJ0LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9jb21tZXJjZS9hcGkvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9jb21tZXJjZS9hcGkvdXRpbHMvZXJyb3JzLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9jb21tZXJjZS9hcGkvdXRpbHMvaXMtYWxsb3dlZC1tZXRob2QudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2NvbW1lcmNlL2FwaS91dGlscy9pcy1hbGxvd2VkLW9wZXJhdGlvbi50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvdXRpbHMvZXJyb3JzLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2xpYi9hcGkvY29tbWVyY2UudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vcGFnZXMvYXBpL2NhcnQudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlL2V4dGVybmFsIFwiQHZlcmNlbC9mZXRjaFwiIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS9leHRlcm5hbCBcImNvb2tpZVwiIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS9leHRlcm5hbCBcImltbXV0YWJpbGl0eS1oZWxwZXJcIiJdLCJuYW1lcyI6WyJhZGRJdGVtIiwicmVzIiwiYm9keSIsImNhcnRJZCIsIml0ZW0iLCJjb25maWciLCJzdGF0dXMiLCJqc29uIiwiZGF0YSIsImVycm9ycyIsIm1lc3NhZ2UiLCJxdWFudGl0eSIsIm9wdGlvbnMiLCJtZXRob2QiLCJKU09OIiwic3RyaW5naWZ5IiwibGluZV9pdGVtcyIsInBhcnNlQ2FydEl0ZW0iLCJzdG9yZUNoYW5uZWxJZCIsImNoYW5uZWxfaWQiLCJzdG9yZUFwaUZldGNoIiwic2V0SGVhZGVyIiwiZ2V0Q2FydENvb2tpZSIsImNhcnRDb29raWUiLCJpZCIsImNhcnRDb29raWVNYXhBZ2UiLCJub3JtYWxpemVDYXJ0IiwiZ2V0Q2FydCIsInJlc3VsdCIsImVycm9yIiwiQmlnY29tbWVyY2VBcGlFcnJvciIsImhhbmRsZXJzIiwidXBkYXRlSXRlbSIsInJlbW92ZUl0ZW0iLCJjYXJ0QXBpIiwiY3JlYXRlRW5kcG9pbnQiLCJoYW5kbGVyIiwiY2FydEVuZHBvaW50IiwiaXRlbUlkIiwibGluZV9pdGVtIiwiY2F0ZWdvcnlUcmVlSXRlbUZyYWdtZW50IiwicHJvZHVjdFByaWNlcyIsInN3YXRjaE9wdGlvbkZyYWdtZW50IiwibXVsdGlwbGVDaG9pY2VPcHRpb25GcmFnbWVudCIsInByb2R1Y3RJbmZvRnJhZ21lbnQiLCJwcm9kdWN0Q29ubmVjdGlvbkZyYWdtZW50IiwiQVBJX1VSTCIsInByb2Nlc3MiLCJlbnYiLCJCSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9VUkwiLCJBUElfVE9LRU4iLCJCSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9UT0tFTiIsIlNUT1JFX0FQSV9VUkwiLCJCSUdDT01NRVJDRV9TVE9SRV9BUElfVVJMIiwiU1RPUkVfQVBJX1RPS0VOIiwiQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOIiwiU1RPUkVfQVBJX0NMSUVOVF9JRCIsIkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9DTElFTlRfSUQiLCJTVE9SRV9DSEFOTkVMX0lEIiwiQklHQ09NTUVSQ0VfQ0hBTk5FTF9JRCIsIlNUT1JFX1VSTCIsIkJJR0NPTU1FUkNFX1NUT1JFX1VSTCIsIkNMSUVOVF9TRUNSRVQiLCJCSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX1NFQ1JFVCIsIlNUT1JFRlJPTlRfSEFTSCIsIkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9TVE9SRV9IQVNIIiwiRXJyb3IiLCJPTkVfREFZIiwiY29tbWVyY2VVcmwiLCJhcGlUb2tlbiIsImN1c3RvbWVyQ29va2llIiwiQklHQ09NTUVSQ0VfQ0FSVF9DT09LSUUiLCJmZXRjaCIsImNyZWF0ZUZldGNoR3JhcGhxbEFwaSIsImdldENvbW1lcmNlQXBpIiwiZ2V0Q29uZmlnIiwiYXBwbHlMb2NhbGUiLCJzdG9yZUFwaVVybCIsInN0b3JlQXBpVG9rZW4iLCJzdG9yZUFwaUNsaWVudElkIiwic3RvcmVVcmwiLCJzdG9yZUFwaUNsaWVudFNlY3JldCIsInN0b3JlSGFzaCIsImNyZWF0ZUZldGNoU3RvcmVBcGkiLCJvcGVyYXRpb25zIiwibG9naW4iLCJnZXRBbGxQYWdlcyIsImdldFBhZ2UiLCJnZXRTaXRlSW5mbyIsImdldEN1c3RvbWVyV2lzaGxpc3QiLCJnZXRBbGxQcm9kdWN0UGF0aHMiLCJnZXRBbGxQcm9kdWN0cyIsImdldFByb2R1Y3QiLCJwcm92aWRlciIsImN1c3RvbVByb3ZpZGVyIiwiY29tbWVyY2VBcGkiLCJnZXRBbGxQYWdlc09wZXJhdGlvbiIsImNvbW1lcmNlIiwicHJldmlldyIsImNmZyIsInBhZ2VzIiwiZmlsdGVyIiwicCIsImlzX3Zpc2libGUiLCJnZXRBbGxQcm9kdWN0UGF0aHNRdWVyeSIsImdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbiIsInF1ZXJ5IiwidmFyaWFibGVzIiwicHJvZHVjdHMiLCJzaXRlIiwiZWRnZXMiLCJmaWx0ZXJFZGdlcyIsIm1hcCIsIm5vZGUiLCJnZXRBbGxQcm9kdWN0c1F1ZXJ5IiwiZ2V0UHJvZHVjdHNUeXBlIiwicmVsZXZhbmNlIiwiZ2V0QWxsUHJvZHVjdHNPcGVyYXRpb24iLCJ2YXJzIiwibG9jYWxlIiwiZmllbGQiLCJoYXNMb2NhbGUiLCJmaXJzdCIsImlkcyIsImVudGl0eUlkcyIsIk51bWJlciIsImZvckVhY2giLCJwcm9kdWN0Iiwic2V0UHJvZHVjdExvY2FsZU1ldGEiLCJub3JtYWxpemVQcm9kdWN0IiwiZ2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbiIsImluY2x1ZGVQcm9kdWN0cyIsImN1c3RvbWVySWQiLCJ3aXNobGlzdCIsIml0ZW1zIiwibGVuZ3RoIiwicHJvZHVjdF9pZCIsIlN0cmluZyIsImdyYXBocWxEYXRhIiwicHJvZHVjdHNCeUlkIiwicmVkdWNlIiwicHJvZHMiLCJnZXRQYWdlT3BlcmF0aW9uIiwidXJsIiwiZmlyc3RQYWdlIiwicGFnZSIsIm5vcm1hbGl6ZVBhZ2UiLCJnZXRQcm9kdWN0UXVlcnkiLCJzbHVnIiwicGF0aCIsInJvdXRlIiwiX190eXBlbmFtZSIsImdldFNpdGVJbmZvUXVlcnkiLCJnZXRTaXRlSW5mb09wZXJhdGlvbiIsImNhdGVnb3JpZXMiLCJjYXRlZ29yeVRyZWUiLCJub3JtYWxpemVDYXRlZ29yeSIsImJyYW5kcyIsImxvZ2luTXV0YXRpb24iLCJsb2dpbk9wZXJhdGlvbiIsInJlc3BvbnNlIiwiY29va2llIiwiaGVhZGVycyIsImdldCIsInJlcGxhY2UiLCJjb25jYXRIZWFkZXIiLCJnZXRIZWFkZXIiLCJwcmV2IiwidmFsIiwiQXJyYXkiLCJpc0FycmF5IiwiY29uY2F0IiwiQmlnY29tbWVyY2VHcmFwaFFMRXJyb3IiLCJjb25zdHJ1Y3RvciIsIm1zZyIsIm5hbWUiLCJCaWdjb21tZXJjZU5ldHdvcmtFcnJvciIsImZldGNoR3JhcGhxbEFwaSIsImZldGNoT3B0aW9ucyIsIkF1dGhvcml6YXRpb24iLCJGZXRjaGVyRXJyb3IiLCJmZXRjaFN0b3JlQXBpIiwiZW5kcG9pbnQiLCJjb250ZW50VHlwZSIsImlzSlNPTiIsImluY2x1ZGVzIiwib2siLCJnZXRUZXh0T3JOdWxsIiwiZ2V0UmF3SGVhZGVycyIsInZhbHVlIiwia2V5IiwidGV4dCIsImVyciIsInplaXRGZXRjaCIsImVkZ2UiLCJtYXhBZ2UiLCJleHBpcmVzIiwiRGF0ZSIsIm5vdyIsInNlY3VyZSIsInNhbWVTaXRlIiwic2VyaWFsaXplIiwicGFyc2VXaXNobGlzdEl0ZW0iLCJwcm9kdWN0SWQiLCJ2YXJpYW50X2lkIiwidmFyaWFudElkIiwib3B0aW9uX3NlbGVjdGlvbnMiLCJvcHRpb25TZWxlY3Rpb25zIiwibG9jYWxlTWV0YSIsImdldFNsdWciLCJjIiwiQ29udGV4dCIsImV4dGVuZCIsIm9iamVjdCIsInVwZGF0ZSIsIm5vcm1hbGl6ZVByb2R1Y3RPcHRpb24iLCJwcm9kdWN0T3B0aW9uIiwiZW50aXR5SWQiLCJ2YWx1ZXMiLCJyZXN0IiwicHJvZHVjdE5vZGUiLCJwcm9kdWN0T3B0aW9ucyIsInByaWNlcyIsIl8iLCJfMCIsIiRzZXQiLCJpbWFnZXMiLCIkYXBwbHkiLCJ1cmxPcmlnaW5hbCIsImFsdFRleHQiLCJhbHQiLCJ2YXJpYW50cyIsImJyYW5kIiwicHJpY2UiLCJjdXJyZW5jeUNvZGUiLCIkdW5zZXQiLCJzb3J0X29yZGVyIiwiY3VzdG9tZXJfaWQiLCJlbWFpbCIsImNyZWF0ZWRBdCIsImNyZWF0ZWRfdGltZSIsImN1cnJlbmN5IiwidGF4ZXNJbmNsdWRlZCIsInRheF9pbmNsdWRlZCIsImxpbmVJdGVtcyIsInBoeXNpY2FsX2l0ZW1zIiwibm9ybWFsaXplTGluZUl0ZW0iLCJkaWdpdGFsX2l0ZW1zIiwibGluZUl0ZW1zU3VidG90YWxQcmljZSIsImJhc2VfYW1vdW50Iiwic3VidG90YWxQcmljZSIsImRpc2NvdW50X2Ftb3VudCIsInRvdGFsUHJpY2UiLCJjYXJ0X2Ftb3VudCIsImRpc2NvdW50cyIsImRpc2NvdW50IiwiZGlzY291bnRlZF9hbW91bnQiLCJ2YXJpYW50Iiwic2t1IiwiaW1hZ2UiLCJpbWFnZV91cmwiLCJyZXF1aXJlc1NoaXBwaW5nIiwiaXNfcmVxdWlyZV9zaGlwcGluZyIsInNhbGVfcHJpY2UiLCJsaXN0UHJpY2UiLCJsaXN0X3ByaWNlIiwic3BsaXQiLCJjYXRlZ29yeSIsImN0eCIsInJlcSIsImlzQWxsb3dlZE9wZXJhdGlvbiIsIkdFVCIsIlBPU1QiLCJQVVQiLCJERUxFVEUiLCJjb29raWVzIiwiY29uc29sZSIsIkNvbW1lcmNlQVBJRXJyb3IiLCJDb21tZXJjZUFQSUNvcmUiLCJ1c2VyQ29uZmlnIiwiT2JqZWN0IiwiZW50cmllcyIsImFzc2lnbiIsInNldENvbmZpZyIsIm5ld0NvbmZpZyIsImRlZmF1bHRPcGVyYXRpb25zIiwib3BzIiwiT1BFUkFUSU9OUyIsImsiLCJvcCIsImdldEVuZHBvaW50IiwiY29udGV4dCIsImFwaUhhbmRsZXIiLCJub29wIiwiQ29tbWVyY2VOZXR3b3JrRXJyb3IiLCJpc0FsbG93ZWRNZXRob2QiLCJhbGxvd2VkTWV0aG9kcyIsIm1ldGhvZHMiLCJqb2luIiwiZW5kIiwiYWxsb3dlZE9wZXJhdGlvbnMiLCJrZXlzIiwiYXJyIiwicHVzaCIsIkNvbW1lcmNlRXJyb3IiLCJjb2RlIiwiVmFsaWRhdGlvbkVycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFHQSxNQUFNQSxPQUE0QyxHQUFHLE9BQU87QUFDMURDLEtBRDBEO0FBRTFEQyxNQUFJLEVBQUU7QUFBRUMsVUFBRjtBQUFVQztBQUFWLEdBRm9EO0FBRzFEQztBQUgwRCxDQUFQLEtBSS9DO0FBQ0osTUFBSSxDQUFDRCxJQUFMLEVBQVc7QUFDVCxXQUFPSCxHQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsVUFBSSxFQUFFLElBRG9CO0FBRTFCQyxZQUFNLEVBQUUsQ0FBQztBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUFEO0FBRmtCLEtBQXJCLENBQVA7QUFJRDs7QUFDRCxNQUFJLENBQUNOLElBQUksQ0FBQ08sUUFBVixFQUFvQlAsSUFBSSxDQUFDTyxRQUFMLEdBQWdCLENBQWhCO0FBRXBCLFFBQU1DLE9BQU8sR0FBRztBQUNkQyxVQUFNLEVBQUUsTUFETTtBQUVkWCxRQUFJLEVBQUVZLElBQUksQ0FBQ0MsU0FBTDtBQUNKQyxnQkFBVSxFQUFFLENBQUNDLGdFQUFhLENBQUNiLElBQUQsQ0FBZDtBQURSLE9BRUEsQ0FBQ0QsTUFBRCxJQUFXRSxNQUFNLENBQUNhLGNBQWxCLEdBQ0E7QUFBRUMsZ0JBQVUsRUFBRWQsTUFBTSxDQUFDYTtBQUFyQixLQURBLEdBRUEsRUFKQTtBQUZRLEdBQWhCO0FBU0EsUUFBTTtBQUFFVjtBQUFGLE1BQVdMLE1BQU0sR0FDbkIsTUFBTUUsTUFBTSxDQUFDZSxhQUFQLENBQ0gsYUFBWWpCLE1BQU8sa0RBRGhCLEVBRUpTLE9BRkksQ0FEYSxHQUtuQixNQUFNUCxNQUFNLENBQUNlLGFBQVAsQ0FDSixxREFESSxFQUVKUixPQUZJLENBTFYsQ0FsQkksQ0E0Qko7O0FBQ0FYLEtBQUcsQ0FBQ29CLFNBQUosQ0FDRSxZQURGLEVBRUVDLCtEQUFhLENBQUNqQixNQUFNLENBQUNrQixVQUFSLEVBQW9CZixJQUFJLENBQUNnQixFQUF6QixFQUE2Qm5CLE1BQU0sQ0FBQ29CLGdCQUFwQyxDQUZmO0FBSUF4QixLQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUFFQyxRQUFJLEVBQUVrQiw2REFBYSxDQUFDbEIsSUFBRDtBQUFyQixHQUFyQjtBQUNELENBdENEOztBQXdDQSwrREFBZVIsT0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7QUM3Q0E7QUFDQTtBQUNBOztBQUlBO0FBQ0EsTUFBTTJCLE9BQTRDLEdBQUcsT0FBTztBQUMxRDFCLEtBRDBEO0FBRTFEQyxNQUFJLEVBQUU7QUFBRUM7QUFBRixHQUZvRDtBQUcxREU7QUFIMEQsQ0FBUCxLQUkvQztBQUNKLE1BQUl1QixNQUFrQyxHQUFHLEVBQXpDOztBQUVBLE1BQUl6QixNQUFKLEVBQVk7QUFDVixRQUFJO0FBQ0Z5QixZQUFNLEdBQUcsTUFBTXZCLE1BQU0sQ0FBQ2UsYUFBUCxDQUNaLGFBQVlqQixNQUFPLDRDQURQLENBQWY7QUFHRCxLQUpELENBSUUsT0FBTzBCLEtBQVAsRUFBYztBQUNkLFVBQUlBLEtBQUssWUFBWUMsOERBQWpCLElBQXdDRCxLQUFLLENBQUN2QixNQUFOLEtBQWlCLEdBQTdELEVBQWtFO0FBQ2hFO0FBQ0FMLFdBQUcsQ0FBQ29CLFNBQUosQ0FBYyxZQUFkLEVBQTRCQywrREFBYSxDQUFDakIsTUFBTSxDQUFDa0IsVUFBUixDQUF6QztBQUNELE9BSEQsTUFHTztBQUNMLGNBQU1NLEtBQU47QUFDRDtBQUNGO0FBQ0Y7O0FBRUQ1QixLQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUNuQkMsUUFBSSxFQUFFb0IsTUFBTSxDQUFDcEIsSUFBUCxHQUFja0IsNkRBQWEsQ0FBQ0UsTUFBTSxDQUFDcEIsSUFBUixDQUEzQixHQUEyQztBQUQ5QixHQUFyQjtBQUdELENBekJEOztBQTJCQSwrREFBZW1CLE9BQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQU1PLE1BQU1JLFFBQWtDLEdBQUc7QUFDaERKLFNBRGdEO0FBRWhEM0IsU0FGZ0Q7QUFHaERnQyxZQUhnRDtBQUloREMsWUFBVUE7QUFKc0MsQ0FBM0M7QUFPUCxNQUFNQyxPQUFPLEdBQUdDLDZEQUFjLENBQVU7QUFDdENDLFNBQU8sRUFBRUMsaUVBRDZCO0FBRXRDTjtBQUZzQyxDQUFWLENBQTlCO0FBS0EsK0RBQWVHLE9BQWYsRTs7Ozs7Ozs7Ozs7Ozs7QUN6QkE7QUFDQTs7QUFHQSxNQUFNRCxVQUFrRCxHQUFHLE9BQU87QUFDaEVoQyxLQURnRTtBQUVoRUMsTUFBSSxFQUFFO0FBQUVDLFVBQUY7QUFBVW1DO0FBQVYsR0FGMEQ7QUFHaEVqQztBQUhnRSxDQUFQLEtBSXJEO0FBQUE7O0FBQ0osTUFBSSxDQUFDRixNQUFELElBQVcsQ0FBQ21DLE1BQWhCLEVBQXdCO0FBQ3RCLFdBQU9yQyxHQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUMxQkMsVUFBSSxFQUFFLElBRG9CO0FBRTFCQyxZQUFNLEVBQUUsQ0FBQztBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUFEO0FBRmtCLEtBQXJCLENBQVA7QUFJRDs7QUFFRCxRQUFNa0IsTUFBTSxHQUFHLE1BQU12QixNQUFNLENBQUNlLGFBQVAsQ0FDbEIsYUFBWWpCLE1BQU8sVUFBU21DLE1BQU8sNENBRGpCLEVBRW5CO0FBQUV6QixVQUFNLEVBQUU7QUFBVixHQUZtQixDQUFyQjtBQUlBLFFBQU1MLElBQUksbUJBQUdvQixNQUFILGFBQUdBLE1BQUgsdUJBQUdBLE1BQU0sQ0FBRXBCLElBQVgsdURBQW1CLElBQTdCO0FBRUFQLEtBQUcsQ0FBQ29CLFNBQUosQ0FDRSxZQURGLEVBRUViLElBQUksR0FDQTtBQUNBYyxpRUFBYSxDQUFDakIsTUFBTSxDQUFDa0IsVUFBUixFQUFvQnBCLE1BQXBCLEVBQTRCRSxNQUFNLENBQUNvQixnQkFBbkMsQ0FGYixHQUdBO0FBQ0FILGlFQUFhLENBQUNqQixNQUFNLENBQUNrQixVQUFSLENBTm5CO0FBUUF0QixLQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUFFQyxRQUFJLEVBQUVBLElBQUksSUFBSWtCLDZEQUFhLENBQUNsQixJQUFEO0FBQTdCLEdBQXJCO0FBQ0QsQ0EzQkQ7O0FBNkJBLCtEQUFleUIsVUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7QUNqQ0E7QUFDQTtBQUNBOztBQUdBLE1BQU1ELFVBQWtELEdBQUcsT0FBTztBQUNoRS9CLEtBRGdFO0FBRWhFQyxNQUFJLEVBQUU7QUFBRUMsVUFBRjtBQUFVbUMsVUFBVjtBQUFrQmxDO0FBQWxCLEdBRjBEO0FBR2hFQztBQUhnRSxDQUFQLEtBSXJEO0FBQ0osTUFBSSxDQUFDRixNQUFELElBQVcsQ0FBQ21DLE1BQVosSUFBc0IsQ0FBQ2xDLElBQTNCLEVBQWlDO0FBQy9CLFdBQU9ILEdBQUcsQ0FBQ0ssTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQzFCQyxVQUFJLEVBQUUsSUFEb0I7QUFFMUJDLFlBQU0sRUFBRSxDQUFDO0FBQUVDLGVBQU8sRUFBRTtBQUFYLE9BQUQ7QUFGa0IsS0FBckIsQ0FBUDtBQUlEOztBQUVELFFBQU07QUFBRUY7QUFBRixNQUFXLE1BQU1ILE1BQU0sQ0FBQ2UsYUFBUCxDQUNwQixhQUFZakIsTUFBTyxVQUFTbUMsTUFBTyw0Q0FEZixFQUVyQjtBQUNFekIsVUFBTSxFQUFFLEtBRFY7QUFFRVgsUUFBSSxFQUFFWSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNuQndCLGVBQVMsRUFBRXRCLGdFQUFhLENBQUNiLElBQUQ7QUFETCxLQUFmO0FBRlIsR0FGcUIsQ0FBdkIsQ0FSSSxDQWtCSjs7QUFDQUgsS0FBRyxDQUFDb0IsU0FBSixDQUNFLFlBREYsRUFFRUMsK0RBQWEsQ0FBQ2pCLE1BQU0sQ0FBQ2tCLFVBQVIsRUFBb0JwQixNQUFwQixFQUE0QkUsTUFBTSxDQUFDb0IsZ0JBQW5DLENBRmY7QUFJQXhCLEtBQUcsQ0FBQ0ssTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQUVDLFFBQUksRUFBRWtCLDZEQUFhLENBQUNsQixJQUFEO0FBQXJCLEdBQXJCO0FBQ0QsQ0E1QkQ7O0FBOEJBLCtEQUFld0IsVUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7QUNuQ08sTUFBTVEsd0JBQXdCO0FBQUc7QUFBZTtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUk8sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLE1BQU1DLGFBQWE7QUFBRztBQUFlO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWZPO0FBaUJBLE1BQU1DLG9CQUFvQjtBQUFHO0FBQWU7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUxPO0FBT0EsTUFBTUMsNEJBQTRCO0FBQUc7QUFBZTtBQUMzRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUQsb0JBQXFCO0FBQ3pCLENBYk87QUFlQSxNQUFNRSxtQkFBbUI7QUFBRztBQUFlO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJSCxhQUFjO0FBQ2xCLElBQUlFLDRCQUE2QjtBQUNqQyxDQXhETztBQTBEQSxNQUFNRSx5QkFBeUI7QUFBRztBQUFlO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUQsbUJBQW9CO0FBQ3hCLENBZk8sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoR1A7QUFLQTtBQUNBO0FBVUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWdCQSxNQUFNRSxPQUFPLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyw4QkFBNUI7QUFDQSxNQUFNQyxTQUFTLEdBQUdILE9BQU8sQ0FBQ0MsR0FBUixDQUFZRyxnQ0FBOUI7QUFDQSxNQUFNQyxhQUFhLEdBQUdMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyx5QkFBbEM7QUFDQSxNQUFNQyxlQUFlLEdBQUdQLE9BQU8sQ0FBQ0MsR0FBUixDQUFZTywyQkFBcEM7QUFDQSxNQUFNQyxtQkFBbUIsR0FBR1QsT0FBTyxDQUFDQyxHQUFSLENBQVlTLCtCQUF4QztBQUNBLE1BQU1DLGdCQUFnQixHQUFHWCxPQUFPLENBQUNDLEdBQVIsQ0FBWVcsc0JBQXJDO0FBQ0EsTUFBTUMsU0FBUyxHQUFHYixPQUFPLENBQUNDLEdBQVIsQ0FBWWEscUJBQTlCO0FBQ0EsTUFBTUMsYUFBYSxHQUFHZixPQUFPLENBQUNDLEdBQVIsQ0FBWWUsbUNBQWxDO0FBQ0EsTUFBTUMsZUFBZSxHQUFHakIsT0FBTyxDQUFDQyxHQUFSLENBQVlpQixnQ0FBcEM7O0FBRUEsSUFBSSxDQUFDbkIsT0FBTCxFQUFjO0FBQ1osUUFBTSxJQUFJb0IsS0FBSixDQUNILDJHQURHLENBQU47QUFHRDs7QUFFRCxJQUFJLENBQUNoQixTQUFMLEVBQWdCO0FBQ2QsUUFBTSxJQUFJZ0IsS0FBSixDQUNILDZHQURHLENBQU47QUFHRDs7QUFFRCxJQUFJLEVBQUVkLGFBQWEsSUFBSUUsZUFBakIsSUFBb0NFLG1CQUF0QyxDQUFKLEVBQWdFO0FBQzlELFFBQU0sSUFBSVUsS0FBSixDQUNILGdMQURHLENBQU47QUFHRDs7QUFFRCxNQUFNQyxPQUFPLEdBQUcsS0FBSyxFQUFMLEdBQVUsRUFBMUI7QUFFQSxNQUFNOUQsTUFBeUIsR0FBRztBQUNoQytELGFBQVcsRUFBRXRCLE9BRG1CO0FBRWhDdUIsVUFBUSxFQUFFbkIsU0FGc0I7QUFHaENvQixnQkFBYyxFQUFFLFlBSGdCO0FBSWhDL0MsWUFBVSwyQkFBRXdCLE9BQU8sQ0FBQ0MsR0FBUixDQUFZdUIsdUJBQWQseUVBQXlDLFdBSm5CO0FBS2hDOUMsa0JBQWdCLEVBQUUwQyxPQUFPLEdBQUcsRUFMSTtBQU1oQ0ssT0FBSyxFQUFFQyxpRUFBcUIsQ0FBQyxNQUFNQyxjQUFjLEdBQUdDLFNBQWpCLEVBQVAsQ0FOSTtBQU9oQ0MsYUFBVyxFQUFFLElBUG1CO0FBUWhDO0FBQ0FDLGFBQVcsRUFBRXpCLGFBVG1CO0FBVWhDMEIsZUFBYSxFQUFFeEIsZUFWaUI7QUFXaEN5QixrQkFBZ0IsRUFBRXZCLG1CQVhjO0FBWWhDdEMsZ0JBQWMsRUFBRXdDLGdCQVpnQjtBQWFoQ3NCLFVBQVEsRUFBQ3BCLFNBYnVCO0FBY2hDcUIsc0JBQW9CLEVBQUNuQixhQWRXO0FBZWhDb0IsV0FBUyxFQUFFbEIsZUFmcUI7QUFnQmhDNUMsZUFBYSxFQUFFK0QsK0RBQW1CLENBQUMsTUFBTVQsY0FBYyxHQUFHQyxTQUFqQixFQUFQO0FBaEJGLENBQWxDO0FBbUJBLE1BQU1TLFVBQVUsR0FBRztBQUNqQkMsT0FEaUI7QUFFakJDLGFBRmlCO0FBR2pCQyxTQUhpQjtBQUlqQkMsYUFKaUI7QUFLakJDLHFCQUxpQjtBQU1qQkMsb0JBTmlCO0FBT2pCQyxnQkFQaUI7QUFRakJDLFlBQVVBO0FBUk8sQ0FBbkI7QUFXTyxNQUFNQyxRQUFRLEdBQUc7QUFBRXhGLFFBQUY7QUFBVStFO0FBQVYsQ0FBakI7QUFlQSxTQUFTVixjQUFULENBQ0xvQixjQUFpQixHQUFHRCxRQURmLEVBRWM7QUFDbkIsU0FBT0UsOERBQVcsQ0FBQ0QsY0FBRCxDQUFsQjtBQUNELEM7Ozs7Ozs7Ozs7Ozs7OztBQy9HYyxTQUFTRSxvQkFBVCxDQUE4QjtBQUMzQ0M7QUFEMkMsQ0FBOUIsRUFFZ0I7QUFhN0IsaUJBQWVYLFdBQWYsQ0FBMkQ7QUFDekRqRixVQUR5RDtBQUV6RDZGO0FBRnlELE1BT3ZELEVBUEosRUFPNEI7QUFBQTs7QUFDMUIsVUFBTUMsR0FBRyxHQUFHRixRQUFRLENBQUN0QixTQUFULENBQW1CdEUsTUFBbkIsQ0FBWixDQUQwQixDQUUxQjtBQUNBOztBQUNBLFVBQU07QUFBRUc7QUFBRixRQUFXLE1BQU0yRixHQUFHLENBQUMvRSxhQUFKLENBRXJCLG1CQUZxQixDQUF2QjtBQUdBLFVBQU1nRixLQUFLLFdBQUk1RixJQUFKLHVDQUErQyxFQUExRDtBQUVBLFdBQU87QUFDTDRGLFdBQUssRUFBRUYsT0FBTyxHQUFHRSxLQUFILEdBQVdBLEtBQUssQ0FBQ0MsTUFBTixDQUFjQyxDQUFELElBQU9BLENBQUMsQ0FBQ0MsVUFBdEI7QUFEcEIsS0FBUDtBQUdEOztBQUVELFNBQU9qQixXQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0Q7QUFHTyxNQUFNa0IsdUJBQXVCO0FBQUc7QUFBZTtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FaTztBQWNRLFNBQVNDLDJCQUFULENBQXFDO0FBQ2xEUjtBQURrRCxDQUFyQyxFQUVnQjtBQWU3QixpQkFBZVAsa0JBQWYsQ0FBeUU7QUFDdkVnQixTQUFLLEdBQUdGLHVCQUQrRDtBQUV2RUcsYUFGdUU7QUFHdkV0RztBQUh1RSxNQVFyRSxFQVJKLEVBUTRCO0FBQUE7O0FBQzFCQSxVQUFNLEdBQUc0RixRQUFRLENBQUN0QixTQUFULENBQW1CdEUsTUFBbkIsQ0FBVCxDQUQwQixDQUUxQjtBQUNBOztBQUNBLFVBQU07QUFBRUc7QUFBRixRQUFXLE1BQU1ILE1BQU0sQ0FBQ21FLEtBQVAsQ0FFckJrQyxLQUZxQixFQUVkO0FBQUVDO0FBQUYsS0FGYyxDQUF2QjtBQUdBLFVBQU1DLFFBQVEsaUJBQUdwRyxJQUFJLENBQUNxRyxJQUFSLHNFQUFHLFdBQVdELFFBQWQsd0RBQUcsb0JBQXFCRSxLQUF0QztBQUVBLFdBQU87QUFDTEYsY0FBUSxFQUFFRyw0REFBVyxDQUFDSCxRQUFELENBQVgsQ0FBNERJLEdBQTVELENBQ1IsQ0FBQztBQUFFQztBQUFGLE9BQUQsS0FBY0EsSUFETjtBQURMLEtBQVA7QUFLRDs7QUFDRCxTQUFPdkIsa0JBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZERDtBQUNBO0FBQ0E7QUFFQTtBQUVPLE1BQU13QixtQkFBbUI7QUFBRztBQUFlO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJckUseUVBQTBCO0FBQzlCLENBNUJPOztBQTBDUCxTQUFTc0UsZUFBVCxDQUNFQyxTQURGLEVBRUU7QUFDQSxVQUFRQSxTQUFSO0FBQ0UsU0FBSyxVQUFMO0FBQ0UsYUFBTyxrQkFBUDs7QUFDRixTQUFLLGNBQUw7QUFDRSxhQUFPLHFCQUFQOztBQUNGLFNBQUssUUFBTDtBQUNFLGFBQU8sZ0JBQVA7O0FBQ0Y7QUFDRSxhQUFPLFVBQVA7QUFSSjtBQVVEOztBQUVjLFNBQVNDLHVCQUFULENBQWlDO0FBQzlDcEI7QUFEOEMsQ0FBakMsRUFFZ0I7QUFlN0IsaUJBQWVOLGNBQWYsQ0FBaUU7QUFDL0RlLFNBQUssR0FBR1EsbUJBRHVEO0FBRS9EUCxhQUFTLEVBQUVXLElBQUksR0FBRyxFQUY2QztBQUcvRGpILFVBQU0sRUFBRThGO0FBSHVELE1BUzdELEVBVEosRUFTNEI7QUFBQTs7QUFDMUIsVUFBTTlGLE1BQU0sR0FBRzRGLFFBQVEsQ0FBQ3RCLFNBQVQsQ0FBbUJ3QixHQUFuQixDQUFmO0FBQ0EsVUFBTTtBQUFFb0I7QUFBRixRQUFhbEgsTUFBbkI7QUFDQSxVQUFNbUgsS0FBSyxHQUFHTCxlQUFlLENBQUNHLElBQUksQ0FBQ0YsU0FBTixDQUE3QjtBQUNBLFVBQU1ULFNBQXVDLEdBQUc7QUFDOUNZLFlBRDhDO0FBRTlDRSxlQUFTLEVBQUUsQ0FBQyxDQUFDRjtBQUZpQyxLQUFoRDtBQUtBWixhQUFTLENBQUNhLEtBQUQsQ0FBVCxHQUFtQixJQUFuQjtBQUVBLFFBQUlGLElBQUksQ0FBQ0ksS0FBVCxFQUFnQmYsU0FBUyxDQUFDZSxLQUFWLEdBQWtCSixJQUFJLENBQUNJLEtBQXZCO0FBQ2hCLFFBQUlKLElBQUksQ0FBQ0ssR0FBVCxFQUFjaEIsU0FBUyxDQUFDaUIsU0FBVixHQUFzQk4sSUFBSSxDQUFDSyxHQUFMLENBQVNYLEdBQVQsQ0FBY3hGLEVBQUQsSUFBUXFHLE1BQU0sQ0FBQ3JHLEVBQUQsQ0FBM0IsQ0FBdEIsQ0FaWSxDQWMxQjtBQUNBOztBQUNBLFVBQU07QUFBRWhCO0FBQUYsUUFBVyxNQUFNSCxNQUFNLENBQUNtRSxLQUFQLENBQ3JCa0MsS0FEcUIsRUFFckI7QUFBRUM7QUFBRixLQUZxQixDQUF2QjtBQUlBLFVBQU1HLEtBQUssaUJBQUd0RyxJQUFJLENBQUNxRyxJQUFSLG1FQUFHLFdBQVlXLEtBQVosQ0FBSCxxREFBRyxpQkFBb0JWLEtBQWxDO0FBQ0EsVUFBTUYsUUFBUSxHQUFHRyw0REFBVyxDQUFDRCxLQUFELENBQTVCOztBQUVBLFFBQUlTLE1BQU0sSUFBSWxILE1BQU0sQ0FBQ3VFLFdBQXJCLEVBQWtDO0FBQ2hDZ0MsY0FBUSxDQUFDa0IsT0FBVCxDQUFrQkMsT0FBRCxJQUE0QztBQUMzRCxZQUFJQSxPQUFPLENBQUNkLElBQVosRUFBa0JlLHVFQUFvQixDQUFDRCxPQUFPLENBQUNkLElBQVQsQ0FBcEI7QUFDbkIsT0FGRDtBQUdEOztBQUVELFdBQU87QUFDTEwsY0FBUSxFQUFFQSxRQUFRLENBQUNJLEdBQVQsQ0FBYSxDQUFDO0FBQUVDO0FBQUYsT0FBRCxLQUFjZ0IsZ0VBQWdCLENBQUNoQixJQUFELENBQTNDO0FBREwsS0FBUDtBQUdEOztBQUVELFNBQU90QixjQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7O0FDMUhjLFNBQVN1Qyw0QkFBVCxDQUFzQztBQUNuRGpDO0FBRG1ELENBQXRDLEVBRWdCO0FBaUI3QixpQkFBZVIsbUJBQWYsQ0FBMkU7QUFDekVwRixVQUR5RTtBQUV6RXNHLGFBRnlFO0FBR3pFd0I7QUFIeUUsR0FBM0UsRUFTdUI7QUFBQTs7QUFDckI5SCxVQUFNLEdBQUc0RixRQUFRLENBQUN0QixTQUFULENBQW1CdEUsTUFBbkIsQ0FBVDtBQUVBLFVBQU07QUFBRUcsVUFBSSxHQUFHO0FBQVQsUUFBZ0IsTUFBTUgsTUFBTSxDQUFDZSxhQUFQLENBRXpCLDZCQUE0QnVGLFNBQVMsQ0FBQ3lCLFVBQVcsRUFGeEIsQ0FBNUI7QUFHQSxVQUFNQyxRQUFRLEdBQUc3SCxJQUFJLENBQUMsQ0FBRCxDQUFyQjs7QUFFQSxRQUFJMkgsZUFBZSxJQUFJRSxRQUFKLGFBQUlBLFFBQUosa0NBQUlBLFFBQVEsQ0FBRUMsS0FBZCw0Q0FBSSxnQkFBaUJDLE1BQXhDLEVBQWdEO0FBQUE7O0FBQzlDLFlBQU1aLEdBQUcsdUJBQUdVLFFBQVEsQ0FBQ0MsS0FBWixxREFBRyxpQkFDUnRCLEdBRFEsQ0FDSDVHLElBQUQsSUFBV0EsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixJQUFBQSxJQUFJLENBQUVvSSxVQUFOLEdBQW1CQyxNQUFNLENBQUNySSxJQUFELGFBQUNBLElBQUQsdUJBQUNBLElBQUksQ0FBRW9JLFVBQVAsQ0FBekIsR0FBOEMsSUFEckQsRUFFVG5DLE1BRlMsQ0FFRDdFLEVBQUQsSUFBc0IsQ0FBQyxDQUFDQSxFQUZ0QixDQUFaOztBQUlBLFVBQUltRyxHQUFKLGFBQUlBLEdBQUosZUFBSUEsR0FBRyxDQUFFWSxNQUFULEVBQWlCO0FBQ2YsY0FBTUcsV0FBVyxHQUFHLE1BQU16QyxRQUFRLENBQUNOLGNBQVQsQ0FBd0I7QUFDaERnQixtQkFBUyxFQUFFO0FBQUVlLGlCQUFLLEVBQUUsRUFBVDtBQUFhQztBQUFiLFdBRHFDO0FBRWhEdEg7QUFGZ0QsU0FBeEIsQ0FBMUIsQ0FEZSxDQUtmOztBQUNBLGNBQU1zSSxZQUFZLEdBQUdELFdBQVcsQ0FBQzlCLFFBQVosQ0FBcUJnQyxNQUFyQixDQUVsQixDQUFDQyxLQUFELEVBQVF2QyxDQUFSLEtBQWM7QUFDZnVDLGVBQUssQ0FBQ2hCLE1BQU0sQ0FBQ3ZCLENBQUMsQ0FBQzlFLEVBQUgsQ0FBUCxDQUFMLEdBQXNCOEUsQ0FBdEI7QUFDQSxpQkFBT3VDLEtBQVA7QUFDRCxTQUxvQixFQUtsQixFQUxrQixDQUFyQixDQU5lLENBWWY7O0FBQ0FSLGdCQUFRLENBQUNDLEtBQVQsQ0FBZVIsT0FBZixDQUF3QjFILElBQUQsSUFBVTtBQUMvQixnQkFBTTJILE9BQU8sR0FBRzNILElBQUksSUFBSXVJLFlBQVksQ0FBQ3ZJLElBQUksQ0FBQ29JLFVBQU4sQ0FBcEM7O0FBQ0EsY0FBSXBJLElBQUksSUFBSTJILE9BQVosRUFBcUI7QUFDbkI7QUFDQTNILGdCQUFJLENBQUMySCxPQUFMLEdBQWVBLE9BQWY7QUFDRDtBQUNGLFNBTkQ7QUFPRDtBQUNGOztBQUVELFdBQU87QUFBRU0sY0FBUSxFQUFFQTtBQUFaLEtBQVA7QUFDRDs7QUFFRCxTQUFPNUMsbUJBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDekVEO0FBRWUsU0FBU3FELGdCQUFULENBQTBCO0FBQ3ZDN0M7QUFEdUMsQ0FBMUIsRUFFZ0I7QUFlN0IsaUJBQWVWLE9BQWYsQ0FBbUQ7QUFDakR3RCxPQURpRDtBQUVqRHBDLGFBRmlEO0FBR2pEdEcsVUFIaUQ7QUFJakQ2RjtBQUppRCxHQUFuRCxFQVV1QjtBQUNyQixVQUFNQyxHQUFHLEdBQUdGLFFBQVEsQ0FBQ3RCLFNBQVQsQ0FBbUJ0RSxNQUFuQixDQUFaLENBRHFCLENBRXJCO0FBQ0E7O0FBQ0EsVUFBTTtBQUFFRztBQUFGLFFBQVcsTUFBTTJGLEdBQUcsQ0FBQy9FLGFBQUosQ0FFckIySCxHQUFHLElBQUssd0JBQXVCcEMsU0FBUyxDQUFDbkYsRUFBRyxlQUZ2QixDQUF2QjtBQUdBLFVBQU13SCxTQUFTLEdBQUd4SSxJQUFILGFBQUdBLElBQUgsdUJBQUdBLElBQUksQ0FBRyxDQUFILENBQXRCO0FBQ0EsVUFBTXlJLElBQUksR0FBR0QsU0FBYjs7QUFFQSxRQUFJOUMsT0FBTyxJQUFJK0MsSUFBSixhQUFJQSxJQUFKLGVBQUlBLElBQUksQ0FBRTFDLFVBQXJCLEVBQWlDO0FBQy9CLGFBQU87QUFBRTBDLFlBQUksRUFBRUMsNkRBQWEsQ0FBQ0QsSUFBRDtBQUFyQixPQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxFQUFQO0FBQ0Q7O0FBRUQsU0FBTzFELE9BQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9DRDtBQUNBO0FBRUE7QUFFTyxNQUFNNEQsZUFBZTtBQUFHO0FBQWU7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJdkcsbUVBQW9CO0FBQ3hCLENBbkRPLEMsQ0FxRFA7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSxTQUFTNkQsMkJBQVQsQ0FBcUM7QUFDbERSO0FBRGtELENBQXJDLEVBRWdCO0FBZTdCLGlCQUFlTCxVQUFmLE9BU3VCO0FBQUE7O0FBQUEsUUFUa0M7QUFDdkRjLFdBQUssR0FBR3lDLGVBRCtDO0FBRXZEeEMsZUFBUyxFQUFFO0FBQUV5QztBQUFGLE9BRjRDO0FBR3ZEL0ksWUFBTSxFQUFFOEY7QUFIK0MsS0FTbEM7QUFBQSxRQVBDbUIsSUFPRCxpQ0FQckJYLFNBT3FCOztBQUNyQixVQUFNdEcsTUFBTSxHQUFHNEYsUUFBUSxDQUFDdEIsU0FBVCxDQUFtQndCLEdBQW5CLENBQWY7QUFDQSxVQUFNO0FBQUVvQjtBQUFGLFFBQWFsSCxNQUFuQjtBQUNBLFVBQU1zRyxTQUFtQyxHQUFHO0FBQzFDWSxZQUQwQztBQUUxQ0UsZUFBUyxFQUFFLENBQUMsQ0FBQ0YsTUFGNkI7QUFHMUM4QixVQUFJLEVBQUVELElBQUksR0FBSSxJQUFHQSxJQUFLLEdBQVosR0FBaUI5QixJQUFJLENBQUMrQjtBQUhVLEtBQTVDO0FBS0EsVUFBTTtBQUFFN0k7QUFBRixRQUFXLE1BQU1ILE1BQU0sQ0FBQ21FLEtBQVAsQ0FBOEJrQyxLQUE5QixFQUFxQztBQUFFQztBQUFGLEtBQXJDLENBQXZCO0FBQ0EsVUFBTW9CLE9BQU8saUJBQUd2SCxJQUFJLENBQUNxRyxJQUFSLG1FQUFHLFdBQVd5QyxLQUFkLHFEQUFHLGlCQUFrQnJDLElBQWxDOztBQUVBLFFBQUksQ0FBQWMsT0FBTyxTQUFQLElBQUFBLE9BQU8sV0FBUCxZQUFBQSxPQUFPLENBQUV3QixVQUFULE1BQXdCLFNBQTVCLEVBQXVDO0FBQ3JDLFVBQUloQyxNQUFNLElBQUlsSCxNQUFNLENBQUN1RSxXQUFyQixFQUFrQztBQUNoQ29ELCtFQUFvQixDQUFDRCxPQUFELENBQXBCO0FBQ0Q7O0FBRUQsYUFBTztBQUFFQSxlQUFPLEVBQUVFLGdFQUFnQixDQUFDRixPQUFEO0FBQTNCLE9BQVA7QUFDRDs7QUFFRCxXQUFPLEVBQVA7QUFDRDs7QUFDRCxTQUFPbkMsVUFBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSEQ7QUFFQTtDQUdBOztBQUNPLE1BQU00RCxnQkFBZ0I7QUFBRztBQUFlO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJaEgsOEVBQXlCO0FBQzdCLENBckNPO0FBdUNRLFNBQVNpSCxvQkFBVCxDQUE4QjtBQUMzQ3hEO0FBRDJDLENBQTlCLEVBRWdCO0FBYTdCLGlCQUFlVCxXQUFmLENBQTJEO0FBQ3pEa0IsU0FBSyxHQUFHOEMsZ0JBRGlEO0FBRXpEbko7QUFGeUQsTUFPdkQsRUFQSixFQU80QjtBQUFBOztBQUMxQixVQUFNOEYsR0FBRyxHQUFHRixRQUFRLENBQUN0QixTQUFULENBQW1CdEUsTUFBbkIsQ0FBWjtBQUNBLFVBQU07QUFBRUc7QUFBRixRQUFXLE1BQU0yRixHQUFHLENBQUMzQixLQUFKLENBQTRCa0MsS0FBNUIsQ0FBdkI7QUFDQSxVQUFNZ0QsVUFBVSxHQUFHbEosSUFBSSxDQUFDcUcsSUFBTCxDQUFVOEMsWUFBVixDQUF1QjNDLEdBQXZCLENBQTJCNEMsNkRBQTNCLENBQW5CO0FBQ0EsVUFBTUMsTUFBTSxpQkFBR3JKLElBQUksQ0FBQ3FHLElBQVIsb0VBQUcsV0FBV2dELE1BQWQsc0RBQUcsa0JBQW1CL0MsS0FBbEM7QUFFQSxXQUFPO0FBQ0w0QyxnQkFBVSxFQUFFQSxVQUFGLGFBQUVBLFVBQUYsY0FBRUEsVUFBRixHQUFnQixFQURyQjtBQUVMRyxZQUFNLEVBQUU5Qyw0REFBVyxDQUFDOEMsTUFBRDtBQUZkLEtBQVA7QUFJRDs7QUFFRCxTQUFPckUsV0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUVEO0FBR08sTUFBTXNFLGFBQWE7QUFBRztBQUFlO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5PO0FBUVEsU0FBU0MsY0FBVCxDQUF3QjtBQUNyQzlEO0FBRHFDLENBQXhCLEVBRWdCO0FBZTdCLGlCQUFlWixLQUFmLENBQStDO0FBQzdDcUIsU0FBSyxHQUFHb0QsYUFEcUM7QUFFN0NuRCxhQUY2QztBQUc3QzFHLE9BQUcsRUFBRStKLFFBSHdDO0FBSTdDM0o7QUFKNkMsR0FBL0MsRUFVdUI7QUFBQTs7QUFDckJBLFVBQU0sR0FBRzRGLFFBQVEsQ0FBQ3RCLFNBQVQsQ0FBbUJ0RSxNQUFuQixDQUFUO0FBRUEsVUFBTTtBQUFFRyxVQUFGO0FBQVFQO0FBQVIsUUFBZ0IsTUFBTUksTUFBTSxDQUFDbUUsS0FBUCxDQUMxQmtDLEtBRDBCLEVBRTFCO0FBQUVDO0FBQUYsS0FGMEIsQ0FBNUIsQ0FIcUIsQ0FPckI7O0FBQ0EsUUFBSXNELE1BQU0sR0FBR2hLLEdBQUcsQ0FBQ2lLLE9BQUosQ0FBWUMsR0FBWixDQUFnQixZQUFoQixDQUFiOztBQUVBLFFBQUlGLE1BQU0sSUFBSSxPQUFPQSxNQUFQLEtBQWtCLFFBQWhDLEVBQTBDO0FBQ3hDO0FBQ0EsZ0JBQTJDO0FBQ3pDQSxjQUFNLEdBQUdBLE1BQU0sQ0FBQ0csT0FBUCxDQUFlLFVBQWYsRUFBMkIsRUFBM0IsQ0FBVCxDQUR5QyxDQUV6QztBQUNBO0FBQ0E7O0FBQ0FILGNBQU0sR0FBR0EsTUFBTSxDQUFDRyxPQUFQLENBQWUsbUJBQWYsRUFBb0MsZ0JBQXBDLENBQVQ7QUFDRDs7QUFFREosY0FBUSxDQUFDM0ksU0FBVCxDQUNFLFlBREYsRUFFRWdKLDZEQUFZLENBQUNMLFFBQVEsQ0FBQ00sU0FBVCxDQUFtQixZQUFuQixDQUFELEVBQW1DTCxNQUFuQyxDQUZkO0FBSUQ7O0FBRUQsV0FBTztBQUNMckksWUFBTSxpQkFBRXBCLElBQUksQ0FBQzZFLEtBQVAsZ0RBQUUsWUFBWXpEO0FBRGYsS0FBUDtBQUdEOztBQUVELFNBQU95RCxLQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7O0FDNUVjLFNBQVNnRixZQUFULENBQXNCRSxJQUF0QixFQUFvQ0MsR0FBcEMsRUFBaUQ7QUFDOUQsTUFBSSxDQUFDQSxHQUFMLEVBQVUsT0FBT0QsSUFBUDtBQUNWLE1BQUksQ0FBQ0EsSUFBTCxFQUFXLE9BQU9DLEdBQVA7QUFFWCxNQUFJQyxLQUFLLENBQUNDLE9BQU4sQ0FBY0gsSUFBZCxDQUFKLEVBQXlCLE9BQU9BLElBQUksQ0FBQ0ksTUFBTCxDQUFZbEMsTUFBTSxDQUFDK0IsR0FBRCxDQUFsQixDQUFQO0FBRXpCRCxNQUFJLEdBQUc5QixNQUFNLENBQUM4QixJQUFELENBQWI7QUFFQSxNQUFJRSxLQUFLLENBQUNDLE9BQU4sQ0FBY0YsR0FBZCxDQUFKLEVBQXdCLE9BQU8sQ0FBQ0QsSUFBRCxFQUFPSSxNQUFQLENBQWNILEdBQWQsQ0FBUDtBQUV4QixTQUFPLENBQUNELElBQUQsRUFBTzlCLE1BQU0sQ0FBQytCLEdBQUQsQ0FBYixDQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hEO0FBQ08sTUFBTUksdUJBQU4sU0FBc0MxRyxLQUF0QyxDQUE0QztBQUU1QyxNQUFNcEMsbUJBQU4sU0FBa0NvQyxLQUFsQyxDQUF3QztBQUs3QzJHLGFBQVcsQ0FBQ0MsR0FBRCxFQUFjN0ssR0FBZCxFQUE2Qk8sSUFBN0IsRUFBeUM7QUFDbEQsVUFBTXNLLEdBQU47O0FBRGtEOztBQUFBOztBQUFBOztBQUVsRCxTQUFLQyxJQUFMLEdBQVkscUJBQVo7QUFDQSxTQUFLekssTUFBTCxHQUFjTCxHQUFHLENBQUNLLE1BQWxCO0FBQ0EsU0FBS0wsR0FBTCxHQUFXQSxHQUFYO0FBQ0EsU0FBS08sSUFBTCxHQUFZQSxJQUFaO0FBQ0Q7O0FBWDRDO0FBY3hDLE1BQU13Syx1QkFBTixTQUFzQzlHLEtBQXRDLENBQTRDO0FBQ2pEMkcsYUFBVyxDQUFDQyxHQUFELEVBQWM7QUFDdkIsVUFBTUEsR0FBTjtBQUNBLFNBQUtDLElBQUwsR0FBWSx5QkFBWjtBQUNEOztBQUpnRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CbkQ7QUFHQTs7QUFFQSxNQUFNRSxlQUF1RSxHQUMxRXRHLFNBQUQsSUFDQSxPQUFPK0IsS0FBUCxFQUFzQjtBQUFFQyxXQUFGO0FBQWFUO0FBQWIsSUFBeUIsRUFBL0MsRUFBbURnRixZQUFuRCxLQUFvRTtBQUNsRTtBQUNBLFFBQU03SyxNQUFNLEdBQUdzRSxTQUFTLEVBQXhCO0FBQ0EsUUFBTTFFLEdBQUcsR0FBRyxNQUFNdUUsK0NBQUssQ0FBQ25FLE1BQU0sQ0FBQytELFdBQVAsSUFBc0I4QixPQUFPLEdBQUcsVUFBSCxHQUFnQixFQUE3QyxDQUFELGtDQUNsQmdGLFlBRGtCO0FBRXJCckssVUFBTSxFQUFFLE1BRmE7QUFHckJxSixXQUFPO0FBQ0xpQixtQkFBYSxFQUFHLFVBQVM5SyxNQUFNLENBQUNnRSxRQUFTO0FBRHBDLE9BRUY2RyxZQUZFLGFBRUZBLFlBRkUsdUJBRUZBLFlBQVksQ0FBRWhCLE9BRlo7QUFHTCxzQkFBZ0I7QUFIWCxNQUhjO0FBUXJCaEssUUFBSSxFQUFFWSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNuQjJGLFdBRG1CO0FBRW5CQztBQUZtQixLQUFmO0FBUmUsS0FBdkI7QUFjQSxRQUFNcEcsSUFBSSxHQUFHLE1BQU1OLEdBQUcsQ0FBQ00sSUFBSixFQUFuQjs7QUFDQSxNQUFJQSxJQUFJLENBQUNFLE1BQVQsRUFBaUI7QUFBQTs7QUFDZixVQUFNLElBQUkySyxnRUFBSixDQUFpQjtBQUNyQjNLLFlBQU0sa0JBQUVGLElBQUksQ0FBQ0UsTUFBUCx1REFBaUIsQ0FBQztBQUFFQyxlQUFPLEVBQUU7QUFBWCxPQUFELENBREY7QUFFckJKLFlBQU0sRUFBRUwsR0FBRyxDQUFDSztBQUZTLEtBQWpCLENBQU47QUFJRDs7QUFFRCxTQUFPO0FBQUVFLFFBQUksRUFBRUQsSUFBSSxDQUFDQyxJQUFiO0FBQW1CUDtBQUFuQixHQUFQO0FBQ0QsQ0E1Qkg7O0FBOEJBLCtEQUFlZ0wsZUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDQTtBQUNBOztBQUVBLE1BQU1JLGFBQWEsR0FDYjFHLFNBQUosSUFDQSxPQUFPMkcsUUFBUCxFQUF5QjFLLE9BQXpCLEtBQStEO0FBQzdELFFBQU1QLE1BQU0sR0FBR3NFLFNBQVMsRUFBeEI7QUFDQSxNQUFJMUUsR0FBSjs7QUFFQSxNQUFJO0FBQ0ZBLE9BQUcsR0FBRyxNQUFNdUUsK0NBQUssQ0FBQ25FLE1BQU0sQ0FBQ3dFLFdBQVAsR0FBcUJ5RyxRQUF0QixrQ0FDWjFLLE9BRFk7QUFFZnNKLGFBQU8sa0NBQ0Z0SixPQURFLGFBQ0ZBLE9BREUsdUJBQ0ZBLE9BQU8sQ0FBRXNKLE9BRFA7QUFFTCx3QkFBZ0Isa0JBRlg7QUFHTCx3QkFBZ0I3SixNQUFNLENBQUN5RSxhQUhsQjtBQUlMLHlCQUFpQnpFLE1BQU0sQ0FBQzBFO0FBSm5CO0FBRlEsT0FBakI7QUFTRCxHQVZELENBVUUsT0FBT2xELEtBQVAsRUFBYztBQUNkLFVBQU0sSUFBSW1KLDREQUFKLENBQ0gsZ0NBQStCbkosS0FBSyxDQUFDbkIsT0FBUSxFQUQxQyxDQUFOO0FBR0Q7O0FBRUQsUUFBTTZLLFdBQVcsR0FBR3RMLEdBQUcsQ0FBQ2lLLE9BQUosQ0FBWUMsR0FBWixDQUFnQixjQUFoQixDQUFwQjtBQUNBLFFBQU1xQixNQUFNLEdBQUdELFdBQUgsYUFBR0EsV0FBSCx1QkFBR0EsV0FBVyxDQUFFRSxRQUFiLENBQXNCLGtCQUF0QixDQUFmOztBQUVBLE1BQUksQ0FBQ3hMLEdBQUcsQ0FBQ3lMLEVBQVQsRUFBYTtBQUNYLFVBQU1sTCxJQUFJLEdBQUdnTCxNQUFNLEdBQUcsTUFBTXZMLEdBQUcsQ0FBQ00sSUFBSixFQUFULEdBQXNCLE1BQU1vTCxhQUFhLENBQUMxTCxHQUFELENBQTVEO0FBQ0EsVUFBTWlLLE9BQU8sR0FBRzBCLGFBQWEsQ0FBQzNMLEdBQUQsQ0FBN0I7QUFDQSxVQUFNNkssR0FBRyxHQUFJLDJCQUNYN0ssR0FBRyxDQUFDSyxNQUNMLGdCQUFlUSxJQUFJLENBQUNDLFNBQUwsQ0FBZW1KLE9BQWYsRUFBd0IsSUFBeEIsRUFBOEIsQ0FBOUIsQ0FBaUMsS0FDL0MsT0FBTzFKLElBQVAsS0FBZ0IsUUFBaEIsR0FBMkJBLElBQTNCLEdBQWtDTSxJQUFJLENBQUNDLFNBQUwsQ0FBZVAsSUFBZixFQUFxQixJQUFyQixFQUEyQixDQUEzQixDQUNuQyxFQUpEO0FBTUEsVUFBTSxJQUFJc0Isd0RBQUosQ0FBd0JnSixHQUF4QixFQUE2QjdLLEdBQTdCLEVBQWtDTyxJQUFsQyxDQUFOO0FBQ0Q7O0FBRUQsTUFBSVAsR0FBRyxDQUFDSyxNQUFKLEtBQWUsR0FBZixJQUFzQixDQUFDa0wsTUFBM0IsRUFBbUM7QUFDakMsVUFBTSxJQUFJMUosd0RBQUosQ0FDSCxxRUFBb0V5SixXQUFZLEVBRDdFLEVBRUp0TCxHQUZJLENBQU47QUFJRCxHQXhDNEQsQ0EwQzdEOzs7QUFDQSxTQUFPQSxHQUFHLENBQUNLLE1BQUosS0FBZSxHQUFmLEdBQXFCLElBQXJCLEdBQTRCLE1BQU1MLEdBQUcsQ0FBQ00sSUFBSixFQUF6QztBQUNELENBOUNIOztBQStDQSwrREFBZThLLGFBQWY7O0FBRUEsU0FBU08sYUFBVCxDQUF1QjNMLEdBQXZCLEVBQXNDO0FBQ3BDLFFBQU1pSyxPQUFrQyxHQUFHLEVBQTNDO0FBRUFqSyxLQUFHLENBQUNpSyxPQUFKLENBQVlwQyxPQUFaLENBQW9CLENBQUMrRCxLQUFELEVBQVFDLEdBQVIsS0FBZ0I7QUFDbEM1QixXQUFPLENBQUM0QixHQUFELENBQVAsR0FBZUQsS0FBZjtBQUNELEdBRkQ7QUFJQSxTQUFPM0IsT0FBUDtBQUNEOztBQUVELFNBQVN5QixhQUFULENBQXVCMUwsR0FBdkIsRUFBc0M7QUFDcEMsTUFBSTtBQUNGLFdBQU9BLEdBQUcsQ0FBQzhMLElBQUosRUFBUDtBQUNELEdBRkQsQ0FFRSxPQUFPQyxHQUFQLEVBQVk7QUFDWixXQUFPLElBQVA7QUFDRDtBQUNGLEM7Ozs7Ozs7Ozs7Ozs7O0FDdEVEO0FBRUEsK0RBQWVDLG9EQUFTLEVBQXhCLEU7Ozs7Ozs7Ozs7Ozs7OztBQ0ZlLFNBQVNsRixXQUFULENBQ2JELEtBRGEsRUFFYjtBQUFBOztBQUNBLDBCQUFPQSxLQUFQLGFBQU9BLEtBQVAsdUJBQU9BLEtBQUssQ0FBRVQsTUFBUCxDQUFlNkYsSUFBRCxJQUFxQixDQUFDLENBQUNBLElBQXJDLENBQVAseURBQXFELEVBQXJEO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKRDtBQUVlLFNBQVM1SyxhQUFULENBQ2J5SixJQURhLEVBRWI1SyxNQUZhLEVBR2JnTSxNQUhhLEVBSWI7QUFDQSxRQUFNdkwsT0FBK0IsR0FDbkNULE1BQU0sSUFBSWdNLE1BQVYsR0FDSTtBQUNFQSxVQURGO0FBRUVDLFdBQU8sRUFBRSxJQUFJQyxJQUFKLENBQVNBLElBQUksQ0FBQ0MsR0FBTCxLQUFhSCxNQUFNLEdBQUcsSUFBL0IsQ0FGWDtBQUdFSSxVQUFNLE9BSFI7QUFJRWxELFFBQUksRUFBRSxHQUpSO0FBS0VtRCxZQUFRLEVBQUU7QUFMWixHQURKLEdBUUk7QUFBRUwsVUFBTSxFQUFFLENBQUMsQ0FBWDtBQUFjOUMsUUFBSSxFQUFFO0FBQXBCLEdBVE4sQ0FEQSxDQVVnQzs7QUFFaEMsU0FBT29ELGlEQUFTLENBQUMxQixJQUFELEVBQU81SyxNQUFNLElBQUksRUFBakIsRUFBcUJTLE9BQXJCLENBQWhCO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ0pNLE1BQU04TCxpQkFBaUIsR0FDNUJ0TSxJQUQrQixLQUVQO0FBQ3hCb0ksWUFBVSxFQUFFWCxNQUFNLENBQUN6SCxJQUFJLENBQUN1TSxTQUFOLENBRE07QUFFeEJDLFlBQVUsRUFBRS9FLE1BQU0sQ0FBQ3pILElBQUksQ0FBQ3lNLFNBQU47QUFGTSxDQUZPLENBQTFCO0FBT0EsTUFBTTVMLGFBQWEsR0FBSWIsSUFBRCxLQUF5QztBQUNwRU8sVUFBUSxFQUFFUCxJQUFJLENBQUNPLFFBRHFEO0FBRXBFNkgsWUFBVSxFQUFFWCxNQUFNLENBQUN6SCxJQUFJLENBQUN1TSxTQUFOLENBRmtEO0FBR3BFQyxZQUFVLEVBQUUvRSxNQUFNLENBQUN6SCxJQUFJLENBQUN5TSxTQUFOLENBSGtEO0FBSXBFQyxtQkFBaUIsRUFBRTFNLElBQUksQ0FBQzJNO0FBSjRDLENBQXpDLENBQXRCLEM7Ozs7Ozs7Ozs7Ozs7OztBQ25CUSxTQUFTL0Usb0JBQVQsQ0FDYmYsSUFEYSxFQUViO0FBQUE7O0FBQ0EsMEJBQUlBLElBQUksQ0FBQytGLFVBQVQsNkNBQUksaUJBQWlCbEcsS0FBckIsRUFBNEI7QUFDMUJHLFFBQUksQ0FBQytGLFVBQUwsQ0FBZ0JsRyxLQUFoQixHQUF3QkcsSUFBSSxDQUFDK0YsVUFBTCxDQUFnQmxHLEtBQWhCLENBQXNCVCxNQUF0QixDQUE4QjZGLElBQUQsSUFBVTtBQUFBOztBQUM3RCxZQUFNO0FBQUVKLFdBQUY7QUFBT0Q7QUFBUCx3QkFBaUJLLElBQWpCLGFBQWlCQSxJQUFqQix1QkFBaUJBLElBQUksQ0FBRWpGLElBQXZCLG1EQUErQixFQUFyQzs7QUFDQSxVQUFJNkUsR0FBRyxJQUFJQSxHQUFHLElBQUk3RSxJQUFsQixFQUF3QjtBQUN0QjtBQUFFQSxZQUFELENBQWM2RSxHQUFkLElBQXFCRCxLQUFyQjtBQUNELGVBQU8sS0FBUDtBQUNEOztBQUNELGFBQU8sSUFBUDtBQUNELEtBUHVCLENBQXhCOztBQVNBLFFBQUksQ0FBQzVFLElBQUksQ0FBQytGLFVBQUwsQ0FBZ0JsRyxLQUFoQixDQUFzQnlCLE1BQTNCLEVBQW1DO0FBQ2pDLGFBQU90QixJQUFJLENBQUMrRixVQUFaO0FBQ0Q7QUFDRjtBQUNGLEM7Ozs7Ozs7Ozs7OztBQ3BCRDtBQUNBO0FBQ0EsTUFBTUMsT0FBTyxHQUFJNUQsSUFBRCxJQUFrQkEsSUFBSSxDQUFDZSxPQUFMLENBQWEsVUFBYixFQUF5QixFQUF6QixDQUFsQzs7QUFFQSwrREFBZTZDLE9BQWYsRTs7Ozs7Ozs7Ozs7Ozs7QUNKQTtBQUVBLE1BQU1DLENBQUMsR0FBRyxJQUFJQyx3REFBSixFQUFWO0FBRUFELENBQUMsQ0FBQ0UsTUFBRixDQUFTLE9BQVQsRUFBa0IsVUFBVXZCLEtBQVYsRUFBaUJ3QixNQUFqQixFQUF5QjtBQUN6QyxTQUFPQSxNQUFNLEdBQUdILENBQUMsQ0FBQ0ksTUFBRixDQUFTRCxNQUFULEVBQWlCeEIsS0FBakIsQ0FBSCxHQUE2QnFCLENBQUMsQ0FBQ0ksTUFBRixDQUFTLEVBQVQsRUFBYXpCLEtBQWIsQ0FBMUM7QUFDRCxDQUZEO0FBSUFxQixDQUFDLENBQUNFLE1BQUYsQ0FBUyxZQUFULEVBQXVCLFVBQVV2QixLQUFWLEVBQWlCd0IsTUFBakIsRUFBeUI7QUFDOUMsU0FBT0EsTUFBTSxHQUFHSCxDQUFDLENBQUNJLE1BQUYsQ0FBU0QsTUFBVCxFQUFpQnhCLEtBQWpCLENBQUgsR0FBNkJxQixDQUFDLENBQUNJLE1BQUYsQ0FBUyxFQUFULEVBQWF6QixLQUFiLENBQTFDO0FBQ0QsQ0FGRDtBQUlBLCtEQUFlcUIsQ0FBQyxDQUFDSSxNQUFqQixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTtBQUNBOztBQUVBLFNBQVNDLHNCQUFULENBQWdDQyxhQUFoQyxFQUFvRDtBQUNsRCxRQUFNO0FBQ0p2RyxRQUFJLEVBQUU7QUFDSndHLGNBREk7QUFFSkMsWUFBTSxFQUFFO0FBQUU1RyxhQUFLLEdBQUc7QUFBVixVQUFpQjtBQUZyQjtBQURGLE1BTUYwRyxhQU5KO0FBQUEsUUFJT0csSUFKUCw0QkFNSUgsYUFOSixDQUNFdkcsSUFERjs7QUFRQTtBQUNFekYsTUFBRSxFQUFFaU0sUUFETjtBQUVFQyxVQUFNLEVBQUU1RyxLQUFGLGFBQUVBLEtBQUYsdUJBQUVBLEtBQUssQ0FBRUUsR0FBUCxDQUFXLENBQUM7QUFBRUM7QUFBRixLQUFELEtBQW1CQSxJQUE5QjtBQUZWLEtBR0swRyxJQUhMO0FBS0Q7O0FBRU0sU0FBUzFGLGdCQUFULENBQTBCMkYsV0FBMUIsRUFBcUQ7QUFDMUQsUUFBTTtBQUNKSCxZQUFRLEVBQUVqTSxFQUROO0FBRUpxTSxrQkFGSTtBQUdKQyxVQUhJO0FBSUp6RSxRQUpJO0FBS0o3SCxNQUFFLEVBQUV1TSxDQUxBO0FBTUpuTixXQUFPLEVBQUVvTjtBQU5MLE1BT0ZKLFdBUEo7QUFTQSxTQUFPTixzREFBTSxDQUFDTSxXQUFELEVBQWM7QUFDekJwTSxNQUFFLEVBQUU7QUFBRXlNLFVBQUksRUFBRXhGLE1BQU0sQ0FBQ2pILEVBQUQ7QUFBZCxLQURxQjtBQUV6QjBNLFVBQU0sRUFBRTtBQUNOQyxZQUFNLEVBQUUsQ0FBQztBQUFFckg7QUFBRixPQUFELEtBQ05BLEtBRE0sYUFDTkEsS0FETSx1QkFDTkEsS0FBSyxDQUFFRSxHQUFQLENBQVc7QUFBQSxZQUFDO0FBQUVDLGNBQUksRUFBRTtBQUFFbUgsdUJBQUY7QUFBZUM7QUFBZjtBQUFSLFNBQUQ7QUFBQSxZQUFvQ1YsSUFBcEMsaUNBQUcxRyxJQUFIOztBQUFBO0FBQ1Q4QixhQUFHLEVBQUVxRixXQURJO0FBRVRFLGFBQUcsRUFBRUQ7QUFGSSxXQUdOVixJQUhNO0FBQUEsT0FBWDtBQUZJLEtBRmlCO0FBVXpCWSxZQUFRLEVBQUU7QUFDUkosWUFBTSxFQUFFLENBQUM7QUFBRXJIO0FBQUYsT0FBRCxLQUNOQSxLQURNLGFBQ05BLEtBRE0sdUJBQ05BLEtBQUssQ0FBRUUsR0FBUCxDQUFXO0FBQUEsWUFBQztBQUFFQyxjQUFJLEVBQUU7QUFBRXdHLG9CQUFGO0FBQVlJO0FBQVo7QUFBUixTQUFEO0FBQUEsWUFBd0NGLElBQXhDLGtDQUFHMUcsSUFBSDs7QUFBQTtBQUNUekYsWUFBRSxFQUFFaU0sUUFESztBQUVUN00saUJBQU8sRUFBRWlOLGNBQWMsU0FBZCxJQUFBQSxjQUFjLFdBQWQsSUFBQUEsY0FBYyxDQUFFL0csS0FBaEIsR0FDTCtHLGNBQWMsQ0FBQy9HLEtBQWYsQ0FBcUJFLEdBQXJCLENBQXlCdUcsc0JBQXpCLENBREssR0FFTDtBQUpLLFdBS05JLElBTE07QUFBQSxPQUFYO0FBRk0sS0FWZTtBQW9CekIvTSxXQUFPLEVBQUU7QUFDUHFOLFVBQUksRUFBRUosY0FBYyxDQUFDL0csS0FBZixHQUNGK0csY0FERSxhQUNGQSxjQURFLHVCQUNGQSxjQUFjLENBQUUvRyxLQUFoQixDQUFzQkUsR0FBdEIsQ0FBMEJ1RyxzQkFBMUIsQ0FERSxHQUVGO0FBSEcsS0FwQmdCO0FBeUJ6QmlCLFNBQUssRUFBRTtBQUNMTCxZQUFNLEVBQUdLLEtBQUQsSUFBaUJBLEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsSUFBQUEsS0FBSyxDQUFFZixRQUFQLEdBQWtCZSxLQUFsQixhQUFrQkEsS0FBbEIsdUJBQWtCQSxLQUFLLENBQUVmLFFBQXpCLEdBQW9DO0FBRHhELEtBekJrQjtBQTRCekJyRSxRQUFJLEVBQUU7QUFDSjZFLFVBQUksRUFBRTVFLElBQUYsYUFBRUEsSUFBRix1QkFBRUEsSUFBSSxDQUFFZSxPQUFOLENBQWMsWUFBZCxFQUE0QixFQUE1QjtBQURGLEtBNUJtQjtBQStCekJxRSxTQUFLLEVBQUU7QUFDTFIsVUFBSSxFQUFFO0FBQ0pwQyxhQUFLLEVBQUVpQyxNQUFGLGFBQUVBLE1BQUYsdUJBQUVBLE1BQU0sQ0FBRVcsS0FBUixDQUFjNUMsS0FEakI7QUFFSjZDLG9CQUFZLEVBQUVaLE1BQUYsYUFBRUEsTUFBRix1QkFBRUEsTUFBTSxDQUFFVyxLQUFSLENBQWNDO0FBRnhCO0FBREQsS0EvQmtCO0FBcUN6QkMsVUFBTSxFQUFFLENBQUMsVUFBRDtBQXJDaUIsR0FBZCxDQUFiO0FBdUNEO0FBRU0sU0FBU3pGLGFBQVQsQ0FBdUJELElBQXZCLEVBQTZEO0FBQ2xFLFNBQU87QUFDTHpILE1BQUUsRUFBRWlILE1BQU0sQ0FBQ1EsSUFBSSxDQUFDekgsRUFBTixDQURMO0FBRUx1SixRQUFJLEVBQUU5QixJQUFJLENBQUM4QixJQUZOO0FBR0x4RSxjQUFVLEVBQUUwQyxJQUFJLENBQUMxQyxVQUhaO0FBSUxxSSxjQUFVLEVBQUUzRixJQUFJLENBQUMyRixVQUpaO0FBS0wxTyxRQUFJLEVBQUUrSSxJQUFJLENBQUMvSTtBQUxOLEdBQVA7QUFPRDtBQUVNLFNBQVN3QixhQUFULENBQXVCbEIsSUFBdkIsRUFBb0Q7QUFBQTs7QUFDekQsU0FBTztBQUNMZ0IsTUFBRSxFQUFFaEIsSUFBSSxDQUFDZ0IsRUFESjtBQUVMNEcsY0FBVSxFQUFFSyxNQUFNLENBQUNqSSxJQUFJLENBQUNxTyxXQUFOLENBRmI7QUFHTEMsU0FBSyxFQUFFdE8sSUFBSSxDQUFDc08sS0FIUDtBQUlMQyxhQUFTLEVBQUV2TyxJQUFJLENBQUN3TyxZQUpYO0FBS0xDLFlBQVEsRUFBRXpPLElBQUksQ0FBQ3lPLFFBTFY7QUFNTEMsaUJBQWEsRUFBRTFPLElBQUksQ0FBQzJPLFlBTmY7QUFPTEMsYUFBUyxFQUFFLENBQ1QsR0FBRzVPLElBQUksQ0FBQ1EsVUFBTCxDQUFnQnFPLGNBQWhCLENBQStCckksR0FBL0IsQ0FBbUNzSSxpQkFBbkMsQ0FETSxFQUVULEdBQUc5TyxJQUFJLENBQUNRLFVBQUwsQ0FBZ0J1TyxhQUFoQixDQUE4QnZJLEdBQTlCLENBQWtDc0ksaUJBQWxDLENBRk0sQ0FQTjtBQVdMRSwwQkFBc0IsRUFBRWhQLElBQUksQ0FBQ2lQLFdBWHhCO0FBWUxDLGlCQUFhLEVBQUVsUCxJQUFJLENBQUNpUCxXQUFMLEdBQW1CalAsSUFBSSxDQUFDbVAsZUFabEM7QUFhTEMsY0FBVSxFQUFFcFAsSUFBSSxDQUFDcVAsV0FiWjtBQWNMQyxhQUFTLHFCQUFFdFAsSUFBSSxDQUFDc1AsU0FBUCxvREFBRSxnQkFBZ0I5SSxHQUFoQixDQUFxQitJLFFBQUQsS0FBZTtBQUM1Q2xFLFdBQUssRUFBRWtFLFFBQVEsQ0FBQ0M7QUFENEIsS0FBZixDQUFwQjtBQWROLEdBQVA7QUFrQkQ7O0FBRUQsU0FBU1YsaUJBQVQsQ0FBMkJsUCxJQUEzQixFQUFnRDtBQUM5QyxTQUFPO0FBQ0xvQixNQUFFLEVBQUVwQixJQUFJLENBQUNvQixFQURKO0FBRUxxTCxhQUFTLEVBQUVwRSxNQUFNLENBQUNySSxJQUFJLENBQUN3TSxVQUFOLENBRlo7QUFHTEQsYUFBUyxFQUFFbEUsTUFBTSxDQUFDckksSUFBSSxDQUFDb0ksVUFBTixDQUhaO0FBSUx1QyxRQUFJLEVBQUUzSyxJQUFJLENBQUMySyxJQUpOO0FBS0xwSyxZQUFRLEVBQUVQLElBQUksQ0FBQ08sUUFMVjtBQU1Mc1AsV0FBTyxFQUFFO0FBQ1B6TyxRQUFFLEVBQUVpSCxNQUFNLENBQUNySSxJQUFJLENBQUN3TSxVQUFOLENBREg7QUFFUHNELFNBQUcsRUFBRTlQLElBQUksQ0FBQzhQLEdBRkg7QUFHUG5GLFVBQUksRUFBRTNLLElBQUksQ0FBQzJLLElBSEo7QUFJUG9GLFdBQUssRUFBRTtBQUNMcEgsV0FBRyxFQUFFM0ksSUFBSSxDQUFDZ1E7QUFETCxPQUpBO0FBT1BDLHNCQUFnQixFQUFFalEsSUFBSSxDQUFDa1EsbUJBUGhCO0FBUVA3QixXQUFLLEVBQUVyTyxJQUFJLENBQUNtUSxVQVJMO0FBU1BDLGVBQVMsRUFBRXBRLElBQUksQ0FBQ3FRO0FBVFQsS0FOSjtBQWlCTHBILFFBQUksRUFBRWpKLElBQUksQ0FBQzJJLEdBQUwsQ0FBUzJILEtBQVQsQ0FBZSxHQUFmLEVBQW9CLENBQXBCLENBakJEO0FBa0JMWixhQUFTLEVBQUUxUCxJQUFJLENBQUMwUCxTQUFMLENBQWU5SSxHQUFmLENBQW9CK0ksUUFBRCxLQUFvQjtBQUNoRGxFLFdBQUssRUFBRWtFLFFBQVEsQ0FBQ0M7QUFEZ0MsS0FBcEIsQ0FBbkI7QUFsQk4sR0FBUDtBQXNCRDs7QUFFTSxTQUFTcEcsaUJBQVQsQ0FBMkIrRyxRQUEzQixFQUEyRDtBQUNoRSxTQUFPO0FBQ0xuUCxNQUFFLEVBQUcsR0FBRW1QLFFBQVEsQ0FBQ2xELFFBQVMsRUFEcEI7QUFFTDFDLFFBQUksRUFBRTRGLFFBQVEsQ0FBQzVGLElBRlY7QUFHTDNCLFFBQUksRUFBRTZELGtEQUFPLENBQUMwRCxRQUFRLENBQUN0SCxJQUFWLENBSFI7QUFJTEEsUUFBSSxFQUFFc0gsUUFBUSxDQUFDdEg7QUFKVixHQUFQO0FBTUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6SUQ7QUFDQTs7QUFHQSxNQUFNaEgsWUFHa0IsR0FBRyxNQUFPdU8sR0FBUCxJQUFlO0FBQ3hDLFFBQU07QUFBRUMsT0FBRjtBQUFPNVEsT0FBUDtBQUFZOEIsWUFBWjtBQUFzQjFCO0FBQXRCLE1BQWlDdVEsR0FBdkM7O0FBRUEsTUFDRSxDQUFDRSxvRUFBa0IsQ0FBQ0QsR0FBRCxFQUFNNVEsR0FBTixFQUFXO0FBQzVCOFEsT0FBRyxFQUFFaFAsUUFBUSxDQUFDLFNBQUQsQ0FEZTtBQUU1QmlQLFFBQUksRUFBRWpQLFFBQVEsQ0FBQyxTQUFELENBRmM7QUFHNUJrUCxPQUFHLEVBQUVsUCxRQUFRLENBQUMsWUFBRCxDQUhlO0FBSTVCbVAsVUFBTSxFQUFFblAsUUFBUSxDQUFDLFlBQUQ7QUFKWSxHQUFYLENBRHJCLEVBT0U7QUFDQTtBQUNEOztBQUVELFFBQU07QUFBRW9QO0FBQUYsTUFBY04sR0FBcEI7QUFDQSxRQUFNMVEsTUFBTSxHQUFHZ1IsT0FBTyxDQUFDOVEsTUFBTSxDQUFDa0IsVUFBUixDQUF0Qjs7QUFFQSxNQUFJO0FBQ0Y7QUFDQSxRQUFJc1AsR0FBRyxDQUFDaFEsTUFBSixLQUFlLEtBQW5CLEVBQTBCO0FBQ3hCLFlBQU1YLElBQUksR0FBRztBQUFFQztBQUFGLE9BQWI7QUFDQSxhQUFPLE1BQU00QixRQUFRLENBQUMsU0FBRCxDQUFSLGlDQUF5QjZPLEdBQXpCO0FBQThCMVE7QUFBOUIsU0FBYjtBQUNELEtBTEMsQ0FPRjs7O0FBQ0EsUUFBSTJRLEdBQUcsQ0FBQ2hRLE1BQUosS0FBZSxNQUFuQixFQUEyQjtBQUN6QixZQUFNWCxJQUFJLG1DQUFRMlEsR0FBRyxDQUFDM1EsSUFBWjtBQUFrQkM7QUFBbEIsUUFBVjs7QUFDQSxhQUFPLE1BQU00QixRQUFRLENBQUMsU0FBRCxDQUFSLGlDQUF5QjZPLEdBQXpCO0FBQThCMVE7QUFBOUIsU0FBYjtBQUNELEtBWEMsQ0FhRjs7O0FBQ0EsUUFBSTJRLEdBQUcsQ0FBQ2hRLE1BQUosS0FBZSxLQUFuQixFQUEwQjtBQUN4QixZQUFNWCxJQUFJLG1DQUFRMlEsR0FBRyxDQUFDM1EsSUFBWjtBQUFrQkM7QUFBbEIsUUFBVjs7QUFDQSxhQUFPLE1BQU00QixRQUFRLENBQUMsWUFBRCxDQUFSLGlDQUE0QjZPLEdBQTVCO0FBQWlDMVE7QUFBakMsU0FBYjtBQUNELEtBakJDLENBbUJGOzs7QUFDQSxRQUFJMlEsR0FBRyxDQUFDaFEsTUFBSixLQUFlLFFBQW5CLEVBQTZCO0FBQzNCLFlBQU1YLElBQUksbUNBQVEyUSxHQUFHLENBQUMzUSxJQUFaO0FBQWtCQztBQUFsQixRQUFWOztBQUNBLGFBQU8sTUFBTTRCLFFBQVEsQ0FBQyxZQUFELENBQVIsaUNBQTRCNk8sR0FBNUI7QUFBaUMxUTtBQUFqQyxTQUFiO0FBQ0Q7QUFDRixHQXhCRCxDQXdCRSxPQUFPMkIsS0FBUCxFQUFjO0FBQ2R1UCxXQUFPLENBQUN2UCxLQUFSLENBQWNBLEtBQWQ7QUFFQSxVQUFNbkIsT0FBTyxHQUNYbUIsS0FBSyxZQUFZd1AsMkRBQWpCLEdBQ0ksbURBREosR0FFSSw2QkFITjtBQUtBcFIsT0FBRyxDQUFDSyxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFBRUMsVUFBSSxFQUFFLElBQVI7QUFBY0MsWUFBTSxFQUFFLENBQUM7QUFBRUM7QUFBRixPQUFEO0FBQXRCLEtBQXJCO0FBQ0Q7QUFDRixDQXRERDs7QUF3REEsK0RBQWUyQixZQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoREE7QUFvRU8sTUFBTWlQLGVBQU4sQ0FBMkQ7QUFDaEV6RyxhQUFXLENBQVVoRixRQUFWLEVBQXVCO0FBQUEsU0FBYkEsUUFBYSxHQUFiQSxRQUFhO0FBQUU7O0FBRXBDbEIsV0FBUyxDQUFDNE0sVUFBZ0MsR0FBRyxFQUFwQyxFQUFxRDtBQUM1RCxXQUFPQyxNQUFNLENBQUNDLE9BQVAsQ0FBZUYsVUFBZixFQUEyQjNJLE1BQTNCLENBQ0wsQ0FBQ3pDLEdBQUQsRUFBTSxDQUFDMkYsR0FBRCxFQUFNRCxLQUFOLENBQU4sS0FBdUIyRixNQUFNLENBQUNFLE1BQVAsQ0FBY3ZMLEdBQWQsRUFBbUI7QUFBRSxPQUFDMkYsR0FBRCxHQUFPRDtBQUFULEtBQW5CLENBRGxCLG9CQUVBLEtBQUtoRyxRQUFMLENBQWN4RixNQUZkLEVBQVA7QUFJRDs7QUFFRHNSLFdBQVMsQ0FBQ0MsU0FBRCxFQUFrQztBQUN6Q0osVUFBTSxDQUFDRSxNQUFQLENBQWMsS0FBSzdMLFFBQUwsQ0FBY3hGLE1BQTVCLEVBQW9DdVIsU0FBcEM7QUFDRDs7QUFaK0Q7QUFlM0QsU0FBU2xOLGNBQVQsQ0FDTG9CLGNBREssRUFFVztBQUNoQixRQUFNRyxRQUFRLEdBQUd1TCxNQUFNLENBQUNFLE1BQVAsQ0FDZixJQUFJSixlQUFKLENBQW9CeEwsY0FBcEIsQ0FEZSxFQUVmK0wsMERBRmUsQ0FBakI7QUFJQSxRQUFNQyxHQUFHLEdBQUdoTSxjQUFjLENBQUNWLFVBQTNCO0FBRUEyTSw2REFBQSxDQUFvQkMsQ0FBRCxJQUFPO0FBQ3hCLFVBQU1DLEVBQUUsR0FBR0gsR0FBRyxDQUFDRSxDQUFELENBQWQ7O0FBQ0EsUUFBSUMsRUFBSixFQUFRO0FBQ05oTSxjQUFRLENBQUMrTCxDQUFELENBQVIsR0FBY0MsRUFBRSxDQUFDO0FBQUVoTTtBQUFGLE9BQUQsQ0FBaEI7QUFDRDtBQUNGLEdBTEQ7QUFPQSxTQUFPQSxRQUFQO0FBQ0Q7QUFFTSxTQUFTaU0sV0FBVCxDQUlMak0sUUFKSyxFQUtMa00sT0FMSyxFQVNXO0FBQ2hCLFFBQU1oTSxHQUFHLEdBQUdGLFFBQVEsQ0FBQ3RCLFNBQVQsQ0FBbUJ3TixPQUFPLENBQUM5UixNQUEzQixDQUFaO0FBRUEsU0FBTyxTQUFTK1IsVUFBVCxDQUFvQnZCLEdBQXBCLEVBQXlCNVEsR0FBekIsRUFBOEI7QUFBQTs7QUFDbkMsV0FBT2tTLE9BQU8sQ0FBQy9QLE9BQVIsQ0FBZ0I7QUFDckJ5TyxTQURxQjtBQUVyQjVRLFNBRnFCO0FBR3JCZ0csY0FIcUI7QUFJckI1RixZQUFNLEVBQUU4RixHQUphO0FBS3JCcEUsY0FBUSxFQUFFb1EsT0FBTyxDQUFDcFEsUUFMRztBQU1yQm5CLGFBQU8sc0JBQUV1UixPQUFPLENBQUN2UixPQUFWLCtEQUFxQjtBQU5QLEtBQWhCLENBQVA7QUFRRCxHQVREO0FBVUQ7QUFFTSxNQUFNdUIsY0FBYyxHQUNZbUosUUFBckMsSUFDQSxDQUNFckYsUUFERixFQUVFa00sT0FGRixLQU1xQjtBQUNuQixTQUFPRCxXQUFXLENBQUNqTSxRQUFELGtDQUFnQnFGLFFBQWhCLEdBQTZCNkcsT0FBN0IsRUFBbEI7QUFDRCxDQVZJLEM7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvSFAsTUFBTUUsSUFBSSxHQUFHLE1BQU07QUFDakIsUUFBTSxJQUFJbk8sS0FBSixDQUFVLGlCQUFWLENBQU47QUFDRCxDQUZEOztBQUlPLE1BQU02TixVQUFVLEdBQUcsQ0FDeEIsT0FEd0IsRUFFeEIsYUFGd0IsRUFHeEIsU0FId0IsRUFJeEIsYUFKd0IsRUFLeEIscUJBTHdCLEVBTXhCLG9CQU53QixFQU94QixnQkFQd0IsRUFReEIsWUFSd0IsQ0FBbkI7QUFXQSxNQUFNRixpQkFBaUIsR0FBR0UsVUFBVSxDQUFDbkosTUFBWCxDQUFrQixDQUFDa0osR0FBRCxFQUFNRSxDQUFOLEtBQVk7QUFDN0RGLEtBQUcsQ0FBQ0UsQ0FBRCxDQUFILEdBQVNLLElBQVQ7QUFDQSxTQUFPUCxHQUFQO0FBQ0QsQ0FIZ0MsRUFHOUIsRUFIOEIsQ0FBMUIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJBLE1BQU1ULGdCQUFOLFNBQStCbk4sS0FBL0IsQ0FBcUM7QUFLMUMyRyxhQUFXLENBQUNDLEdBQUQsRUFBYzdLLEdBQWQsRUFBNkJPLElBQTdCLEVBQXlDO0FBQ2xELFVBQU1zSyxHQUFOOztBQURrRDs7QUFBQTs7QUFBQTs7QUFFbEQsU0FBS0MsSUFBTCxHQUFZLGtCQUFaO0FBQ0EsU0FBS3pLLE1BQUwsR0FBY0wsR0FBRyxDQUFDSyxNQUFsQjtBQUNBLFNBQUtMLEdBQUwsR0FBV0EsR0FBWDtBQUNBLFNBQUtPLElBQUwsR0FBWUEsSUFBWjtBQUNEOztBQVh5QztBQWNyQyxNQUFNOFIsb0JBQU4sU0FBbUNwTyxLQUFuQyxDQUF5QztBQUM5QzJHLGFBQVcsQ0FBQ0MsR0FBRCxFQUFjO0FBQ3ZCLFVBQU1BLEdBQU47QUFDQSxTQUFLQyxJQUFMLEdBQVksc0JBQVo7QUFDRDs7QUFKNkMsQzs7Ozs7Ozs7Ozs7Ozs7O0FDWmpDLFNBQVN3SCxlQUFULENBQ2IxQixHQURhLEVBRWI1USxHQUZhLEVBR2J1UyxjQUhhLEVBSWI7QUFDQSxRQUFNQyxPQUFPLEdBQUdELGNBQWMsQ0FBQy9HLFFBQWYsQ0FBd0IsU0FBeEIsSUFDWitHLGNBRFksR0FFWixDQUFDLEdBQUdBLGNBQUosRUFBb0IsU0FBcEIsQ0FGSjs7QUFJQSxNQUFJLENBQUMzQixHQUFHLENBQUNoUSxNQUFMLElBQWUsQ0FBQzRSLE9BQU8sQ0FBQ2hILFFBQVIsQ0FBaUJvRixHQUFHLENBQUNoUSxNQUFyQixDQUFwQixFQUFrRDtBQUNoRFosT0FBRyxDQUFDSyxNQUFKLENBQVcsR0FBWDtBQUNBTCxPQUFHLENBQUNvQixTQUFKLENBQWMsT0FBZCxFQUF1Qm9SLE9BQU8sQ0FBQ0MsSUFBUixDQUFhLElBQWIsQ0FBdkI7QUFDQXpTLE9BQUcsQ0FBQzBTLEdBQUo7QUFDQSxXQUFPLEtBQVA7QUFDRDs7QUFFRCxNQUFJOUIsR0FBRyxDQUFDaFEsTUFBSixLQUFlLFNBQW5CLEVBQThCO0FBQzVCWixPQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYO0FBQ0FMLE9BQUcsQ0FBQ29CLFNBQUosQ0FBYyxPQUFkLEVBQXVCb1IsT0FBTyxDQUFDQyxJQUFSLENBQWEsSUFBYixDQUF2QjtBQUNBelMsT0FBRyxDQUFDb0IsU0FBSixDQUFjLGdCQUFkLEVBQWdDLEdBQWhDO0FBQ0FwQixPQUFHLENBQUMwUyxHQUFKO0FBQ0EsV0FBTyxLQUFQO0FBQ0Q7O0FBRUQsU0FBTyxJQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7OztBQzVCRDtBQUdlLFNBQVM3QixrQkFBVCxDQUNiRCxHQURhLEVBRWI1USxHQUZhLEVBR2IyUyxpQkFIYSxFQUliO0FBQ0EsUUFBTUgsT0FBTyxHQUFHakIsTUFBTSxDQUFDcUIsSUFBUCxDQUFZRCxpQkFBWixDQUFoQjtBQUNBLFFBQU1KLGNBQWMsR0FBR0MsT0FBTyxDQUFDN0osTUFBUixDQUErQixDQUFDa0ssR0FBRCxFQUFNalMsTUFBTixLQUFpQjtBQUNyRSxRQUFJK1IsaUJBQWlCLENBQUMvUixNQUFELENBQXJCLEVBQStCO0FBQzdCaVMsU0FBRyxDQUFDQyxJQUFKLENBQVNsUyxNQUFUO0FBQ0Q7O0FBQ0QsV0FBT2lTLEdBQVA7QUFDRCxHQUxzQixFQUtwQixFQUxvQixDQUF2QjtBQU9BLFNBQU9QLDJEQUFlLENBQUMxQixHQUFELEVBQU01USxHQUFOLEVBQVd1UyxjQUFYLENBQXRCO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOTSxNQUFNUSxhQUFOLFNBQTRCOU8sS0FBNUIsQ0FBa0M7QUFJdkMyRyxhQUFXLENBQUM7QUFBRW5LLFdBQUY7QUFBV3VTLFFBQVg7QUFBaUJ4UztBQUFqQixHQUFELEVBQXdDO0FBQ2pELFVBQU1vQixLQUFnQixHQUFHbkIsT0FBTztBQUMxQkE7QUFEMEIsT0FDYnVTLElBQUksR0FBRztBQUFFQTtBQUFGLEtBQUgsR0FBYyxFQURMLElBRTVCeFMsTUFBTSxDQUFFLENBQUYsQ0FGVjtBQUlBLFVBQU1vQixLQUFLLENBQUNuQixPQUFaOztBQUxpRDs7QUFBQTs7QUFNakQsU0FBS0QsTUFBTCxHQUFjQyxPQUFPLEdBQUcsQ0FBQ21CLEtBQUQsQ0FBSCxHQUFhcEIsTUFBbEM7QUFFQSxRQUFJb0IsS0FBSyxDQUFDb1IsSUFBVixFQUFnQixLQUFLQSxJQUFMLEdBQVlwUixLQUFLLENBQUNvUixJQUFsQjtBQUNqQjs7QUFic0MsQyxDQWdCekM7O0FBQ08sTUFBTUMsZUFBTixTQUE4QkYsYUFBOUIsQ0FBNEM7QUFDakRuSSxhQUFXLENBQUNqSyxPQUFELEVBQXNCO0FBQy9CLFVBQU1BLE9BQU47QUFDQSxTQUFLcVMsSUFBTCxHQUFZLGtCQUFaO0FBQ0Q7O0FBSmdEO0FBTzVDLE1BQU03SCxZQUFOLFNBQTJCNEgsYUFBM0IsQ0FBeUM7QUFHOUNuSSxhQUFXLENBQ1RqSyxPQURTLEVBSVQ7QUFDQSxVQUFNQSxPQUFOOztBQURBOztBQUVBLFNBQUtOLE1BQUwsR0FBY00sT0FBTyxDQUFDTixNQUF0QjtBQUNEOztBQVY2QyxDOzs7Ozs7Ozs7Ozs7O0FDcENoRDtBQUVBLCtEQUFlb0UsOERBQWMsRUFBN0IsRTs7Ozs7Ozs7Ozs7Ozs7QUNGQTtBQUNBO0FBRUEsK0RBQWV4QyxzRUFBTyxDQUFDK0Qsc0RBQUQsQ0FBdEIsRTs7Ozs7Ozs7Ozs7QUNIQSwyQzs7Ozs7Ozs7Ozs7QUNBQSxvQzs7Ozs7Ozs7Ozs7QUNBQSxpRCIsImZpbGUiOiJwYWdlcy9hcGkvY2FydC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG5vcm1hbGl6ZUNhcnQgfSBmcm9tICcuLi8uLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5pbXBvcnQgeyBwYXJzZUNhcnRJdGVtIH0gZnJvbSAnLi4vLi4vdXRpbHMvcGFyc2UtaXRlbSdcclxuaW1wb3J0IGdldENhcnRDb29raWUgZnJvbSAnLi4vLi4vdXRpbHMvZ2V0LWNhcnQtY29va2llJ1xyXG5pbXBvcnQgdHlwZSB7IENhcnRFbmRwb2ludCB9IGZyb20gJy4nXHJcblxyXG5jb25zdCBhZGRJdGVtOiBDYXJ0RW5kcG9pbnRbJ2hhbmRsZXJzJ11bJ2FkZEl0ZW0nXSA9IGFzeW5jICh7XHJcbiAgcmVzLFxyXG4gIGJvZHk6IHsgY2FydElkLCBpdGVtIH0sXHJcbiAgY29uZmlnLFxyXG59KSA9PiB7XHJcbiAgaWYgKCFpdGVtKSB7XHJcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oe1xyXG4gICAgICBkYXRhOiBudWxsLFxyXG4gICAgICBlcnJvcnM6IFt7IG1lc3NhZ2U6ICdNaXNzaW5nIGl0ZW0nIH1dLFxyXG4gICAgfSlcclxuICB9XHJcbiAgaWYgKCFpdGVtLnF1YW50aXR5KSBpdGVtLnF1YW50aXR5ID0gMVxyXG5cclxuICBjb25zdCBvcHRpb25zID0ge1xyXG4gICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgIGxpbmVfaXRlbXM6IFtwYXJzZUNhcnRJdGVtKGl0ZW0pXSxcclxuICAgICAgLi4uKCFjYXJ0SWQgJiYgY29uZmlnLnN0b3JlQ2hhbm5lbElkXHJcbiAgICAgICAgPyB7IGNoYW5uZWxfaWQ6IGNvbmZpZy5zdG9yZUNoYW5uZWxJZCB9XHJcbiAgICAgICAgOiB7fSksXHJcbiAgICB9KSxcclxuICB9XHJcbiAgY29uc3QgeyBkYXRhIH0gPSBjYXJ0SWRcclxuICAgID8gYXdhaXQgY29uZmlnLnN0b3JlQXBpRmV0Y2goXHJcbiAgICAgICAgYC92My9jYXJ0cy8ke2NhcnRJZH0vaXRlbXM/aW5jbHVkZT1saW5lX2l0ZW1zLnBoeXNpY2FsX2l0ZW1zLm9wdGlvbnNgLFxyXG4gICAgICAgIG9wdGlvbnNcclxuICAgICAgKVxyXG4gICAgOiBhd2FpdCBjb25maWcuc3RvcmVBcGlGZXRjaChcclxuICAgICAgICAnL3YzL2NhcnRzP2luY2x1ZGU9bGluZV9pdGVtcy5waHlzaWNhbF9pdGVtcy5vcHRpb25zJyxcclxuICAgICAgICBvcHRpb25zXHJcbiAgICAgIClcclxuXHJcbiAgLy8gQ3JlYXRlIG9yIHVwZGF0ZSB0aGUgY2FydCBjb29raWVcclxuICByZXMuc2V0SGVhZGVyKFxyXG4gICAgJ1NldC1Db29raWUnLFxyXG4gICAgZ2V0Q2FydENvb2tpZShjb25maWcuY2FydENvb2tpZSwgZGF0YS5pZCwgY29uZmlnLmNhcnRDb29raWVNYXhBZ2UpXHJcbiAgKVxyXG4gIHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgZGF0YTogbm9ybWFsaXplQ2FydChkYXRhKSB9KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhZGRJdGVtXHJcbiIsImltcG9ydCB7IG5vcm1hbGl6ZUNhcnQgfSBmcm9tICcuLi8uLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5pbXBvcnQgeyBCaWdjb21tZXJjZUFwaUVycm9yIH0gZnJvbSAnLi4vLi4vdXRpbHMvZXJyb3JzJ1xyXG5pbXBvcnQgZ2V0Q2FydENvb2tpZSBmcm9tICcuLi8uLi91dGlscy9nZXQtY2FydC1jb29raWUnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDYXJ0IH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvY2FydCdcclxuaW1wb3J0IHR5cGUgeyBDYXJ0RW5kcG9pbnQgfSBmcm9tICcuJ1xyXG5cclxuLy8gUmV0dXJuIGN1cnJlbnQgY2FydCBpbmZvXHJcbmNvbnN0IGdldENhcnQ6IENhcnRFbmRwb2ludFsnaGFuZGxlcnMnXVsnZ2V0Q2FydCddID0gYXN5bmMgKHtcclxuICByZXMsXHJcbiAgYm9keTogeyBjYXJ0SWQgfSxcclxuICBjb25maWcsXHJcbn0pID0+IHtcclxuICBsZXQgcmVzdWx0OiB7IGRhdGE/OiBCaWdjb21tZXJjZUNhcnQgfSA9IHt9XHJcblxyXG4gIGlmIChjYXJ0SWQpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHJlc3VsdCA9IGF3YWl0IGNvbmZpZy5zdG9yZUFwaUZldGNoKFxyXG4gICAgICAgIGAvdjMvY2FydHMvJHtjYXJ0SWR9P2luY2x1ZGU9bGluZV9pdGVtcy5waHlzaWNhbF9pdGVtcy5vcHRpb25zYFxyXG4gICAgICApXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBCaWdjb21tZXJjZUFwaUVycm9yICYmIGVycm9yLnN0YXR1cyA9PT0gNDA0KSB7XHJcbiAgICAgICAgLy8gUmVtb3ZlIHRoZSBjb29raWUgaWYgaXQgZXhpc3RzIGJ1dCB0aGUgY2FydCB3YXNuJ3QgZm91bmRcclxuICAgICAgICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgZ2V0Q2FydENvb2tpZShjb25maWcuY2FydENvb2tpZSkpXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhyb3cgZXJyb3JcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oe1xyXG4gICAgZGF0YTogcmVzdWx0LmRhdGEgPyBub3JtYWxpemVDYXJ0KHJlc3VsdC5kYXRhKSA6IG51bGwsXHJcbiAgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZ2V0Q2FydFxyXG4iLCJpbXBvcnQgeyBHZXRBUElTY2hlbWEsIGNyZWF0ZUVuZHBvaW50IH0gZnJvbSAnQGNvbW1lcmNlL2FwaSdcclxuaW1wb3J0IGNhcnRFbmRwb2ludCBmcm9tICdAY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jYXJ0J1xyXG5pbXBvcnQgdHlwZSB7IENhcnRTY2hlbWEgfSBmcm9tICcuLi8uLi8uLi90eXBlcy9jYXJ0J1xyXG5pbXBvcnQgdHlwZSB7IEJpZ2NvbW1lcmNlQVBJIH0gZnJvbSAnLi4vLi4nXHJcbmltcG9ydCBnZXRDYXJ0IGZyb20gJy4vZ2V0LWNhcnQnXHJcbmltcG9ydCBhZGRJdGVtIGZyb20gJy4vYWRkLWl0ZW0nXHJcbmltcG9ydCB1cGRhdGVJdGVtIGZyb20gJy4vdXBkYXRlLWl0ZW0nXHJcbmltcG9ydCByZW1vdmVJdGVtIGZyb20gJy4vcmVtb3ZlLWl0ZW0nXHJcblxyXG5leHBvcnQgdHlwZSBDYXJ0QVBJID0gR2V0QVBJU2NoZW1hPEJpZ2NvbW1lcmNlQVBJLCBDYXJ0U2NoZW1hPlxyXG5cclxuZXhwb3J0IHR5cGUgQ2FydEVuZHBvaW50ID0gQ2FydEFQSVsnZW5kcG9pbnQnXVxyXG5cclxuZXhwb3J0IGNvbnN0IGhhbmRsZXJzOiBDYXJ0RW5kcG9pbnRbJ2hhbmRsZXJzJ10gPSB7XHJcbiAgZ2V0Q2FydCxcclxuICBhZGRJdGVtLFxyXG4gIHVwZGF0ZUl0ZW0sXHJcbiAgcmVtb3ZlSXRlbSxcclxufVxyXG5cclxuY29uc3QgY2FydEFwaSA9IGNyZWF0ZUVuZHBvaW50PENhcnRBUEk+KHtcclxuICBoYW5kbGVyOiBjYXJ0RW5kcG9pbnQsXHJcbiAgaGFuZGxlcnMsXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjYXJ0QXBpXHJcbiIsImltcG9ydCB7IG5vcm1hbGl6ZUNhcnQgfSBmcm9tICcuLi8uLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5pbXBvcnQgZ2V0Q2FydENvb2tpZSBmcm9tICcuLi8uLi91dGlscy9nZXQtY2FydC1jb29raWUnXHJcbmltcG9ydCB0eXBlIHsgQ2FydEVuZHBvaW50IH0gZnJvbSAnLidcclxuXHJcbmNvbnN0IHJlbW92ZUl0ZW06IENhcnRFbmRwb2ludFsnaGFuZGxlcnMnXVsncmVtb3ZlSXRlbSddID0gYXN5bmMgKHtcclxuICByZXMsXHJcbiAgYm9keTogeyBjYXJ0SWQsIGl0ZW1JZCB9LFxyXG4gIGNvbmZpZyxcclxufSkgPT4ge1xyXG4gIGlmICghY2FydElkIHx8ICFpdGVtSWQpIHtcclxuICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7XHJcbiAgICAgIGRhdGE6IG51bGwsXHJcbiAgICAgIGVycm9yczogW3sgbWVzc2FnZTogJ0ludmFsaWQgcmVxdWVzdCcgfV0sXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY29uZmlnLnN0b3JlQXBpRmV0Y2g8eyBkYXRhOiBhbnkgfSB8IG51bGw+KFxyXG4gICAgYC92My9jYXJ0cy8ke2NhcnRJZH0vaXRlbXMvJHtpdGVtSWR9P2luY2x1ZGU9bGluZV9pdGVtcy5waHlzaWNhbF9pdGVtcy5vcHRpb25zYCxcclxuICAgIHsgbWV0aG9kOiAnREVMRVRFJyB9XHJcbiAgKVxyXG4gIGNvbnN0IGRhdGEgPSByZXN1bHQ/LmRhdGEgPz8gbnVsbFxyXG5cclxuICByZXMuc2V0SGVhZGVyKFxyXG4gICAgJ1NldC1Db29raWUnLFxyXG4gICAgZGF0YVxyXG4gICAgICA/IC8vIFVwZGF0ZSB0aGUgY2FydCBjb29raWVcclxuICAgICAgICBnZXRDYXJ0Q29va2llKGNvbmZpZy5jYXJ0Q29va2llLCBjYXJ0SWQsIGNvbmZpZy5jYXJ0Q29va2llTWF4QWdlKVxyXG4gICAgICA6IC8vIFJlbW92ZSB0aGUgY2FydCBjb29raWUgaWYgdGhlIGNhcnQgd2FzIHJlbW92ZWQgKGVtcHR5IGl0ZW1zKVxyXG4gICAgICAgIGdldENhcnRDb29raWUoY29uZmlnLmNhcnRDb29raWUpXHJcbiAgKVxyXG4gIHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgZGF0YTogZGF0YSAmJiBub3JtYWxpemVDYXJ0KGRhdGEpIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJlbW92ZUl0ZW1cclxuIiwiaW1wb3J0IHsgbm9ybWFsaXplQ2FydCB9IGZyb20gJy4uLy4uLy4uL2xpYi9ub3JtYWxpemUnXHJcbmltcG9ydCB7IHBhcnNlQ2FydEl0ZW0gfSBmcm9tICcuLi8uLi91dGlscy9wYXJzZS1pdGVtJ1xyXG5pbXBvcnQgZ2V0Q2FydENvb2tpZSBmcm9tICcuLi8uLi91dGlscy9nZXQtY2FydC1jb29raWUnXHJcbmltcG9ydCB0eXBlIHsgQ2FydEVuZHBvaW50IH0gZnJvbSAnLidcclxuXHJcbmNvbnN0IHVwZGF0ZUl0ZW06IENhcnRFbmRwb2ludFsnaGFuZGxlcnMnXVsndXBkYXRlSXRlbSddID0gYXN5bmMgKHtcclxuICByZXMsXHJcbiAgYm9keTogeyBjYXJ0SWQsIGl0ZW1JZCwgaXRlbSB9LFxyXG4gIGNvbmZpZyxcclxufSkgPT4ge1xyXG4gIGlmICghY2FydElkIHx8ICFpdGVtSWQgfHwgIWl0ZW0pIHtcclxuICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7XHJcbiAgICAgIGRhdGE6IG51bGwsXHJcbiAgICAgIGVycm9yczogW3sgbWVzc2FnZTogJ0ludmFsaWQgcmVxdWVzdCcgfV0sXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBjb25maWcuc3RvcmVBcGlGZXRjaChcclxuICAgIGAvdjMvY2FydHMvJHtjYXJ0SWR9L2l0ZW1zLyR7aXRlbUlkfT9pbmNsdWRlPWxpbmVfaXRlbXMucGh5c2ljYWxfaXRlbXMub3B0aW9uc2AsXHJcbiAgICB7XHJcbiAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBsaW5lX2l0ZW06IHBhcnNlQ2FydEl0ZW0oaXRlbSksXHJcbiAgICAgIH0pLFxyXG4gICAgfVxyXG4gIClcclxuXHJcbiAgLy8gVXBkYXRlIHRoZSBjYXJ0IGNvb2tpZVxyXG4gIHJlcy5zZXRIZWFkZXIoXHJcbiAgICAnU2V0LUNvb2tpZScsXHJcbiAgICBnZXRDYXJ0Q29va2llKGNvbmZpZy5jYXJ0Q29va2llLCBjYXJ0SWQsIGNvbmZpZy5jYXJ0Q29va2llTWF4QWdlKVxyXG4gIClcclxuICByZXMuc3RhdHVzKDIwMCkuanNvbih7IGRhdGE6IG5vcm1hbGl6ZUNhcnQoZGF0YSkgfSlcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXBkYXRlSXRlbVxyXG4iLCJleHBvcnQgY29uc3QgY2F0ZWdvcnlUcmVlSXRlbUZyYWdtZW50ID0gLyogR3JhcGhRTCAqLyBgXHJcbiAgZnJhZ21lbnQgY2F0ZWdvcnlUcmVlSXRlbSBvbiBDYXRlZ29yeVRyZWVJdGVtIHtcclxuICAgIGVudGl0eUlkXHJcbiAgICBuYW1lXHJcbiAgICBwYXRoXHJcbiAgICBkZXNjcmlwdGlvblxyXG4gICAgcHJvZHVjdENvdW50XHJcbiAgfVxyXG5gXHJcbiIsImV4cG9ydCBjb25zdCBwcm9kdWN0UHJpY2VzID0gLyogR3JhcGhRTCAqLyBgXHJcbiAgZnJhZ21lbnQgcHJvZHVjdFByaWNlcyBvbiBQcmljZXMge1xyXG4gICAgcHJpY2Uge1xyXG4gICAgICB2YWx1ZVxyXG4gICAgICBjdXJyZW5jeUNvZGVcclxuICAgIH1cclxuICAgIHNhbGVQcmljZSB7XHJcbiAgICAgIHZhbHVlXHJcbiAgICAgIGN1cnJlbmN5Q29kZVxyXG4gICAgfVxyXG4gICAgcmV0YWlsUHJpY2Uge1xyXG4gICAgICB2YWx1ZVxyXG4gICAgICBjdXJyZW5jeUNvZGVcclxuICAgIH1cclxuICB9XHJcbmBcclxuXHJcbmV4cG9ydCBjb25zdCBzd2F0Y2hPcHRpb25GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHN3YXRjaE9wdGlvbiBvbiBTd2F0Y2hPcHRpb25WYWx1ZSB7XHJcbiAgICBpc0RlZmF1bHRcclxuICAgIGhleENvbG9yc1xyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IG11bHRpcGxlQ2hvaWNlT3B0aW9uRnJhZ21lbnQgPSAvKiBHcmFwaFFMICovIGBcclxuICBmcmFnbWVudCBtdWx0aXBsZUNob2ljZU9wdGlvbiBvbiBNdWx0aXBsZUNob2ljZU9wdGlvbiB7XHJcbiAgICB2YWx1ZXMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBsYWJlbFxyXG4gICAgICAgICAgLi4uc3dhdGNoT3B0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3N3YXRjaE9wdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdEluZm9GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHByb2R1Y3RJbmZvIG9uIFByb2R1Y3Qge1xyXG4gICAgZW50aXR5SWRcclxuICAgIG5hbWVcclxuICAgIHBhdGhcclxuICAgIGJyYW5kIHtcclxuICAgICAgZW50aXR5SWRcclxuICAgIH1cclxuICAgIGRlc2NyaXB0aW9uXHJcbiAgICBwcmljZXMge1xyXG4gICAgICAuLi5wcm9kdWN0UHJpY2VzXHJcbiAgICB9XHJcbiAgICBpbWFnZXMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgYWx0VGV4dFxyXG4gICAgICAgICAgaXNEZWZhdWx0XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB2YXJpYW50cyB7XHJcbiAgICAgIGVkZ2VzIHtcclxuICAgICAgICBub2RlIHtcclxuICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICBkZWZhdWx0SW1hZ2Uge1xyXG4gICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICBhbHRUZXh0XHJcbiAgICAgICAgICAgIGlzRGVmYXVsdFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHJvZHVjdE9wdGlvbnMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICBlbnRpdHlJZFxyXG4gICAgICAgICAgZGlzcGxheU5hbWVcclxuICAgICAgICAgIC4uLm11bHRpcGxlQ2hvaWNlT3B0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBsb2NhbGVNZXRhOiBtZXRhZmllbGRzKG5hbWVzcGFjZTogJGxvY2FsZSwga2V5czogW1wibmFtZVwiLCBcImRlc2NyaXB0aW9uXCJdKVxyXG4gICAgICBAaW5jbHVkZShpZjogJGhhc0xvY2FsZSkge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBrZXlcclxuICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3Byb2R1Y3RQcmljZXN9XHJcbiAgJHttdWx0aXBsZUNob2ljZU9wdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdENvbm5lY3Rpb25GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHByb2R1Y3RDb25ubmVjdGlvbiBvbiBQcm9kdWN0Q29ubmVjdGlvbiB7XHJcbiAgICBwYWdlSW5mbyB7XHJcbiAgICAgIHN0YXJ0Q3Vyc29yXHJcbiAgICAgIGVuZEN1cnNvclxyXG4gICAgfVxyXG4gICAgZWRnZXMge1xyXG4gICAgICBjdXJzb3JcclxuICAgICAgbm9kZSB7XHJcbiAgICAgICAgLi4ucHJvZHVjdEluZm9cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJHtwcm9kdWN0SW5mb0ZyYWdtZW50fVxyXG5gXHJcbiIsImltcG9ydCB0eXBlIHsgUmVxdWVzdEluaXQgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5pbXBvcnQge1xyXG4gIENvbW1lcmNlQVBJLFxyXG4gIENvbW1lcmNlQVBJQ29uZmlnLFxyXG4gIGdldENvbW1lcmNlQXBpIGFzIGNvbW1lcmNlQXBpLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGknXHJcbmltcG9ydCBjcmVhdGVGZXRjaEdyYXBocWxBcGkgZnJvbSAnLi91dGlscy9mZXRjaC1ncmFwaHFsLWFwaSdcclxuaW1wb3J0IGNyZWF0ZUZldGNoU3RvcmVBcGkgZnJvbSAnLi91dGlscy9mZXRjaC1zdG9yZS1hcGknXHJcblxyXG5pbXBvcnQgdHlwZSB7IENhcnRBUEkgfSBmcm9tICcuL2VuZHBvaW50cy9jYXJ0J1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvY3VzdG9tZXInXHJcbmltcG9ydCB0eXBlIHsgTG9naW5BUEkgfSBmcm9tICcuL2VuZHBvaW50cy9sb2dpbidcclxuaW1wb3J0IHR5cGUgeyBMb2dvdXRBUEkgfSBmcm9tICcuL2VuZHBvaW50cy9sb2dvdXQnXHJcbmltcG9ydCB0eXBlIHsgU2lnbnVwQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvc2lnbnVwJ1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3RzQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvY2F0YWxvZy9wcm9kdWN0cydcclxuaW1wb3J0IHR5cGUgeyBXaXNobGlzdEFQSSB9IGZyb20gJy4vZW5kcG9pbnRzL3dpc2hsaXN0J1xyXG5cclxuaW1wb3J0IGxvZ2luIGZyb20gJy4vb3BlcmF0aW9ucy9sb2dpbidcclxuaW1wb3J0IGdldEFsbFBhZ2VzIGZyb20gJy4vb3BlcmF0aW9ucy9nZXQtYWxsLXBhZ2VzJ1xyXG5pbXBvcnQgZ2V0UGFnZSBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LXBhZ2UnXHJcbmltcG9ydCBnZXRTaXRlSW5mbyBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LXNpdGUtaW5mbydcclxuaW1wb3J0IGdldEN1c3RvbWVyV2lzaGxpc3QgZnJvbSAnLi9vcGVyYXRpb25zL2dldC1jdXN0b21lci13aXNobGlzdCdcclxuaW1wb3J0IGdldEFsbFByb2R1Y3RQYXRocyBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LWFsbC1wcm9kdWN0LXBhdGhzJ1xyXG5pbXBvcnQgZ2V0QWxsUHJvZHVjdHMgZnJvbSAnLi9vcGVyYXRpb25zL2dldC1hbGwtcHJvZHVjdHMnXHJcbmltcG9ydCBnZXRQcm9kdWN0IGZyb20gJy4vb3BlcmF0aW9ucy9nZXQtcHJvZHVjdCdcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQmlnY29tbWVyY2VDb25maWcgZXh0ZW5kcyBDb21tZXJjZUFQSUNvbmZpZyB7XHJcbiAgLy8gSW5kaWNhdGVzIGlmIHRoZSByZXR1cm5lZCBtZXRhZGF0YSB3aXRoIHRyYW5zbGF0aW9ucyBzaG91bGQgYmUgYXBwbGllZCB0byB0aGVcclxuICAvLyBkYXRhIG9yIHJldHVybmVkIGFzIGl0IGlzXHJcbiAgYXBwbHlMb2NhbGU/OiBib29sZWFuXHJcbiAgc3RvcmVBcGlVcmw6IHN0cmluZ1xyXG4gIHN0b3JlQXBpVG9rZW46IHN0cmluZ1xyXG4gIHN0b3JlQXBpQ2xpZW50SWQ6IHN0cmluZ1xyXG4gIHN0b3JlQ2hhbm5lbElkPzogc3RyaW5nXHJcbiAgc3RvcmVVcmw/OiBzdHJpbmdcclxuICBzdG9yZUFwaUNsaWVudFNlY3JldD86IHN0cmluZ1xyXG4gIHN0b3JlSGFzaD86c3RyaW5nXHJcbiAgc3RvcmVBcGlGZXRjaDxUPihlbmRwb2ludDogc3RyaW5nLCBvcHRpb25zPzogUmVxdWVzdEluaXQpOiBQcm9taXNlPFQ+XHJcbn1cclxuXHJcbmNvbnN0IEFQSV9VUkwgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9VUkxcclxuY29uc3QgQVBJX1RPS0VOID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVE9LRU5cclxuY29uc3QgU1RPUkVfQVBJX1VSTCA9IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9VUkxcclxuY29uc3QgU1RPUkVfQVBJX1RPS0VOID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOXHJcbmNvbnN0IFNUT1JFX0FQSV9DTElFTlRfSUQgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX0lEXHJcbmNvbnN0IFNUT1JFX0NIQU5ORUxfSUQgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9DSEFOTkVMX0lEXHJcbmNvbnN0IFNUT1JFX1VSTCA9IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX1NUT1JFX1VSTFxyXG5jb25zdCBDTElFTlRfU0VDUkVUID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX0NMSUVOVF9TRUNSRVRcclxuY29uc3QgU1RPUkVGUk9OVF9IQVNIID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1NUT1JFX0hBU0hcclxuXHJcbmlmICghQVBJX1VSTCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIGBUaGUgZW52aXJvbm1lbnQgdmFyaWFibGUgQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVVJMIGlzIG1pc3NpbmcgYW5kIGl0J3MgcmVxdWlyZWQgdG8gYWNjZXNzIHlvdXIgc3RvcmVgXHJcbiAgKVxyXG59XHJcblxyXG5pZiAoIUFQSV9UT0tFTikge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIGBUaGUgZW52aXJvbm1lbnQgdmFyaWFibGUgQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVE9LRU4gaXMgbWlzc2luZyBhbmQgaXQncyByZXF1aXJlZCB0byBhY2Nlc3MgeW91ciBzdG9yZWBcclxuICApXHJcbn1cclxuXHJcbmlmICghKFNUT1JFX0FQSV9VUkwgJiYgU1RPUkVfQVBJX1RPS0VOICYmIFNUT1JFX0FQSV9DTElFTlRfSUQpKSB7XHJcbiAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgYFRoZSBlbnZpcm9ubWVudCB2YXJpYWJsZXMgQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1VSTCwgQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOLCBCSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX0lEIGhhdmUgdG8gYmUgc2V0IGluIG9yZGVyIHRvIGFjY2VzcyB0aGUgUkVTVCBBUEkgb2YgeW91ciBzdG9yZWBcclxuICApXHJcbn1cclxuXHJcbmNvbnN0IE9ORV9EQVkgPSA2MCAqIDYwICogMjRcclxuXHJcbmNvbnN0IGNvbmZpZzogQmlnY29tbWVyY2VDb25maWcgPSB7XHJcbiAgY29tbWVyY2VVcmw6IEFQSV9VUkwsXHJcbiAgYXBpVG9rZW46IEFQSV9UT0tFTixcclxuICBjdXN0b21lckNvb2tpZTogJ1NIT1BfVE9LRU4nLFxyXG4gIGNhcnRDb29raWU6IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX0NBUlRfQ09PS0lFID8/ICdiY19jYXJ0SWQnLFxyXG4gIGNhcnRDb29raWVNYXhBZ2U6IE9ORV9EQVkgKiAzMCxcclxuICBmZXRjaDogY3JlYXRlRmV0Y2hHcmFwaHFsQXBpKCgpID0+IGdldENvbW1lcmNlQXBpKCkuZ2V0Q29uZmlnKCkpLFxyXG4gIGFwcGx5TG9jYWxlOiB0cnVlLFxyXG4gIC8vIFJFU1QgQVBJIG9ubHlcclxuICBzdG9yZUFwaVVybDogU1RPUkVfQVBJX1VSTCxcclxuICBzdG9yZUFwaVRva2VuOiBTVE9SRV9BUElfVE9LRU4sXHJcbiAgc3RvcmVBcGlDbGllbnRJZDogU1RPUkVfQVBJX0NMSUVOVF9JRCxcclxuICBzdG9yZUNoYW5uZWxJZDogU1RPUkVfQ0hBTk5FTF9JRCxcclxuICBzdG9yZVVybDpTVE9SRV9VUkwsXHJcbiAgc3RvcmVBcGlDbGllbnRTZWNyZXQ6Q0xJRU5UX1NFQ1JFVCxcclxuICBzdG9yZUhhc2g6IFNUT1JFRlJPTlRfSEFTSCxcclxuICBzdG9yZUFwaUZldGNoOiBjcmVhdGVGZXRjaFN0b3JlQXBpKCgpID0+IGdldENvbW1lcmNlQXBpKCkuZ2V0Q29uZmlnKCkpLFxyXG59XHJcblxyXG5jb25zdCBvcGVyYXRpb25zID0ge1xyXG4gIGxvZ2luLFxyXG4gIGdldEFsbFBhZ2VzLFxyXG4gIGdldFBhZ2UsXHJcbiAgZ2V0U2l0ZUluZm8sXHJcbiAgZ2V0Q3VzdG9tZXJXaXNobGlzdCxcclxuICBnZXRBbGxQcm9kdWN0UGF0aHMsXHJcbiAgZ2V0QWxsUHJvZHVjdHMsXHJcbiAgZ2V0UHJvZHVjdCxcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHByb3ZpZGVyID0geyBjb25maWcsIG9wZXJhdGlvbnMgfVxyXG5cclxuZXhwb3J0IHR5cGUgUHJvdmlkZXIgPSB0eXBlb2YgcHJvdmlkZXJcclxuXHJcbmV4cG9ydCB0eXBlIEFQSXMgPVxyXG4gIHwgQ2FydEFQSVxyXG4gIHwgQ3VzdG9tZXJBUElcclxuICB8IExvZ2luQVBJXHJcbiAgfCBMb2dvdXRBUElcclxuICB8IFNpZ251cEFQSVxyXG4gIHwgUHJvZHVjdHNBUElcclxuICB8IFdpc2hsaXN0QVBJXHJcblxyXG5leHBvcnQgdHlwZSBCaWdjb21tZXJjZUFQSTxQIGV4dGVuZHMgUHJvdmlkZXIgPSBQcm92aWRlcj4gPSBDb21tZXJjZUFQSTxQPlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1lcmNlQXBpPFAgZXh0ZW5kcyBQcm92aWRlcj4oXHJcbiAgY3VzdG9tUHJvdmlkZXI6IFAgPSBwcm92aWRlciBhcyBhbnlcclxuKTogQmlnY29tbWVyY2VBUEk8UD4ge1xyXG4gIHJldHVybiBjb21tZXJjZUFwaShjdXN0b21Qcm92aWRlcilcclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7XHJcbiAgT3BlcmF0aW9uQ29udGV4dCxcclxuICBPcGVyYXRpb25PcHRpb25zLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGkvb3BlcmF0aW9ucydcclxuaW1wb3J0IHR5cGUgeyBQYWdlLCBHZXRBbGxQYWdlc09wZXJhdGlvbiB9IGZyb20gJy4uLy4uL3R5cGVzL3BhZ2UnXHJcbmltcG9ydCB0eXBlIHsgUmVjdXJzaXZlUGFydGlhbCwgUmVjdXJzaXZlUmVxdWlyZWQgfSBmcm9tICcuLi91dGlscy90eXBlcydcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZXRBbGxQYWdlc09wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUGFnZXM8VCBleHRlbmRzIEdldEFsbFBhZ2VzT3BlcmF0aW9uPihvcHRzPzoge1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQYWdlczxUIGV4dGVuZHMgR2V0QWxsUGFnZXNPcGVyYXRpb24+KFxyXG4gICAgb3B0czoge1xyXG4gICAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUGFnZXM8VCBleHRlbmRzIEdldEFsbFBhZ2VzT3BlcmF0aW9uPih7XHJcbiAgICBjb25maWcsXHJcbiAgICBwcmV2aWV3LFxyXG4gIH06IHtcclxuICAgIHVybD86IHN0cmluZ1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbnN0IGNmZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGB1cmxgXHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGNmZy5zdG9yZUFwaUZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPHsgZGF0YTogUGFnZVtdIH0+XHJcbiAgICA+KCcvdjMvY29udGVudC9wYWdlcycpXHJcbiAgICBjb25zdCBwYWdlcyA9IChkYXRhIGFzIFJlY3Vyc2l2ZVJlcXVpcmVkPHR5cGVvZiBkYXRhPikgPz8gW11cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBwYWdlczogcHJldmlldyA/IHBhZ2VzIDogcGFnZXMuZmlsdGVyKChwKSA9PiBwLmlzX3Zpc2libGUpLFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGdldEFsbFBhZ2VzXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHsgR2V0QWxsUHJvZHVjdFBhdGhzUXVlcnkgfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCB0eXBlIHsgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uIH0gZnJvbSAnLi4vLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgZmlsdGVyRWRnZXMgZnJvbSAnLi4vdXRpbHMvZmlsdGVyLWVkZ2VzJ1xyXG5pbXBvcnQgeyBCaWdjb21tZXJjZUNvbmZpZywgUHJvdmlkZXIgfSBmcm9tICcuLidcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRBbGxQcm9kdWN0UGF0aHNRdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldEFsbFByb2R1Y3RQYXRocygkZmlyc3Q6IEludCA9IDEwMCkge1xyXG4gICAgc2l0ZSB7XHJcbiAgICAgIHByb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIHtcclxuICAgICAgICBlZGdlcyB7XHJcbiAgICAgICAgICBub2RlIHtcclxuICAgICAgICAgICAgcGF0aFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8XHJcbiAgICBUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uXHJcbiAgPihvcHRzPzoge1xyXG4gICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbj4oe1xyXG4gICAgcXVlcnkgPSBnZXRBbGxQcm9kdWN0UGF0aHNRdWVyeSxcclxuICAgIHZhcmlhYmxlcyxcclxuICAgIGNvbmZpZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbmZpZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGBxdWVyeWBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPEdldEFsbFByb2R1Y3RQYXRoc1F1ZXJ5PlxyXG4gICAgPihxdWVyeSwgeyB2YXJpYWJsZXMgfSlcclxuICAgIGNvbnN0IHByb2R1Y3RzID0gZGF0YS5zaXRlPy5wcm9kdWN0cz8uZWRnZXNcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBwcm9kdWN0czogZmlsdGVyRWRnZXMocHJvZHVjdHMgYXMgUmVjdXJzaXZlUmVxdWlyZWQ8dHlwZW9mIHByb2R1Y3RzPikubWFwKFxyXG4gICAgICAgICh7IG5vZGUgfSkgPT4gbm9kZVxyXG4gICAgICApLFxyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gZ2V0QWxsUHJvZHVjdFBhdGhzXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHtcclxuICBHZXRBbGxQcm9kdWN0c1F1ZXJ5LFxyXG4gIEdldEFsbFByb2R1Y3RzUXVlcnlWYXJpYWJsZXMsXHJcbn0gZnJvbSAnLi4vLi4vc2NoZW1hJ1xyXG5pbXBvcnQgdHlwZSB7IEdldEFsbFByb2R1Y3RzT3BlcmF0aW9uIH0gZnJvbSAnLi4vLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgZmlsdGVyRWRnZXMgZnJvbSAnLi4vdXRpbHMvZmlsdGVyLWVkZ2VzJ1xyXG5pbXBvcnQgc2V0UHJvZHVjdExvY2FsZU1ldGEgZnJvbSAnLi4vdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEnXHJcbmltcG9ydCB7IHByb2R1Y3RDb25uZWN0aW9uRnJhZ21lbnQgfSBmcm9tICcuLi9mcmFnbWVudHMvcHJvZHVjdCdcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVByb2R1Y3QgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldEFsbFByb2R1Y3RzUXVlcnkgPSAvKiBHcmFwaFFMICovIGBcclxuICBxdWVyeSBnZXRBbGxQcm9kdWN0cyhcclxuICAgICRoYXNMb2NhbGU6IEJvb2xlYW4gPSBmYWxzZVxyXG4gICAgJGxvY2FsZTogU3RyaW5nID0gXCJudWxsXCJcclxuICAgICRlbnRpdHlJZHM6IFtJbnQhXVxyXG4gICAgJGZpcnN0OiBJbnQgPSAxMFxyXG4gICAgJHByb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRmZWF0dXJlZFByb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRiZXN0U2VsbGluZ1Byb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRuZXdlc3RQcm9kdWN0czogQm9vbGVhbiA9IGZhbHNlXHJcbiAgKSB7XHJcbiAgICBzaXRlIHtcclxuICAgICAgcHJvZHVjdHMoZmlyc3Q6ICRmaXJzdCwgZW50aXR5SWRzOiAkZW50aXR5SWRzKSBAaW5jbHVkZShpZjogJHByb2R1Y3RzKSB7XHJcbiAgICAgICAgLi4ucHJvZHVjdENvbm5uZWN0aW9uXHJcbiAgICAgIH1cclxuICAgICAgZmVhdHVyZWRQcm9kdWN0cyhmaXJzdDogJGZpcnN0KSBAaW5jbHVkZShpZjogJGZlYXR1cmVkUHJvZHVjdHMpIHtcclxuICAgICAgICAuLi5wcm9kdWN0Q29ubm5lY3Rpb25cclxuICAgICAgfVxyXG4gICAgICBiZXN0U2VsbGluZ1Byb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIEBpbmNsdWRlKGlmOiAkYmVzdFNlbGxpbmdQcm9kdWN0cykge1xyXG4gICAgICAgIC4uLnByb2R1Y3RDb25ubmVjdGlvblxyXG4gICAgICB9XHJcbiAgICAgIG5ld2VzdFByb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIEBpbmNsdWRlKGlmOiAkbmV3ZXN0UHJvZHVjdHMpIHtcclxuICAgICAgICAuLi5wcm9kdWN0Q29ubm5lY3Rpb25cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJHtwcm9kdWN0Q29ubmVjdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgdHlwZSBQcm9kdWN0RWRnZSA9IE5vbk51bGxhYmxlPFxyXG4gIE5vbk51bGxhYmxlPEdldEFsbFByb2R1Y3RzUXVlcnlbJ3NpdGUnXVsncHJvZHVjdHMnXVsnZWRnZXMnXT5bMF1cclxuPlxyXG5cclxuZXhwb3J0IHR5cGUgUHJvZHVjdE5vZGUgPSBQcm9kdWN0RWRnZVsnbm9kZSddXHJcblxyXG5leHBvcnQgdHlwZSBHZXRBbGxQcm9kdWN0c1Jlc3VsdDxcclxuICBUIGV4dGVuZHMgUmVjb3JkPGtleW9mIEdldEFsbFByb2R1Y3RzUmVzdWx0LCBhbnlbXT4gPSB7XHJcbiAgICBwcm9kdWN0czogUHJvZHVjdEVkZ2VbXVxyXG4gIH1cclxuPiA9IFRcclxuXHJcbmZ1bmN0aW9uIGdldFByb2R1Y3RzVHlwZShcclxuICByZWxldmFuY2U/OiBHZXRBbGxQcm9kdWN0c09wZXJhdGlvblsndmFyaWFibGVzJ11bJ3JlbGV2YW5jZSddXHJcbikge1xyXG4gIHN3aXRjaCAocmVsZXZhbmNlKSB7XHJcbiAgICBjYXNlICdmZWF0dXJlZCc6XHJcbiAgICAgIHJldHVybiAnZmVhdHVyZWRQcm9kdWN0cydcclxuICAgIGNhc2UgJ2Jlc3Rfc2VsbGluZyc6XHJcbiAgICAgIHJldHVybiAnYmVzdFNlbGxpbmdQcm9kdWN0cydcclxuICAgIGNhc2UgJ25ld2VzdCc6XHJcbiAgICAgIHJldHVybiAnbmV3ZXN0UHJvZHVjdHMnXHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gJ3Byb2R1Y3RzJ1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdHNPcGVyYXRpb24oe1xyXG4gIGNvbW1lcmNlLFxyXG59OiBPcGVyYXRpb25Db250ZXh0PFByb3ZpZGVyPikge1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFByb2R1Y3RzPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbj4ob3B0cz86IHtcclxuICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFByb2R1Y3RzPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0czxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdHNPcGVyYXRpb24+KHtcclxuICAgIHF1ZXJ5ID0gZ2V0QWxsUHJvZHVjdHNRdWVyeSxcclxuICAgIHZhcmlhYmxlczogdmFycyA9IHt9LFxyXG4gICAgY29uZmlnOiBjZmcsXHJcbiAgfToge1xyXG4gICAgcXVlcnk/OiBzdHJpbmdcclxuICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9ID0ge30pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uc3QgY29uZmlnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNmZylcclxuICAgIGNvbnN0IHsgbG9jYWxlIH0gPSBjb25maWdcclxuICAgIGNvbnN0IGZpZWxkID0gZ2V0UHJvZHVjdHNUeXBlKHZhcnMucmVsZXZhbmNlKVxyXG4gICAgY29uc3QgdmFyaWFibGVzOiBHZXRBbGxQcm9kdWN0c1F1ZXJ5VmFyaWFibGVzID0ge1xyXG4gICAgICBsb2NhbGUsXHJcbiAgICAgIGhhc0xvY2FsZTogISFsb2NhbGUsXHJcbiAgICB9XHJcblxyXG4gICAgdmFyaWFibGVzW2ZpZWxkXSA9IHRydWVcclxuXHJcbiAgICBpZiAodmFycy5maXJzdCkgdmFyaWFibGVzLmZpcnN0ID0gdmFycy5maXJzdFxyXG4gICAgaWYgKHZhcnMuaWRzKSB2YXJpYWJsZXMuZW50aXR5SWRzID0gdmFycy5pZHMubWFwKChpZCkgPT4gTnVtYmVyKGlkKSlcclxuXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGBxdWVyeWBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFJlY3Vyc2l2ZVBhcnRpYWw8R2V0QWxsUHJvZHVjdHNRdWVyeT4+KFxyXG4gICAgICBxdWVyeSxcclxuICAgICAgeyB2YXJpYWJsZXMgfVxyXG4gICAgKVxyXG4gICAgY29uc3QgZWRnZXMgPSBkYXRhLnNpdGU/LltmaWVsZF0/LmVkZ2VzXHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGZpbHRlckVkZ2VzKGVkZ2VzIGFzIFJlY3Vyc2l2ZVJlcXVpcmVkPHR5cGVvZiBlZGdlcz4pXHJcblxyXG4gICAgaWYgKGxvY2FsZSAmJiBjb25maWcuYXBwbHlMb2NhbGUpIHtcclxuICAgICAgcHJvZHVjdHMuZm9yRWFjaCgocHJvZHVjdDogUmVjdXJzaXZlUGFydGlhbDxQcm9kdWN0RWRnZT4pID0+IHtcclxuICAgICAgICBpZiAocHJvZHVjdC5ub2RlKSBzZXRQcm9kdWN0TG9jYWxlTWV0YShwcm9kdWN0Lm5vZGUpXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcHJvZHVjdHM6IHByb2R1Y3RzLm1hcCgoeyBub2RlIH0pID0+IG5vcm1hbGl6ZVByb2R1Y3Qobm9kZSBhcyBhbnkpKSxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiBnZXRBbGxQcm9kdWN0c1xyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbixcclxuICBXaXNobGlzdCxcclxufSBmcm9tICcuLi8uLi90eXBlcy93aXNobGlzdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgeyBCaWdjb21tZXJjZUNvbmZpZywgUHJvdmlkZXIgfSBmcm9tICcuLidcclxuaW1wb3J0IGdldEFsbFByb2R1Y3RzLCB7IFByb2R1Y3RFZGdlIH0gZnJvbSAnLi9nZXQtYWxsLXByb2R1Y3RzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxcclxuICAgIFQgZXh0ZW5kcyBHZXRDdXN0b21lcldpc2hsaXN0T3BlcmF0aW9uXHJcbiAgPihvcHRzOiB7XHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBCaWdjb21tZXJjZUNvbmZpZ1xyXG4gICAgaW5jbHVkZVByb2R1Y3RzPzogYm9vbGVhblxyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxUIGV4dGVuZHMgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgICAgaW5jbHVkZVByb2R1Y3RzPzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxUIGV4dGVuZHMgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbj4oe1xyXG4gICAgY29uZmlnLFxyXG4gICAgdmFyaWFibGVzLFxyXG4gICAgaW5jbHVkZVByb2R1Y3RzLFxyXG4gIH06IHtcclxuICAgIHVybD86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgIGluY2x1ZGVQcm9kdWN0cz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbmZpZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcblxyXG4gICAgY29uc3QgeyBkYXRhID0gW10gfSA9IGF3YWl0IGNvbmZpZy5zdG9yZUFwaUZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPHsgZGF0YTogV2lzaGxpc3RbXSB9PlxyXG4gICAgPihgL3YzL3dpc2hsaXN0cz9jdXN0b21lcl9pZD0ke3ZhcmlhYmxlcy5jdXN0b21lcklkfWApXHJcbiAgICBjb25zdCB3aXNobGlzdCA9IGRhdGFbMF1cclxuXHJcbiAgICBpZiAoaW5jbHVkZVByb2R1Y3RzICYmIHdpc2hsaXN0Py5pdGVtcz8ubGVuZ3RoKSB7XHJcbiAgICAgIGNvbnN0IGlkcyA9IHdpc2hsaXN0Lml0ZW1zXHJcbiAgICAgICAgPy5tYXAoKGl0ZW0pID0+IChpdGVtPy5wcm9kdWN0X2lkID8gU3RyaW5nKGl0ZW0/LnByb2R1Y3RfaWQpIDogbnVsbCkpXHJcbiAgICAgICAgLmZpbHRlcigoaWQpOiBpZCBpcyBzdHJpbmcgPT4gISFpZClcclxuXHJcbiAgICAgIGlmIChpZHM/Lmxlbmd0aCkge1xyXG4gICAgICAgIGNvbnN0IGdyYXBocWxEYXRhID0gYXdhaXQgY29tbWVyY2UuZ2V0QWxsUHJvZHVjdHMoe1xyXG4gICAgICAgICAgdmFyaWFibGVzOiB7IGZpcnN0OiA1MCwgaWRzIH0sXHJcbiAgICAgICAgICBjb25maWcsXHJcbiAgICAgICAgfSlcclxuICAgICAgICAvLyBQdXQgdGhlIHByb2R1Y3RzIGluIGFuIG9iamVjdCB0aGF0IHdlIGNhbiB1c2UgdG8gZ2V0IHRoZW0gYnkgaWRcclxuICAgICAgICBjb25zdCBwcm9kdWN0c0J5SWQgPSBncmFwaHFsRGF0YS5wcm9kdWN0cy5yZWR1Y2U8e1xyXG4gICAgICAgICAgW2s6IG51bWJlcl06IFByb2R1Y3RFZGdlXHJcbiAgICAgICAgfT4oKHByb2RzLCBwKSA9PiB7XHJcbiAgICAgICAgICBwcm9kc1tOdW1iZXIocC5pZCldID0gcCBhcyBhbnlcclxuICAgICAgICAgIHJldHVybiBwcm9kc1xyXG4gICAgICAgIH0sIHt9KVxyXG4gICAgICAgIC8vIFBvcHVsYXRlIHRoZSB3aXNobGlzdCBpdGVtcyB3aXRoIHRoZSBncmFwaHFsIHByb2R1Y3RzXHJcbiAgICAgICAgd2lzaGxpc3QuaXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcHJvZHVjdCA9IGl0ZW0gJiYgcHJvZHVjdHNCeUlkW2l0ZW0ucHJvZHVjdF9pZCFdXHJcbiAgICAgICAgICBpZiAoaXRlbSAmJiBwcm9kdWN0KSB7XHJcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgRml4IHRoaXMgdHlwZSB3aGVuIHRoZSB3aXNobGlzdCB0eXBlIGlzIHByb3Blcmx5IGRlZmluZWRcclxuICAgICAgICAgICAgaXRlbS5wcm9kdWN0ID0gcHJvZHVjdFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4geyB3aXNobGlzdDogd2lzaGxpc3QgYXMgUmVjdXJzaXZlUmVxdWlyZWQ8dHlwZW9mIHdpc2hsaXN0PiB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZ2V0Q3VzdG9tZXJXaXNobGlzdFxyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFBhZ2VPcGVyYXRpb24sIFBhZ2UgfSBmcm9tICcuLi8uLi90eXBlcy9wYWdlJ1xyXG5pbXBvcnQgdHlwZSB7IFJlY3Vyc2l2ZVBhcnRpYWwsIFJlY3Vyc2l2ZVJlcXVpcmVkIH0gZnJvbSAnLi4vdXRpbHMvdHlwZXMnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVBhZ2UgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0UGFnZU9wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UGFnZTxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRQYWdlPFQgZXh0ZW5kcyBHZXRQYWdlT3BlcmF0aW9uPihcclxuICAgIG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UGFnZTxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4oe1xyXG4gICAgdXJsLFxyXG4gICAgdmFyaWFibGVzLFxyXG4gICAgY29uZmlnLFxyXG4gICAgcHJldmlldyxcclxuICB9OiB7XHJcbiAgICB1cmw/OiBzdHJpbmdcclxuICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uc3QgY2ZnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNvbmZpZylcclxuICAgIC8vIFJlY3Vyc2l2ZVBhcnRpYWwgZm9yY2VzIHRoZSBtZXRob2QgdG8gY2hlY2sgZm9yIGV2ZXJ5IHByb3AgaW4gdGhlIGRhdGEsIHdoaWNoIGlzXHJcbiAgICAvLyByZXF1aXJlZCBpbiBjYXNlIHRoZXJlJ3MgYSBjdXN0b20gYHVybGBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY2ZnLnN0b3JlQXBpRmV0Y2g8XHJcbiAgICAgIFJlY3Vyc2l2ZVBhcnRpYWw8eyBkYXRhOiBQYWdlW10gfT5cclxuICAgID4odXJsIHx8IGAvdjMvY29udGVudC9wYWdlcz9pZD0ke3ZhcmlhYmxlcy5pZH0maW5jbHVkZT1ib2R5YClcclxuICAgIGNvbnN0IGZpcnN0UGFnZSA9IGRhdGE/LlswXVxyXG4gICAgY29uc3QgcGFnZSA9IGZpcnN0UGFnZSBhcyBSZWN1cnNpdmVSZXF1aXJlZDx0eXBlb2YgZmlyc3RQYWdlPlxyXG5cclxuICAgIGlmIChwcmV2aWV3IHx8IHBhZ2U/LmlzX3Zpc2libGUpIHtcclxuICAgICAgcmV0dXJuIHsgcGFnZTogbm9ybWFsaXplUGFnZShwYWdlIGFzIGFueSkgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHt9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZ2V0UGFnZVxyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFByb2R1Y3RPcGVyYXRpb24gfSBmcm9tICcuLi8uLi90eXBlcy9wcm9kdWN0J1xyXG5pbXBvcnQgdHlwZSB7IEdldFByb2R1Y3RRdWVyeSwgR2V0UHJvZHVjdFF1ZXJ5VmFyaWFibGVzIH0gZnJvbSAnLi4vLi4vc2NoZW1hJ1xyXG5pbXBvcnQgc2V0UHJvZHVjdExvY2FsZU1ldGEgZnJvbSAnLi4vdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEnXHJcbmltcG9ydCB7IHByb2R1Y3RJbmZvRnJhZ21lbnQgfSBmcm9tICcuLi9mcmFnbWVudHMvcHJvZHVjdCdcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVByb2R1Y3QgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldFByb2R1Y3RRdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldFByb2R1Y3QoXHJcbiAgICAkaGFzTG9jYWxlOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRsb2NhbGU6IFN0cmluZyA9IFwibnVsbFwiXHJcbiAgICAkcGF0aDogU3RyaW5nIVxyXG4gICkge1xyXG4gICAgc2l0ZSB7XHJcbiAgICAgIHJvdXRlKHBhdGg6ICRwYXRoKSB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICAuLi4gb24gUHJvZHVjdCB7XHJcbiAgICAgICAgICAgIC4uLnByb2R1Y3RJbmZvXHJcbiAgICAgICAgICAgIHZhcmlhbnRzIHtcclxuICAgICAgICAgICAgICBlZGdlcyB7XHJcbiAgICAgICAgICAgICAgICBub2RlIHtcclxuICAgICAgICAgICAgICAgICAgZW50aXR5SWRcclxuICAgICAgICAgICAgICAgICAgZGVmYXVsdEltYWdlIHtcclxuICAgICAgICAgICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICAgICAgICAgIGFsdFRleHRcclxuICAgICAgICAgICAgICAgICAgICBpc0RlZmF1bHRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBwcmljZXMge1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLnByb2R1Y3RQcmljZXNcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpbnZlbnRvcnkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZWQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlVG9TZWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3YXJuaW5nTGV2ZWxcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaXNJblN0b2NrXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcHJvZHVjdE9wdGlvbnMge1xyXG4gICAgICAgICAgICAgICAgICAgIGVkZ2VzIHtcclxuICAgICAgICAgICAgICAgICAgICAgIG5vZGUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm11bHRpcGxlQ2hvaWNlT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3Byb2R1Y3RJbmZvRnJhZ21lbnR9XHJcbmBcclxuXHJcbi8vIFRPRE86IFNlZSBpZiB0aGlzIHR5cGUgaXMgdXNlZnVsIGZvciBkZWZpbmluZyB0aGUgUHJvZHVjdCB0eXBlXHJcbi8vIGV4cG9ydCB0eXBlIFByb2R1Y3ROb2RlID0gRXh0cmFjdDxcclxuLy8gICBHZXRQcm9kdWN0UXVlcnlbJ3NpdGUnXVsncm91dGUnXVsnbm9kZSddLFxyXG4vLyAgIHsgX190eXBlbmFtZTogJ1Byb2R1Y3QnIH1cclxuLy8gPlxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0PFQgZXh0ZW5kcyBHZXRQcm9kdWN0T3BlcmF0aW9uPihvcHRzOiB7XHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3Q8VCBleHRlbmRzIEdldFByb2R1Y3RPcGVyYXRpb24+KFxyXG4gICAgb3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0PFQgZXh0ZW5kcyBHZXRQcm9kdWN0T3BlcmF0aW9uPih7XHJcbiAgICBxdWVyeSA9IGdldFByb2R1Y3RRdWVyeSxcclxuICAgIHZhcmlhYmxlczogeyBzbHVnLCAuLi52YXJzIH0sXHJcbiAgICBjb25maWc6IGNmZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPiB7XHJcbiAgICBjb25zdCBjb25maWcgPSBjb21tZXJjZS5nZXRDb25maWcoY2ZnKVxyXG4gICAgY29uc3QgeyBsb2NhbGUgfSA9IGNvbmZpZ1xyXG4gICAgY29uc3QgdmFyaWFibGVzOiBHZXRQcm9kdWN0UXVlcnlWYXJpYWJsZXMgPSB7XHJcbiAgICAgIGxvY2FsZSxcclxuICAgICAgaGFzTG9jYWxlOiAhIWxvY2FsZSxcclxuICAgICAgcGF0aDogc2x1ZyA/IGAvJHtzbHVnfS9gIDogdmFycy5wYXRoISxcclxuICAgIH1cclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPEdldFByb2R1Y3RRdWVyeT4ocXVlcnksIHsgdmFyaWFibGVzIH0pXHJcbiAgICBjb25zdCBwcm9kdWN0ID0gZGF0YS5zaXRlPy5yb3V0ZT8ubm9kZVxyXG5cclxuICAgIGlmIChwcm9kdWN0Py5fX3R5cGVuYW1lID09PSAnUHJvZHVjdCcpIHtcclxuICAgICAgaWYgKGxvY2FsZSAmJiBjb25maWcuYXBwbHlMb2NhbGUpIHtcclxuICAgICAgICBzZXRQcm9kdWN0TG9jYWxlTWV0YShwcm9kdWN0KVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geyBwcm9kdWN0OiBub3JtYWxpemVQcm9kdWN0KHByb2R1Y3QgYXMgYW55KSB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHt9XHJcbiAgfVxyXG4gIHJldHVybiBnZXRQcm9kdWN0XHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHsgR2V0U2l0ZUluZm9PcGVyYXRpb24gfSBmcm9tICcuLi8uLi90eXBlcy9zaXRlJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFNpdGVJbmZvUXVlcnkgfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCBmaWx0ZXJFZGdlcyBmcm9tICcuLi91dGlscy9maWx0ZXItZWRnZXMnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IGNhdGVnb3J5VHJlZUl0ZW1GcmFnbWVudCB9IGZyb20gJy4uL2ZyYWdtZW50cy9jYXRlZ29yeS10cmVlJ1xyXG5pbXBvcnQgeyBub3JtYWxpemVDYXRlZ29yeSB9IGZyb20gJy4uLy4uL2xpYi9ub3JtYWxpemUnXHJcblxyXG4vLyBHZXQgMyBsZXZlbHMgb2YgY2F0ZWdvcmllc1xyXG5leHBvcnQgY29uc3QgZ2V0U2l0ZUluZm9RdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldFNpdGVJbmZvIHtcclxuICAgIHNpdGUge1xyXG4gICAgICBjYXRlZ29yeVRyZWUge1xyXG4gICAgICAgIC4uLmNhdGVnb3J5VHJlZUl0ZW1cclxuICAgICAgICBjaGlsZHJlbiB7XHJcbiAgICAgICAgICAuLi5jYXRlZ29yeVRyZWVJdGVtXHJcbiAgICAgICAgICBjaGlsZHJlbiB7XHJcbiAgICAgICAgICAgIC4uLmNhdGVnb3J5VHJlZUl0ZW1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYnJhbmRzIHtcclxuICAgICAgICBwYWdlSW5mbyB7XHJcbiAgICAgICAgICBzdGFydEN1cnNvclxyXG4gICAgICAgICAgZW5kQ3Vyc29yXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVkZ2VzIHtcclxuICAgICAgICAgIGN1cnNvclxyXG4gICAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICAgIG5hbWVcclxuICAgICAgICAgICAgZGVmYXVsdEltYWdlIHtcclxuICAgICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICAgIGFsdFRleHRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBwYWdlVGl0bGVcclxuICAgICAgICAgICAgbWV0YURlc2NcclxuICAgICAgICAgICAgbWV0YUtleXdvcmRzXHJcbiAgICAgICAgICAgIHNlYXJjaEtleXdvcmRzXHJcbiAgICAgICAgICAgIHBhdGhcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgJHtjYXRlZ29yeVRyZWVJdGVtRnJhZ21lbnR9XHJcbmBcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdldFNpdGVJbmZvT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRTaXRlSW5mbzxUIGV4dGVuZHMgR2V0U2l0ZUluZm9PcGVyYXRpb24+KG9wdHM/OiB7XHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFNpdGVJbmZvPFQgZXh0ZW5kcyBHZXRTaXRlSW5mb09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRTaXRlSW5mbzxUIGV4dGVuZHMgR2V0U2l0ZUluZm9PcGVyYXRpb24+KHtcclxuICAgIHF1ZXJ5ID0gZ2V0U2l0ZUluZm9RdWVyeSxcclxuICAgIGNvbmZpZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbnN0IGNmZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGNmZy5mZXRjaDxHZXRTaXRlSW5mb1F1ZXJ5PihxdWVyeSlcclxuICAgIGNvbnN0IGNhdGVnb3JpZXMgPSBkYXRhLnNpdGUuY2F0ZWdvcnlUcmVlLm1hcChub3JtYWxpemVDYXRlZ29yeSlcclxuICAgIGNvbnN0IGJyYW5kcyA9IGRhdGEuc2l0ZT8uYnJhbmRzPy5lZGdlc1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGNhdGVnb3JpZXM6IGNhdGVnb3JpZXMgPz8gW10sXHJcbiAgICAgIGJyYW5kczogZmlsdGVyRWRnZXMoYnJhbmRzKSxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiBnZXRTaXRlSW5mb1xyXG59XHJcbiIsImltcG9ydCB0eXBlIHsgU2VydmVyUmVzcG9uc2UgfSBmcm9tICdodHRwJ1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgT3BlcmF0aW9uQ29udGV4dCxcclxuICBPcGVyYXRpb25PcHRpb25zLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGkvb3BlcmF0aW9ucydcclxuaW1wb3J0IHR5cGUgeyBMb2dpbk9wZXJhdGlvbiB9IGZyb20gJy4uLy4uL3R5cGVzL2xvZ2luJ1xyXG5pbXBvcnQgdHlwZSB7IExvZ2luTXV0YXRpb24gfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCB0eXBlIHsgUmVjdXJzaXZlUGFydGlhbCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgY29uY2F0SGVhZGVyIGZyb20gJy4uL3V0aWxzL2NvbmNhdC1jb29raWUnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcblxyXG5leHBvcnQgY29uc3QgbG9naW5NdXRhdGlvbiA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIG11dGF0aW9uIGxvZ2luKCRlbWFpbDogU3RyaW5nISwgJHBhc3N3b3JkOiBTdHJpbmchKSB7XHJcbiAgICBsb2dpbihlbWFpbDogJGVtYWlsLCBwYXNzd29yZDogJHBhc3N3b3JkKSB7XHJcbiAgICAgIHJlc3VsdFxyXG4gICAgfVxyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbG9naW5PcGVyYXRpb24oe1xyXG4gIGNvbW1lcmNlLFxyXG59OiBPcGVyYXRpb25Db250ZXh0PFByb3ZpZGVyPikge1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvZ2luPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgIHJlczogU2VydmVyUmVzcG9uc2VcclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvZ2luPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgICAgcmVzOiBTZXJ2ZXJSZXNwb25zZVxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gbG9naW48VCBleHRlbmRzIExvZ2luT3BlcmF0aW9uPih7XHJcbiAgICBxdWVyeSA9IGxvZ2luTXV0YXRpb24sXHJcbiAgICB2YXJpYWJsZXMsXHJcbiAgICByZXM6IHJlc3BvbnNlLFxyXG4gICAgY29uZmlnLFxyXG4gIH06IHtcclxuICAgIHF1ZXJ5Pzogc3RyaW5nXHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICByZXM6IFNlcnZlclJlc3BvbnNlXHJcbiAgICBjb25maWc/OiBCaWdjb21tZXJjZUNvbmZpZ1xyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uZmlnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNvbmZpZylcclxuXHJcbiAgICBjb25zdCB7IGRhdGEsIHJlcyB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFJlY3Vyc2l2ZVBhcnRpYWw8TG9naW5NdXRhdGlvbj4+KFxyXG4gICAgICBxdWVyeSxcclxuICAgICAgeyB2YXJpYWJsZXMgfVxyXG4gICAgKVxyXG4gICAgLy8gQmlnY29tbWVyY2UgcmV0dXJucyBhIFNldC1Db29raWUgaGVhZGVyIHdpdGggdGhlIGF1dGggY29va2llXHJcbiAgICBsZXQgY29va2llID0gcmVzLmhlYWRlcnMuZ2V0KCdTZXQtQ29va2llJylcclxuXHJcbiAgICBpZiAoY29va2llICYmIHR5cGVvZiBjb29raWUgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIC8vIEluIGRldmVsb3BtZW50LCBkb24ndCBzZXQgYSBzZWN1cmUgY29va2llIG9yIHRoZSBicm93c2VyIHdpbGwgaWdub3JlIGl0XHJcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XHJcbiAgICAgICAgY29va2llID0gY29va2llLnJlcGxhY2UoJzsgU2VjdXJlJywgJycpXHJcbiAgICAgICAgLy8gU2FtZVNpdGU9bm9uZSBjYW4ndCBiZSBzZXQgdW5sZXNzIHRoZSBjb29raWUgaXMgU2VjdXJlXHJcbiAgICAgICAgLy8gYmMgc2VlbXMgdG8gc29tZXRpbWVzIHNlbmQgYmFjayBTYW1lU2l0ZT1Ob25lIHJhdGhlciB0aGFuIG5vbmUgc28gbWFrZVxyXG4gICAgICAgIC8vIHRoaXMgY2FzZSBpbnNlbnNpdGl2ZVxyXG4gICAgICAgIGNvb2tpZSA9IGNvb2tpZS5yZXBsYWNlKC87IFNhbWVTaXRlPW5vbmUvZ2ksICc7IFNhbWVTaXRlPWxheCcpXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJlc3BvbnNlLnNldEhlYWRlcihcclxuICAgICAgICAnU2V0LUNvb2tpZScsXHJcbiAgICAgICAgY29uY2F0SGVhZGVyKHJlc3BvbnNlLmdldEhlYWRlcignU2V0LUNvb2tpZScpLCBjb29raWUpIVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzdWx0OiBkYXRhLmxvZ2luPy5yZXN1bHQsXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gbG9naW5cclxufVxyXG4iLCJ0eXBlIEhlYWRlciA9IHN0cmluZyB8IG51bWJlciB8IHN0cmluZ1tdIHwgdW5kZWZpbmVkXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjb25jYXRIZWFkZXIocHJldjogSGVhZGVyLCB2YWw6IEhlYWRlcikge1xyXG4gIGlmICghdmFsKSByZXR1cm4gcHJldlxyXG4gIGlmICghcHJldikgcmV0dXJuIHZhbFxyXG5cclxuICBpZiAoQXJyYXkuaXNBcnJheShwcmV2KSkgcmV0dXJuIHByZXYuY29uY2F0KFN0cmluZyh2YWwpKVxyXG5cclxuICBwcmV2ID0gU3RyaW5nKHByZXYpXHJcblxyXG4gIGlmIChBcnJheS5pc0FycmF5KHZhbCkpIHJldHVybiBbcHJldl0uY29uY2F0KHZhbClcclxuXHJcbiAgcmV0dXJuIFtwcmV2LCBTdHJpbmcodmFsKV1cclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IFJlc3BvbnNlIH0gZnJvbSAnQHZlcmNlbC9mZXRjaCdcclxuXHJcbi8vIFVzZWQgZm9yIEdyYXBoUUwgZXJyb3JzXHJcbmV4cG9ydCBjbGFzcyBCaWdjb21tZXJjZUdyYXBoUUxFcnJvciBleHRlbmRzIEVycm9yIHt9XHJcblxyXG5leHBvcnQgY2xhc3MgQmlnY29tbWVyY2VBcGlFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlclxyXG4gIHJlczogUmVzcG9uc2VcclxuICBkYXRhOiBhbnlcclxuXHJcbiAgY29uc3RydWN0b3IobXNnOiBzdHJpbmcsIHJlczogUmVzcG9uc2UsIGRhdGE/OiBhbnkpIHtcclxuICAgIHN1cGVyKG1zZylcclxuICAgIHRoaXMubmFtZSA9ICdCaWdjb21tZXJjZUFwaUVycm9yJ1xyXG4gICAgdGhpcy5zdGF0dXMgPSByZXMuc3RhdHVzXHJcbiAgICB0aGlzLnJlcyA9IHJlc1xyXG4gICAgdGhpcy5kYXRhID0gZGF0YVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIGNvbnN0cnVjdG9yKG1zZzogc3RyaW5nKSB7XHJcbiAgICBzdXBlcihtc2cpXHJcbiAgICB0aGlzLm5hbWUgPSAnQmlnY29tbWVyY2VOZXR3b3JrRXJyb3InXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEZldGNoZXJFcnJvciB9IGZyb20gJ0Bjb21tZXJjZS91dGlscy9lcnJvcnMnXHJcbmltcG9ydCB0eXBlIHsgR3JhcGhRTEZldGNoZXIgfSBmcm9tICdAY29tbWVyY2UvYXBpJ1xyXG5pbXBvcnQgdHlwZSB7IEJpZ2NvbW1lcmNlQ29uZmlnIH0gZnJvbSAnLi4vaW5kZXgnXHJcbmltcG9ydCBmZXRjaCBmcm9tICcuL2ZldGNoJ1xyXG5cclxuY29uc3QgZmV0Y2hHcmFwaHFsQXBpOiAoZ2V0Q29uZmlnOiAoKSA9PiBCaWdjb21tZXJjZUNvbmZpZykgPT4gR3JhcGhRTEZldGNoZXIgPVxyXG4gIChnZXRDb25maWcpID0+XHJcbiAgYXN5bmMgKHF1ZXJ5OiBzdHJpbmcsIHsgdmFyaWFibGVzLCBwcmV2aWV3IH0gPSB7fSwgZmV0Y2hPcHRpb25zKSA9PiB7XHJcbiAgICAvLyBsb2cud2FybihxdWVyeSlcclxuICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZygpXHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChjb25maWcuY29tbWVyY2VVcmwgKyAocHJldmlldyA/ICcvcHJldmlldycgOiAnJyksIHtcclxuICAgICAgLi4uZmV0Y2hPcHRpb25zLFxyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjb25maWcuYXBpVG9rZW59YCxcclxuICAgICAgICAuLi5mZXRjaE9wdGlvbnM/LmhlYWRlcnMsXHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgfSxcclxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHF1ZXJ5LFxyXG4gICAgICAgIHZhcmlhYmxlcyxcclxuICAgICAgfSksXHJcbiAgICB9KVxyXG5cclxuICAgIGNvbnN0IGpzb24gPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICBpZiAoanNvbi5lcnJvcnMpIHtcclxuICAgICAgdGhyb3cgbmV3IEZldGNoZXJFcnJvcih7XHJcbiAgICAgICAgZXJyb3JzOiBqc29uLmVycm9ycyA/PyBbeyBtZXNzYWdlOiAnRmFpbGVkIHRvIGZldGNoIEJpZ2NvbW1lcmNlIEFQSScgfV0sXHJcbiAgICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7IGRhdGE6IGpzb24uZGF0YSwgcmVzIH1cclxuICB9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaEdyYXBocWxBcGlcclxuIiwiaW1wb3J0IHR5cGUgeyBSZXF1ZXN0SW5pdCwgUmVzcG9uc2UgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5pbXBvcnQgdHlwZSB7IEJpZ2NvbW1lcmNlQ29uZmlnIH0gZnJvbSAnLi4vaW5kZXgnXHJcbmltcG9ydCB7IEJpZ2NvbW1lcmNlQXBpRXJyb3IsIEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yIH0gZnJvbSAnLi9lcnJvcnMnXHJcbmltcG9ydCBmZXRjaCBmcm9tICcuL2ZldGNoJ1xyXG5cclxuY29uc3QgZmV0Y2hTdG9yZUFwaSA9XHJcbiAgPFQ+KGdldENvbmZpZzogKCkgPT4gQmlnY29tbWVyY2VDb25maWcpID0+XHJcbiAgYXN5bmMgKGVuZHBvaW50OiBzdHJpbmcsIG9wdGlvbnM/OiBSZXF1ZXN0SW5pdCk6IFByb21pc2U8VD4gPT4ge1xyXG4gICAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnKClcclxuICAgIGxldCByZXM6IFJlc3BvbnNlXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgcmVzID0gYXdhaXQgZmV0Y2goY29uZmlnLnN0b3JlQXBpVXJsICsgZW5kcG9pbnQsIHtcclxuICAgICAgICAuLi5vcHRpb25zLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIC4uLm9wdGlvbnM/LmhlYWRlcnMsXHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgJ1gtQXV0aC1Ub2tlbic6IGNvbmZpZy5zdG9yZUFwaVRva2VuLFxyXG4gICAgICAgICAgJ1gtQXV0aC1DbGllbnQnOiBjb25maWcuc3RvcmVBcGlDbGllbnRJZCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgdGhyb3cgbmV3IEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yKFxyXG4gICAgICAgIGBGZXRjaCB0byBCaWdjb21tZXJjZSBmYWlsZWQ6ICR7ZXJyb3IubWVzc2FnZX1gXHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlcy5oZWFkZXJzLmdldCgnQ29udGVudC1UeXBlJylcclxuICAgIGNvbnN0IGlzSlNPTiA9IGNvbnRlbnRUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpXHJcblxyXG4gICAgaWYgKCFyZXMub2spIHtcclxuICAgICAgY29uc3QgZGF0YSA9IGlzSlNPTiA/IGF3YWl0IHJlcy5qc29uKCkgOiBhd2FpdCBnZXRUZXh0T3JOdWxsKHJlcylcclxuICAgICAgY29uc3QgaGVhZGVycyA9IGdldFJhd0hlYWRlcnMocmVzKVxyXG4gICAgICBjb25zdCBtc2cgPSBgQmlnIENvbW1lcmNlIEFQSSBlcnJvciAoJHtcclxuICAgICAgICByZXMuc3RhdHVzXHJcbiAgICAgIH0pIFxcbkhlYWRlcnM6ICR7SlNPTi5zdHJpbmdpZnkoaGVhZGVycywgbnVsbCwgMil9XFxuJHtcclxuICAgICAgICB0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycgPyBkYXRhIDogSlNPTi5zdHJpbmdpZnkoZGF0YSwgbnVsbCwgMilcclxuICAgICAgfWBcclxuXHJcbiAgICAgIHRocm93IG5ldyBCaWdjb21tZXJjZUFwaUVycm9yKG1zZywgcmVzLCBkYXRhKVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChyZXMuc3RhdHVzICE9PSAyMDQgJiYgIWlzSlNPTikge1xyXG4gICAgICB0aHJvdyBuZXcgQmlnY29tbWVyY2VBcGlFcnJvcihcclxuICAgICAgICBgRmV0Y2ggdG8gQmlnY29tbWVyY2UgQVBJIGZhaWxlZCwgZXhwZWN0ZWQgSlNPTiBjb250ZW50IGJ1dCBmb3VuZDogJHtjb250ZW50VHlwZX1gLFxyXG4gICAgICAgIHJlc1xyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgLy8gSWYgc29tZXRoaW5nIHdhcyByZW1vdmVkLCB0aGUgcmVzcG9uc2Ugd2lsbCBiZSBlbXB0eVxyXG4gICAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwNCA/IG51bGwgOiBhd2FpdCByZXMuanNvbigpXHJcbiAgfVxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaFN0b3JlQXBpXHJcblxyXG5mdW5jdGlvbiBnZXRSYXdIZWFkZXJzKHJlczogUmVzcG9uc2UpIHtcclxuICBjb25zdCBoZWFkZXJzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge31cclxuXHJcbiAgcmVzLmhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xyXG4gICAgaGVhZGVyc1trZXldID0gdmFsdWVcclxuICB9KVxyXG5cclxuICByZXR1cm4gaGVhZGVyc1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRUZXh0T3JOdWxsKHJlczogUmVzcG9uc2UpIHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIHJlcy50ZXh0KClcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHJldHVybiBudWxsXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB6ZWl0RmV0Y2ggZnJvbSAnQHZlcmNlbC9mZXRjaCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHplaXRGZXRjaCgpXHJcbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGZpbHRlckVkZ2VzPFQ+KFxyXG4gIGVkZ2VzOiAoVCB8IG51bGwgfCB1bmRlZmluZWQpW10gfCBudWxsIHwgdW5kZWZpbmVkXHJcbikge1xyXG4gIHJldHVybiBlZGdlcz8uZmlsdGVyKChlZGdlKTogZWRnZSBpcyBUID0+ICEhZWRnZSkgPz8gW11cclxufVxyXG4iLCJpbXBvcnQgeyBzZXJpYWxpemUsIENvb2tpZVNlcmlhbGl6ZU9wdGlvbnMgfSBmcm9tICdjb29raWUnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZXRDYXJ0Q29va2llKFxyXG4gIG5hbWU6IHN0cmluZyxcclxuICBjYXJ0SWQ/OiBzdHJpbmcsXHJcbiAgbWF4QWdlPzogbnVtYmVyXHJcbikge1xyXG4gIGNvbnN0IG9wdGlvbnM6IENvb2tpZVNlcmlhbGl6ZU9wdGlvbnMgPVxyXG4gICAgY2FydElkICYmIG1heEFnZVxyXG4gICAgICA/IHtcclxuICAgICAgICAgIG1heEFnZSxcclxuICAgICAgICAgIGV4cGlyZXM6IG5ldyBEYXRlKERhdGUubm93KCkgKyBtYXhBZ2UgKiAxMDAwKSxcclxuICAgICAgICAgIHNlY3VyZTogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJyxcclxuICAgICAgICAgIHBhdGg6ICcvJyxcclxuICAgICAgICAgIHNhbWVTaXRlOiAnbGF4JyxcclxuICAgICAgICB9XHJcbiAgICAgIDogeyBtYXhBZ2U6IC0xLCBwYXRoOiAnLycgfSAvLyBSZW1vdmVzIHRoZSBjb29raWVcclxuXHJcbiAgcmV0dXJuIHNlcmlhbGl6ZShuYW1lLCBjYXJ0SWQgfHwgJycsIG9wdGlvbnMpXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUgeyBXaXNobGlzdEl0ZW1Cb2R5IH0gZnJvbSAnLi4vLi4vdHlwZXMvd2lzaGxpc3QnXHJcbmltcG9ydCB0eXBlIHsgQ2FydEl0ZW1Cb2R5LCBPcHRpb25TZWxlY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHlwZXMvY2FydCdcclxuXHJcbnR5cGUgQkNXaXNobGlzdEl0ZW1Cb2R5ID0ge1xyXG4gIHByb2R1Y3RfaWQ6IG51bWJlclxyXG4gIHZhcmlhbnRfaWQ6IG51bWJlclxyXG59XHJcblxyXG50eXBlIEJDQ2FydEl0ZW1Cb2R5ID0ge1xyXG4gIHByb2R1Y3RfaWQ6IG51bWJlclxyXG4gIHZhcmlhbnRfaWQ6IG51bWJlclxyXG4gIHF1YW50aXR5PzogbnVtYmVyXHJcbiAgb3B0aW9uX3NlbGVjdGlvbnM/OiBPcHRpb25TZWxlY3Rpb25zW11cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHBhcnNlV2lzaGxpc3RJdGVtID0gKFxyXG4gIGl0ZW06IFdpc2hsaXN0SXRlbUJvZHlcclxuKTogQkNXaXNobGlzdEl0ZW1Cb2R5ID0+ICh7XHJcbiAgcHJvZHVjdF9pZDogTnVtYmVyKGl0ZW0ucHJvZHVjdElkKSxcclxuICB2YXJpYW50X2lkOiBOdW1iZXIoaXRlbS52YXJpYW50SWQpLFxyXG59KVxyXG5cclxuZXhwb3J0IGNvbnN0IHBhcnNlQ2FydEl0ZW0gPSAoaXRlbTogQ2FydEl0ZW1Cb2R5KTogQkNDYXJ0SXRlbUJvZHkgPT4gKHtcclxuICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcclxuICBwcm9kdWN0X2lkOiBOdW1iZXIoaXRlbS5wcm9kdWN0SWQpLFxyXG4gIHZhcmlhbnRfaWQ6IE51bWJlcihpdGVtLnZhcmlhbnRJZCksXHJcbiAgb3B0aW9uX3NlbGVjdGlvbnM6IGl0ZW0ub3B0aW9uU2VsZWN0aW9ucyxcclxufSlcclxuIiwiaW1wb3J0IHR5cGUgeyBQcm9kdWN0Tm9kZSB9IGZyb20gJy4uL29wZXJhdGlvbnMvZ2V0LWFsbC1wcm9kdWN0cydcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsIH0gZnJvbSAnLi90eXBlcydcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHNldFByb2R1Y3RMb2NhbGVNZXRhKFxyXG4gIG5vZGU6IFJlY3Vyc2l2ZVBhcnRpYWw8UHJvZHVjdE5vZGU+XHJcbikge1xyXG4gIGlmIChub2RlLmxvY2FsZU1ldGE/LmVkZ2VzKSB7XHJcbiAgICBub2RlLmxvY2FsZU1ldGEuZWRnZXMgPSBub2RlLmxvY2FsZU1ldGEuZWRnZXMuZmlsdGVyKChlZGdlKSA9PiB7XHJcbiAgICAgIGNvbnN0IHsga2V5LCB2YWx1ZSB9ID0gZWRnZT8ubm9kZSA/PyB7fVxyXG4gICAgICBpZiAoa2V5ICYmIGtleSBpbiBub2RlKSB7XHJcbiAgICAgICAgOyhub2RlIGFzIGFueSlba2V5XSA9IHZhbHVlXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHRydWVcclxuICAgIH0pXHJcblxyXG4gICAgaWYgKCFub2RlLmxvY2FsZU1ldGEuZWRnZXMubGVuZ3RoKSB7XHJcbiAgICAgIGRlbGV0ZSBub2RlLmxvY2FsZU1ldGFcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiLy8gUmVtb3ZlIHRyYWlsaW5nIGFuZCBsZWFkaW5nIHNsYXNoLCB1c3VhbGx5IGluY2x1ZGVkIGluIG5vZGVzXHJcbi8vIHJldHVybmVkIGJ5IHRoZSBCaWdDb21tZXJjZSBBUElcclxuY29uc3QgZ2V0U2x1ZyA9IChwYXRoOiBzdHJpbmcpID0+IHBhdGgucmVwbGFjZSgvXlxcL3xcXC8kL2csICcnKVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZ2V0U2x1Z1xyXG4iLCJpbXBvcnQgdXBkYXRlLCB7IENvbnRleHQgfSBmcm9tICdpbW11dGFiaWxpdHktaGVscGVyJ1xyXG5cclxuY29uc3QgYyA9IG5ldyBDb250ZXh0KClcclxuXHJcbmMuZXh0ZW5kKCckYXV0bycsIGZ1bmN0aW9uICh2YWx1ZSwgb2JqZWN0KSB7XHJcbiAgcmV0dXJuIG9iamVjdCA/IGMudXBkYXRlKG9iamVjdCwgdmFsdWUpIDogYy51cGRhdGUoe30sIHZhbHVlKVxyXG59KVxyXG5cclxuYy5leHRlbmQoJyRhdXRvQXJyYXknLCBmdW5jdGlvbiAodmFsdWUsIG9iamVjdCkge1xyXG4gIHJldHVybiBvYmplY3QgPyBjLnVwZGF0ZShvYmplY3QsIHZhbHVlKSA6IGMudXBkYXRlKFtdLCB2YWx1ZSlcclxufSlcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGMudXBkYXRlXHJcbiIsImltcG9ydCB0eXBlIHsgUHJvZHVjdCB9IGZyb20gJy4uL3R5cGVzL3Byb2R1Y3QnXHJcbmltcG9ydCB0eXBlIHsgQ2FydCwgQmlnY29tbWVyY2VDYXJ0LCBMaW5lSXRlbSB9IGZyb20gJy4uL3R5cGVzL2NhcnQnXHJcbmltcG9ydCB0eXBlIHsgUGFnZSB9IGZyb20gJy4uL3R5cGVzL3BhZ2UnXHJcbmltcG9ydCB0eXBlIHsgQkNDYXRlZ29yeSwgQ2F0ZWdvcnkgfSBmcm9tICcuLi90eXBlcy9zaXRlJ1xyXG5pbXBvcnQgeyBkZWZpbml0aW9ucyB9IGZyb20gJy4uL2FwaS9kZWZpbml0aW9ucy9zdG9yZS1jb250ZW50J1xyXG5pbXBvcnQgdXBkYXRlIGZyb20gJy4vaW1tdXRhYmlsaXR5J1xyXG5pbXBvcnQgZ2V0U2x1ZyBmcm9tICcuL2dldC1zbHVnJ1xyXG5cclxuZnVuY3Rpb24gbm9ybWFsaXplUHJvZHVjdE9wdGlvbihwcm9kdWN0T3B0aW9uOiBhbnkpIHtcclxuICBjb25zdCB7XHJcbiAgICBub2RlOiB7XHJcbiAgICAgIGVudGl0eUlkLFxyXG4gICAgICB2YWx1ZXM6IHsgZWRnZXMgPSBbXSB9ID0ge30sXHJcbiAgICAgIC4uLnJlc3RcclxuICAgIH0sXHJcbiAgfSA9IHByb2R1Y3RPcHRpb25cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGlkOiBlbnRpdHlJZCxcclxuICAgIHZhbHVlczogZWRnZXM/Lm1hcCgoeyBub2RlIH06IGFueSkgPT4gbm9kZSksXHJcbiAgICAuLi5yZXN0LFxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVByb2R1Y3QocHJvZHVjdE5vZGU6IGFueSk6IFByb2R1Y3Qge1xyXG4gIGNvbnN0IHtcclxuICAgIGVudGl0eUlkOiBpZCxcclxuICAgIHByb2R1Y3RPcHRpb25zLFxyXG4gICAgcHJpY2VzLFxyXG4gICAgcGF0aCxcclxuICAgIGlkOiBfLFxyXG4gICAgb3B0aW9uczogXzAsXHJcbiAgfSA9IHByb2R1Y3ROb2RlXHJcblxyXG4gIHJldHVybiB1cGRhdGUocHJvZHVjdE5vZGUsIHtcclxuICAgIGlkOiB7ICRzZXQ6IFN0cmluZyhpZCkgfSxcclxuICAgIGltYWdlczoge1xyXG4gICAgICAkYXBwbHk6ICh7IGVkZ2VzIH06IGFueSkgPT5cclxuICAgICAgICBlZGdlcz8ubWFwKCh7IG5vZGU6IHsgdXJsT3JpZ2luYWwsIGFsdFRleHQsIC4uLnJlc3QgfSB9OiBhbnkpID0+ICh7XHJcbiAgICAgICAgICB1cmw6IHVybE9yaWdpbmFsLFxyXG4gICAgICAgICAgYWx0OiBhbHRUZXh0LFxyXG4gICAgICAgICAgLi4ucmVzdCxcclxuICAgICAgICB9KSksXHJcbiAgICB9LFxyXG4gICAgdmFyaWFudHM6IHtcclxuICAgICAgJGFwcGx5OiAoeyBlZGdlcyB9OiBhbnkpID0+XHJcbiAgICAgICAgZWRnZXM/Lm1hcCgoeyBub2RlOiB7IGVudGl0eUlkLCBwcm9kdWN0T3B0aW9ucywgLi4ucmVzdCB9IH06IGFueSkgPT4gKHtcclxuICAgICAgICAgIGlkOiBlbnRpdHlJZCxcclxuICAgICAgICAgIG9wdGlvbnM6IHByb2R1Y3RPcHRpb25zPy5lZGdlc1xyXG4gICAgICAgICAgICA/IHByb2R1Y3RPcHRpb25zLmVkZ2VzLm1hcChub3JtYWxpemVQcm9kdWN0T3B0aW9uKVxyXG4gICAgICAgICAgICA6IFtdLFxyXG4gICAgICAgICAgLi4ucmVzdCxcclxuICAgICAgICB9KSksXHJcbiAgICB9LFxyXG4gICAgb3B0aW9uczoge1xyXG4gICAgICAkc2V0OiBwcm9kdWN0T3B0aW9ucy5lZGdlc1xyXG4gICAgICAgID8gcHJvZHVjdE9wdGlvbnM/LmVkZ2VzLm1hcChub3JtYWxpemVQcm9kdWN0T3B0aW9uKVxyXG4gICAgICAgIDogW10sXHJcbiAgICB9LFxyXG4gICAgYnJhbmQ6IHtcclxuICAgICAgJGFwcGx5OiAoYnJhbmQ6IGFueSkgPT4gKGJyYW5kPy5lbnRpdHlJZCA/IGJyYW5kPy5lbnRpdHlJZCA6IG51bGwpLFxyXG4gICAgfSxcclxuICAgIHNsdWc6IHtcclxuICAgICAgJHNldDogcGF0aD8ucmVwbGFjZSgvXlxcLyt8XFwvKyQvZywgJycpLFxyXG4gICAgfSxcclxuICAgIHByaWNlOiB7XHJcbiAgICAgICRzZXQ6IHtcclxuICAgICAgICB2YWx1ZTogcHJpY2VzPy5wcmljZS52YWx1ZSxcclxuICAgICAgICBjdXJyZW5jeUNvZGU6IHByaWNlcz8ucHJpY2UuY3VycmVuY3lDb2RlLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgICR1bnNldDogWydlbnRpdHlJZCddLFxyXG4gIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVQYWdlKHBhZ2U6IGRlZmluaXRpb25zWydwYWdlX0Z1bGwnXSk6IFBhZ2Uge1xyXG4gIHJldHVybiB7XHJcbiAgICBpZDogU3RyaW5nKHBhZ2UuaWQpLFxyXG4gICAgbmFtZTogcGFnZS5uYW1lLFxyXG4gICAgaXNfdmlzaWJsZTogcGFnZS5pc192aXNpYmxlLFxyXG4gICAgc29ydF9vcmRlcjogcGFnZS5zb3J0X29yZGVyLFxyXG4gICAgYm9keTogcGFnZS5ib2R5LFxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUNhcnQoZGF0YTogQmlnY29tbWVyY2VDYXJ0KTogQ2FydCB7XHJcbiAgcmV0dXJuIHtcclxuICAgIGlkOiBkYXRhLmlkLFxyXG4gICAgY3VzdG9tZXJJZDogU3RyaW5nKGRhdGEuY3VzdG9tZXJfaWQpLFxyXG4gICAgZW1haWw6IGRhdGEuZW1haWwsXHJcbiAgICBjcmVhdGVkQXQ6IGRhdGEuY3JlYXRlZF90aW1lLFxyXG4gICAgY3VycmVuY3k6IGRhdGEuY3VycmVuY3ksXHJcbiAgICB0YXhlc0luY2x1ZGVkOiBkYXRhLnRheF9pbmNsdWRlZCxcclxuICAgIGxpbmVJdGVtczogW1xyXG4gICAgICAuLi5kYXRhLmxpbmVfaXRlbXMucGh5c2ljYWxfaXRlbXMubWFwKG5vcm1hbGl6ZUxpbmVJdGVtKSxcclxuICAgICAgLi4uZGF0YS5saW5lX2l0ZW1zLmRpZ2l0YWxfaXRlbXMubWFwKG5vcm1hbGl6ZUxpbmVJdGVtKSxcclxuICAgIF0sXHJcbiAgICBsaW5lSXRlbXNTdWJ0b3RhbFByaWNlOiBkYXRhLmJhc2VfYW1vdW50LFxyXG4gICAgc3VidG90YWxQcmljZTogZGF0YS5iYXNlX2Ftb3VudCArIGRhdGEuZGlzY291bnRfYW1vdW50LFxyXG4gICAgdG90YWxQcmljZTogZGF0YS5jYXJ0X2Ftb3VudCxcclxuICAgIGRpc2NvdW50czogZGF0YS5kaXNjb3VudHM/Lm1hcCgoZGlzY291bnQpID0+ICh7XHJcbiAgICAgIHZhbHVlOiBkaXNjb3VudC5kaXNjb3VudGVkX2Ftb3VudCxcclxuICAgIH0pKSxcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG5vcm1hbGl6ZUxpbmVJdGVtKGl0ZW06IGFueSk6IExpbmVJdGVtIHtcclxuICByZXR1cm4ge1xyXG4gICAgaWQ6IGl0ZW0uaWQsXHJcbiAgICB2YXJpYW50SWQ6IFN0cmluZyhpdGVtLnZhcmlhbnRfaWQpLFxyXG4gICAgcHJvZHVjdElkOiBTdHJpbmcoaXRlbS5wcm9kdWN0X2lkKSxcclxuICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIHF1YW50aXR5OiBpdGVtLnF1YW50aXR5LFxyXG4gICAgdmFyaWFudDoge1xyXG4gICAgICBpZDogU3RyaW5nKGl0ZW0udmFyaWFudF9pZCksXHJcbiAgICAgIHNrdTogaXRlbS5za3UsXHJcbiAgICAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgICAgaW1hZ2U6IHtcclxuICAgICAgICB1cmw6IGl0ZW0uaW1hZ2VfdXJsLFxyXG4gICAgICB9LFxyXG4gICAgICByZXF1aXJlc1NoaXBwaW5nOiBpdGVtLmlzX3JlcXVpcmVfc2hpcHBpbmcsXHJcbiAgICAgIHByaWNlOiBpdGVtLnNhbGVfcHJpY2UsXHJcbiAgICAgIGxpc3RQcmljZTogaXRlbS5saXN0X3ByaWNlLFxyXG4gICAgfSxcclxuICAgIHBhdGg6IGl0ZW0udXJsLnNwbGl0KCcvJylbM10sXHJcbiAgICBkaXNjb3VudHM6IGl0ZW0uZGlzY291bnRzLm1hcCgoZGlzY291bnQ6IGFueSkgPT4gKHtcclxuICAgICAgdmFsdWU6IGRpc2NvdW50LmRpc2NvdW50ZWRfYW1vdW50LFxyXG4gICAgfSkpLFxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUNhdGVnb3J5KGNhdGVnb3J5OiBCQ0NhdGVnb3J5KTogQ2F0ZWdvcnkge1xyXG4gIHJldHVybiB7XHJcbiAgICBpZDogYCR7Y2F0ZWdvcnkuZW50aXR5SWR9YCxcclxuICAgIG5hbWU6IGNhdGVnb3J5Lm5hbWUsXHJcbiAgICBzbHVnOiBnZXRTbHVnKGNhdGVnb3J5LnBhdGgpLFxyXG4gICAgcGF0aDogY2F0ZWdvcnkucGF0aCxcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHR5cGUgeyBDYXJ0U2NoZW1hIH0gZnJvbSAnLi4vLi4vdHlwZXMvY2FydCdcclxuaW1wb3J0IHsgQ29tbWVyY2VBUElFcnJvciB9IGZyb20gJy4uL3V0aWxzL2Vycm9ycydcclxuaW1wb3J0IGlzQWxsb3dlZE9wZXJhdGlvbiBmcm9tICcuLi91dGlscy9pcy1hbGxvd2VkLW9wZXJhdGlvbidcclxuaW1wb3J0IHR5cGUgeyBHZXRBUElTY2hlbWEgfSBmcm9tICcuLidcclxuXHJcbmNvbnN0IGNhcnRFbmRwb2ludDogR2V0QVBJU2NoZW1hPFxyXG4gIGFueSxcclxuICBDYXJ0U2NoZW1hPGFueT5cclxuPlsnZW5kcG9pbnQnXVsnaGFuZGxlciddID0gYXN5bmMgKGN0eCkgPT4ge1xyXG4gIGNvbnN0IHsgcmVxLCByZXMsIGhhbmRsZXJzLCBjb25maWcgfSA9IGN0eFxyXG5cclxuICBpZiAoXHJcbiAgICAhaXNBbGxvd2VkT3BlcmF0aW9uKHJlcSwgcmVzLCB7XHJcbiAgICAgIEdFVDogaGFuZGxlcnNbJ2dldENhcnQnXSxcclxuICAgICAgUE9TVDogaGFuZGxlcnNbJ2FkZEl0ZW0nXSxcclxuICAgICAgUFVUOiBoYW5kbGVyc1sndXBkYXRlSXRlbSddLFxyXG4gICAgICBERUxFVEU6IGhhbmRsZXJzWydyZW1vdmVJdGVtJ10sXHJcbiAgICB9KVxyXG4gICkge1xyXG4gICAgcmV0dXJuXHJcbiAgfVxyXG5cclxuICBjb25zdCB7IGNvb2tpZXMgfSA9IHJlcVxyXG4gIGNvbnN0IGNhcnRJZCA9IGNvb2tpZXNbY29uZmlnLmNhcnRDb29raWVdXHJcblxyXG4gIHRyeSB7XHJcbiAgICAvLyBSZXR1cm4gY3VycmVudCBjYXJ0IGluZm9cclxuICAgIGlmIChyZXEubWV0aG9kID09PSAnR0VUJykge1xyXG4gICAgICBjb25zdCBib2R5ID0geyBjYXJ0SWQgfVxyXG4gICAgICByZXR1cm4gYXdhaXQgaGFuZGxlcnNbJ2dldENhcnQnXSh7IC4uLmN0eCwgYm9keSB9KVxyXG4gICAgfVxyXG5cclxuICAgIC8vIENyZWF0ZSBvciBhZGQgYW4gaXRlbSB0byB0aGUgY2FydFxyXG4gICAgaWYgKHJlcS5tZXRob2QgPT09ICdQT1NUJykge1xyXG4gICAgICBjb25zdCBib2R5ID0geyAuLi5yZXEuYm9keSwgY2FydElkIH1cclxuICAgICAgcmV0dXJuIGF3YWl0IGhhbmRsZXJzWydhZGRJdGVtJ10oeyAuLi5jdHgsIGJvZHkgfSlcclxuICAgIH1cclxuXHJcbiAgICAvLyBVcGRhdGUgaXRlbSBpbiBjYXJ0XHJcbiAgICBpZiAocmVxLm1ldGhvZCA9PT0gJ1BVVCcpIHtcclxuICAgICAgY29uc3QgYm9keSA9IHsgLi4ucmVxLmJvZHksIGNhcnRJZCB9XHJcbiAgICAgIHJldHVybiBhd2FpdCBoYW5kbGVyc1sndXBkYXRlSXRlbSddKHsgLi4uY3R4LCBib2R5IH0pXHJcbiAgICB9XHJcblxyXG4gICAgLy8gUmVtb3ZlIGFuIGl0ZW0gZnJvbSB0aGUgY2FydFxyXG4gICAgaWYgKHJlcS5tZXRob2QgPT09ICdERUxFVEUnKSB7XHJcbiAgICAgIGNvbnN0IGJvZHkgPSB7IC4uLnJlcS5ib2R5LCBjYXJ0SWQgfVxyXG4gICAgICByZXR1cm4gYXdhaXQgaGFuZGxlcnNbJ3JlbW92ZUl0ZW0nXSh7IC4uLmN0eCwgYm9keSB9KVxyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKVxyXG5cclxuICAgIGNvbnN0IG1lc3NhZ2UgPVxyXG4gICAgICBlcnJvciBpbnN0YW5jZW9mIENvbW1lcmNlQVBJRXJyb3JcclxuICAgICAgICA/ICdBbiB1bmV4cGVjdGVkIGVycm9yIG9jdXJyZWQgd2l0aCB0aGUgQ29tbWVyY2UgQVBJJ1xyXG4gICAgICAgIDogJ0FuIHVuZXhwZWN0ZWQgZXJyb3Igb2N1cnJlZCdcclxuXHJcbiAgICByZXMuc3RhdHVzKDUwMCkuanNvbih7IGRhdGE6IG51bGwsIGVycm9yczogW3sgbWVzc2FnZSB9XSB9KVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2FydEVuZHBvaW50XHJcbiIsImltcG9ydCB0eXBlIHsgTmV4dEFwaUhhbmRsZXIgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgdHlwZSB7IFJlcXVlc3RJbml0LCBSZXNwb25zZSB9IGZyb20gJ0B2ZXJjZWwvZmV0Y2gnXHJcbmltcG9ydCB0eXBlIHsgQVBJRW5kcG9pbnQsIEFQSUhhbmRsZXIgfSBmcm9tICcuL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgdHlwZSB7IENhcnRTY2hlbWEgfSBmcm9tICcuLi90eXBlcy9jYXJ0J1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvY3VzdG9tZXInXHJcbmltcG9ydCB0eXBlIHsgTG9naW5TY2hlbWEgfSBmcm9tICcuLi90eXBlcy9sb2dpbidcclxuaW1wb3J0IHR5cGUgeyBMb2dvdXRTY2hlbWEgfSBmcm9tICcuLi90eXBlcy9sb2dvdXQnXHJcbmltcG9ydCB0eXBlIHsgU2lnbnVwU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvc2lnbnVwJ1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3RzU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBXaXNobGlzdFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzL3dpc2hsaXN0J1xyXG5pbXBvcnQgdHlwZSB7IENoZWNrb3V0U2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvY2hlY2tvdXQnXHJcbmltcG9ydCB0eXBlIHsgQ3VzdG9tZXJDYXJkU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvY3VzdG9tZXIvY2FyZCdcclxuaW1wb3J0IHR5cGUgeyBDdXN0b21lckFkZHJlc3NTY2hlbWEgfSBmcm9tICcuLi90eXBlcy9jdXN0b21lci9hZGRyZXNzJ1xyXG5pbXBvcnQge1xyXG4gIGRlZmF1bHRPcGVyYXRpb25zLFxyXG4gIE9QRVJBVElPTlMsXHJcbiAgQWxsT3BlcmF0aW9ucyxcclxuICBBUElPcGVyYXRpb25zLFxyXG59IGZyb20gJy4vb3BlcmF0aW9ucydcclxuXHJcbmV4cG9ydCB0eXBlIEFQSVNjaGVtYXMgPVxyXG4gIHwgQ2FydFNjaGVtYVxyXG4gIHwgQ3VzdG9tZXJTY2hlbWFcclxuICB8IExvZ2luU2NoZW1hXHJcbiAgfCBMb2dvdXRTY2hlbWFcclxuICB8IFNpZ251cFNjaGVtYVxyXG4gIHwgUHJvZHVjdHNTY2hlbWFcclxuICB8IFdpc2hsaXN0U2NoZW1hXHJcbiAgfCBDaGVja291dFNjaGVtYVxyXG4gIHwgQ3VzdG9tZXJDYXJkU2NoZW1hXHJcbiAgfCBDdXN0b21lckFkZHJlc3NTY2hlbWFcclxuXHJcbmV4cG9ydCB0eXBlIEdldEFQSVNjaGVtYTxcclxuICBDIGV4dGVuZHMgQ29tbWVyY2VBUEk8YW55PixcclxuICBTIGV4dGVuZHMgQVBJU2NoZW1hcyA9IEFQSVNjaGVtYXNcclxuPiA9IHtcclxuICBzY2hlbWE6IFNcclxuICBlbmRwb2ludDogRW5kcG9pbnRDb250ZXh0PEMsIFNbJ2VuZHBvaW50J10+XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEVuZHBvaW50Q29udGV4dDxcclxuICBDIGV4dGVuZHMgQ29tbWVyY2VBUEksXHJcbiAgRSBleHRlbmRzIEVuZHBvaW50U2NoZW1hQmFzZVxyXG4+ID0ge1xyXG4gIGhhbmRsZXI6IEVuZHBvaW50PEMsIEU+XHJcbiAgaGFuZGxlcnM6IEVuZHBvaW50SGFuZGxlcnM8QywgRT5cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgRW5kcG9pbnRTY2hlbWFCYXNlID0ge1xyXG4gIG9wdGlvbnM6IHt9XHJcbiAgaGFuZGxlcnM6IHtcclxuICAgIFtrOiBzdHJpbmddOiB7IGRhdGE/OiBhbnk7IGJvZHk/OiBhbnkgfVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgRW5kcG9pbnQ8XHJcbiAgQyBleHRlbmRzIENvbW1lcmNlQVBJLFxyXG4gIEUgZXh0ZW5kcyBFbmRwb2ludFNjaGVtYUJhc2VcclxuPiA9IEFQSUVuZHBvaW50PEMsIEVuZHBvaW50SGFuZGxlcnM8QywgRT4sIGFueSwgRVsnb3B0aW9ucyddPlxyXG5cclxuZXhwb3J0IHR5cGUgRW5kcG9pbnRIYW5kbGVyczxcclxuICBDIGV4dGVuZHMgQ29tbWVyY2VBUEksXHJcbiAgRSBleHRlbmRzIEVuZHBvaW50U2NoZW1hQmFzZVxyXG4+ID0ge1xyXG4gIFtIIGluIGtleW9mIEVbJ2hhbmRsZXJzJ11dOiBBUElIYW5kbGVyPFxyXG4gICAgQyxcclxuICAgIEVuZHBvaW50SGFuZGxlcnM8QywgRT4sXHJcbiAgICBFWydoYW5kbGVycyddW0hdWydkYXRhJ10sXHJcbiAgICBFWydoYW5kbGVycyddW0hdWydib2R5J10sXHJcbiAgICBFWydvcHRpb25zJ11cclxuICA+XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEFQSVByb3ZpZGVyID0ge1xyXG4gIGNvbmZpZzogQ29tbWVyY2VBUElDb25maWdcclxuICBvcGVyYXRpb25zOiBBUElPcGVyYXRpb25zPGFueT5cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgQ29tbWVyY2VBUEk8UCBleHRlbmRzIEFQSVByb3ZpZGVyID0gQVBJUHJvdmlkZXI+ID1cclxuICBDb21tZXJjZUFQSUNvcmU8UD4gJiBBbGxPcGVyYXRpb25zPFA+XHJcblxyXG5leHBvcnQgY2xhc3MgQ29tbWVyY2VBUElDb3JlPFAgZXh0ZW5kcyBBUElQcm92aWRlciA9IEFQSVByb3ZpZGVyPiB7XHJcbiAgY29uc3RydWN0b3IocmVhZG9ubHkgcHJvdmlkZXI6IFApIHt9XHJcblxyXG4gIGdldENvbmZpZyh1c2VyQ29uZmlnOiBQYXJ0aWFsPFBbJ2NvbmZpZyddPiA9IHt9KTogUFsnY29uZmlnJ10ge1xyXG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHVzZXJDb25maWcpLnJlZHVjZShcclxuICAgICAgKGNmZywgW2tleSwgdmFsdWVdKSA9PiBPYmplY3QuYXNzaWduKGNmZywgeyBba2V5XTogdmFsdWUgfSksXHJcbiAgICAgIHsgLi4udGhpcy5wcm92aWRlci5jb25maWcgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgc2V0Q29uZmlnKG5ld0NvbmZpZzogUGFydGlhbDxQWydjb25maWcnXT4pIHtcclxuICAgIE9iamVjdC5hc3NpZ24odGhpcy5wcm92aWRlci5jb25maWcsIG5ld0NvbmZpZylcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb21tZXJjZUFwaTxQIGV4dGVuZHMgQVBJUHJvdmlkZXI+KFxyXG4gIGN1c3RvbVByb3ZpZGVyOiBQXHJcbik6IENvbW1lcmNlQVBJPFA+IHtcclxuICBjb25zdCBjb21tZXJjZSA9IE9iamVjdC5hc3NpZ24oXHJcbiAgICBuZXcgQ29tbWVyY2VBUElDb3JlKGN1c3RvbVByb3ZpZGVyKSxcclxuICAgIGRlZmF1bHRPcGVyYXRpb25zIGFzIEFsbE9wZXJhdGlvbnM8UD5cclxuICApXHJcbiAgY29uc3Qgb3BzID0gY3VzdG9tUHJvdmlkZXIub3BlcmF0aW9uc1xyXG5cclxuICBPUEVSQVRJT05TLmZvckVhY2goKGspID0+IHtcclxuICAgIGNvbnN0IG9wID0gb3BzW2tdXHJcbiAgICBpZiAob3ApIHtcclxuICAgICAgY29tbWVyY2Vba10gPSBvcCh7IGNvbW1lcmNlIH0pIGFzIEFsbE9wZXJhdGlvbnM8UD5bdHlwZW9mIGtdXHJcbiAgICB9XHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIGNvbW1lcmNlXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRFbmRwb2ludDxcclxuICBQIGV4dGVuZHMgQVBJUHJvdmlkZXIsXHJcbiAgVCBleHRlbmRzIEdldEFQSVNjaGVtYTxhbnksIGFueT5cclxuPihcclxuICBjb21tZXJjZTogQ29tbWVyY2VBUEk8UD4sXHJcbiAgY29udGV4dDogVFsnZW5kcG9pbnQnXSAmIHtcclxuICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICBvcHRpb25zPzogVFsnc2NoZW1hJ11bJ2VuZHBvaW50J11bJ29wdGlvbnMnXVxyXG4gIH1cclxuKTogTmV4dEFwaUhhbmRsZXIge1xyXG4gIGNvbnN0IGNmZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb250ZXh0LmNvbmZpZylcclxuXHJcbiAgcmV0dXJuIGZ1bmN0aW9uIGFwaUhhbmRsZXIocmVxLCByZXMpIHtcclxuICAgIHJldHVybiBjb250ZXh0LmhhbmRsZXIoe1xyXG4gICAgICByZXEsXHJcbiAgICAgIHJlcyxcclxuICAgICAgY29tbWVyY2UsXHJcbiAgICAgIGNvbmZpZzogY2ZnLFxyXG4gICAgICBoYW5kbGVyczogY29udGV4dC5oYW5kbGVycyxcclxuICAgICAgb3B0aW9uczogY29udGV4dC5vcHRpb25zID8/IHt9LFxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVFbmRwb2ludCA9XHJcbiAgPEFQSSBleHRlbmRzIEdldEFQSVNjaGVtYTxhbnksIGFueT4+KGVuZHBvaW50OiBBUElbJ2VuZHBvaW50J10pID0+XHJcbiAgPFAgZXh0ZW5kcyBBUElQcm92aWRlcj4oXHJcbiAgICBjb21tZXJjZTogQ29tbWVyY2VBUEk8UD4sXHJcbiAgICBjb250ZXh0PzogUGFydGlhbDxBUElbJ2VuZHBvaW50J10+ICYge1xyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBvcHRpb25zPzogQVBJWydzY2hlbWEnXVsnZW5kcG9pbnQnXVsnb3B0aW9ucyddXHJcbiAgICB9XHJcbiAgKTogTmV4dEFwaUhhbmRsZXIgPT4ge1xyXG4gICAgcmV0dXJuIGdldEVuZHBvaW50KGNvbW1lcmNlLCB7IC4uLmVuZHBvaW50LCAuLi5jb250ZXh0IH0pXHJcbiAgfVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDb21tZXJjZUFQSUNvbmZpZyB7XHJcbiAgbG9jYWxlPzogc3RyaW5nXHJcbiAgbG9jYWxlcz86IHN0cmluZ1tdXHJcbiAgY29tbWVyY2VVcmw6IHN0cmluZ1xyXG4gIGFwaVRva2VuOiBzdHJpbmdcclxuICBjYXJ0Q29va2llOiBzdHJpbmdcclxuICBjYXJ0Q29va2llTWF4QWdlOiBudW1iZXJcclxuICBjdXN0b21lckNvb2tpZTogc3RyaW5nXHJcbiAgZmV0Y2g8RGF0YSA9IGFueSwgVmFyaWFibGVzID0gYW55PihcclxuICAgIHF1ZXJ5OiBzdHJpbmcsXHJcbiAgICBxdWVyeURhdGE/OiBDb21tZXJjZUFQSUZldGNoT3B0aW9uczxWYXJpYWJsZXM+LFxyXG4gICAgZmV0Y2hPcHRpb25zPzogUmVxdWVzdEluaXRcclxuICApOiBQcm9taXNlPEdyYXBoUUxGZXRjaGVyUmVzdWx0PERhdGE+PlxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBHcmFwaFFMRmV0Y2hlcjxcclxuICBEYXRhIGV4dGVuZHMgR3JhcGhRTEZldGNoZXJSZXN1bHQgPSBHcmFwaFFMRmV0Y2hlclJlc3VsdCxcclxuICBWYXJpYWJsZXMgPSBhbnlcclxuPiA9IChcclxuICBxdWVyeTogc3RyaW5nLFxyXG4gIHF1ZXJ5RGF0YT86IENvbW1lcmNlQVBJRmV0Y2hPcHRpb25zPFZhcmlhYmxlcz4sXHJcbiAgZmV0Y2hPcHRpb25zPzogUmVxdWVzdEluaXRcclxuKSA9PiBQcm9taXNlPERhdGE+XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEdyYXBoUUxGZXRjaGVyUmVzdWx0PERhdGEgPSBhbnk+IHtcclxuICBkYXRhOiBEYXRhXHJcbiAgcmVzOiBSZXNwb25zZVxyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1lcmNlQVBJRmV0Y2hPcHRpb25zPFZhcmlhYmxlcz4ge1xyXG4gIHZhcmlhYmxlcz86IFZhcmlhYmxlc1xyXG4gIHByZXZpZXc/OiBib29sZWFuXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUgeyBTZXJ2ZXJSZXNwb25zZSB9IGZyb20gJ2h0dHAnXHJcbmltcG9ydCB0eXBlIHsgTG9naW5PcGVyYXRpb24gfSBmcm9tICcuLi90eXBlcy9sb2dpbidcclxuaW1wb3J0IHR5cGUgeyBHZXRBbGxQYWdlc09wZXJhdGlvbiwgR2V0UGFnZU9wZXJhdGlvbiB9IGZyb20gJy4uL3R5cGVzL3BhZ2UnXHJcbmltcG9ydCB0eXBlIHsgR2V0U2l0ZUluZm9PcGVyYXRpb24gfSBmcm9tICcuLi90eXBlcy9zaXRlJ1xyXG5pbXBvcnQgdHlwZSB7IEdldEN1c3RvbWVyV2lzaGxpc3RPcGVyYXRpb24gfSBmcm9tICcuLi90eXBlcy93aXNobGlzdCdcclxuaW1wb3J0IHR5cGUge1xyXG4gIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbixcclxuICBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbixcclxuICBHZXRQcm9kdWN0T3BlcmF0aW9uLFxyXG59IGZyb20gJy4uL3R5cGVzL3Byb2R1Y3QnXHJcbmltcG9ydCB0eXBlIHsgQVBJUHJvdmlkZXIsIENvbW1lcmNlQVBJIH0gZnJvbSAnLidcclxuXHJcbmNvbnN0IG5vb3AgPSAoKSA9PiB7XHJcbiAgdGhyb3cgbmV3IEVycm9yKCdOb3QgaW1wbGVtZW50ZWQnKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgT1BFUkFUSU9OUyA9IFtcclxuICAnbG9naW4nLFxyXG4gICdnZXRBbGxQYWdlcycsXHJcbiAgJ2dldFBhZ2UnLFxyXG4gICdnZXRTaXRlSW5mbycsXHJcbiAgJ2dldEN1c3RvbWVyV2lzaGxpc3QnLFxyXG4gICdnZXRBbGxQcm9kdWN0UGF0aHMnLFxyXG4gICdnZXRBbGxQcm9kdWN0cycsXHJcbiAgJ2dldFByb2R1Y3QnLFxyXG5dIGFzIGNvbnN0XHJcblxyXG5leHBvcnQgY29uc3QgZGVmYXVsdE9wZXJhdGlvbnMgPSBPUEVSQVRJT05TLnJlZHVjZSgob3BzLCBrKSA9PiB7XHJcbiAgb3BzW2tdID0gbm9vcFxyXG4gIHJldHVybiBvcHNcclxufSwge30gYXMgeyBbSyBpbiBBbGxvd2VkT3BlcmF0aW9uc106IHR5cGVvZiBub29wIH0pXHJcblxyXG5leHBvcnQgdHlwZSBBbGxvd2VkT3BlcmF0aW9ucyA9IHR5cGVvZiBPUEVSQVRJT05TW251bWJlcl1cclxuXHJcbmV4cG9ydCB0eXBlIE9wZXJhdGlvbnM8UCBleHRlbmRzIEFQSVByb3ZpZGVyPiA9IHtcclxuICBsb2dpbjoge1xyXG4gICAgPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIHJlczogU2VydmVyUmVzcG9uc2VcclxuICAgIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgICA8VCBleHRlbmRzIExvZ2luT3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHJlczogU2VydmVyUmVzcG9uc2VcclxuICAgICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICAgICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG4gIH1cclxuXHJcbiAgZ2V0QWxsUGFnZXM6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUGFnZXNPcGVyYXRpb24+KG9wdHM/OiB7XHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRBbGxQYWdlc09wZXJhdGlvbj4oXHJcbiAgICAgIG9wdHM6IHtcclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcblxyXG4gIGdldFBhZ2U6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRQYWdlT3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcblxyXG4gIGdldFNpdGVJbmZvOiB7XHJcbiAgICA8VCBleHRlbmRzIEdldFNpdGVJbmZvT3BlcmF0aW9uPihvcHRzOiB7XHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRTaXRlSW5mb09wZXJhdGlvbj4oXHJcbiAgICAgIG9wdHM6IHtcclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcblxyXG4gIGdldEN1c3RvbWVyV2lzaGxpc3Q6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIGluY2x1ZGVQcm9kdWN0cz86IGJvb2xlYW5cclxuICAgIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgICA8VCBleHRlbmRzIEdldEN1c3RvbWVyV2lzaGxpc3RPcGVyYXRpb24+KFxyXG4gICAgICBvcHRzOiB7XHJcbiAgICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgICAgaW5jbHVkZVByb2R1Y3RzPzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRBbGxQcm9kdWN0UGF0aHM6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uPihvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0UGF0aHNPcGVyYXRpb24+KFxyXG4gICAgICBvcHRzOiB7XHJcbiAgICAgICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRBbGxQcm9kdWN0czoge1xyXG4gICAgPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM/OiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdHNPcGVyYXRpb24+KFxyXG4gICAgICBvcHRzOiB7XHJcbiAgICAgICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcblxyXG4gIGdldFByb2R1Y3Q6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0UHJvZHVjdE9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBbJ2NvbmZpZyddXHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRQcm9kdWN0T3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEFQSU9wZXJhdGlvbnM8UCBleHRlbmRzIEFQSVByb3ZpZGVyPiA9IHtcclxuICBbSyBpbiBrZXlvZiBPcGVyYXRpb25zPFA+XT86IChjdHg6IE9wZXJhdGlvbkNvbnRleHQ8UD4pID0+IE9wZXJhdGlvbnM8UD5bS11cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgQWxsT3BlcmF0aW9uczxQIGV4dGVuZHMgQVBJUHJvdmlkZXI+ID0ge1xyXG4gIFtLIGluIGtleW9mIEFQSU9wZXJhdGlvbnM8UD5dLT86IFBbJ29wZXJhdGlvbnMnXVtLXSBleHRlbmRzIChcclxuICAgIC4uLmFyZ3M6IGFueVxyXG4gICkgPT4gYW55XHJcbiAgICA/IFJldHVyblR5cGU8UFsnb3BlcmF0aW9ucyddW0tdPlxyXG4gICAgOiB0eXBlb2Ygbm9vcFxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBPcGVyYXRpb25Db250ZXh0PFAgZXh0ZW5kcyBBUElQcm92aWRlcj4gPSB7XHJcbiAgY29tbWVyY2U6IENvbW1lcmNlQVBJPFA+XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIE9wZXJhdGlvbk9wdGlvbnMgPVxyXG4gIHwgeyBxdWVyeTogc3RyaW5nOyB1cmw/OiBuZXZlciB9XHJcbiAgfCB7IHF1ZXJ5PzogbmV2ZXI7IHVybDogc3RyaW5nIH1cclxuIiwiaW1wb3J0IHR5cGUgeyBSZXNwb25zZSB9IGZyb20gJ0B2ZXJjZWwvZmV0Y2gnXHJcblxyXG5leHBvcnQgY2xhc3MgQ29tbWVyY2VBUElFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlclxyXG4gIHJlczogUmVzcG9uc2VcclxuICBkYXRhOiBhbnlcclxuXHJcbiAgY29uc3RydWN0b3IobXNnOiBzdHJpbmcsIHJlczogUmVzcG9uc2UsIGRhdGE/OiBhbnkpIHtcclxuICAgIHN1cGVyKG1zZylcclxuICAgIHRoaXMubmFtZSA9ICdDb21tZXJjZUFwaUVycm9yJ1xyXG4gICAgdGhpcy5zdGF0dXMgPSByZXMuc3RhdHVzXHJcbiAgICB0aGlzLnJlcyA9IHJlc1xyXG4gICAgdGhpcy5kYXRhID0gZGF0YVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIENvbW1lcmNlTmV0d29ya0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIGNvbnN0cnVjdG9yKG1zZzogc3RyaW5nKSB7XHJcbiAgICBzdXBlcihtc2cpXHJcbiAgICB0aGlzLm5hbWUgPSAnQ29tbWVyY2VOZXR3b3JrRXJyb3InXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnXHJcblxyXG5leHBvcnQgdHlwZSBIVFRQX01FVEhPRFMgPSAnT1BUSU9OUycgfCAnR0VUJyB8ICdQT1NUJyB8ICdQVVQnIHwgJ0RFTEVURSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQWxsb3dlZE1ldGhvZChcclxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxyXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlLFxyXG4gIGFsbG93ZWRNZXRob2RzOiBIVFRQX01FVEhPRFNbXVxyXG4pIHtcclxuICBjb25zdCBtZXRob2RzID0gYWxsb3dlZE1ldGhvZHMuaW5jbHVkZXMoJ09QVElPTlMnKVxyXG4gICAgPyBhbGxvd2VkTWV0aG9kc1xyXG4gICAgOiBbLi4uYWxsb3dlZE1ldGhvZHMsICdPUFRJT05TJ11cclxuXHJcbiAgaWYgKCFyZXEubWV0aG9kIHx8ICFtZXRob2RzLmluY2x1ZGVzKHJlcS5tZXRob2QpKSB7XHJcbiAgICByZXMuc3RhdHVzKDQwNSlcclxuICAgIHJlcy5zZXRIZWFkZXIoJ0FsbG93JywgbWV0aG9kcy5qb2luKCcsICcpKVxyXG4gICAgcmVzLmVuZCgpXHJcbiAgICByZXR1cm4gZmFsc2VcclxuICB9XHJcblxyXG4gIGlmIChyZXEubWV0aG9kID09PSAnT1BUSU9OUycpIHtcclxuICAgIHJlcy5zdGF0dXMoMjAwKVxyXG4gICAgcmVzLnNldEhlYWRlcignQWxsb3cnLCBtZXRob2RzLmpvaW4oJywgJykpXHJcbiAgICByZXMuc2V0SGVhZGVyKCdDb250ZW50LUxlbmd0aCcsICcwJylcclxuICAgIHJlcy5lbmQoKVxyXG4gICAgcmV0dXJuIGZhbHNlXHJcbiAgfVxyXG5cclxuICByZXR1cm4gdHJ1ZVxyXG59XHJcbiIsImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnXHJcbmltcG9ydCBpc0FsbG93ZWRNZXRob2QsIHsgSFRUUF9NRVRIT0RTIH0gZnJvbSAnLi9pcy1hbGxvd2VkLW1ldGhvZCdcclxuaW1wb3J0IHsgQVBJSGFuZGxlciB9IGZyb20gJy4vdHlwZXMnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc0FsbG93ZWRPcGVyYXRpb24oXHJcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcclxuICByZXM6IE5leHRBcGlSZXNwb25zZSxcclxuICBhbGxvd2VkT3BlcmF0aW9uczogeyBbayBpbiBIVFRQX01FVEhPRFNdPzogQVBJSGFuZGxlcjxhbnksIGFueT4gfVxyXG4pIHtcclxuICBjb25zdCBtZXRob2RzID0gT2JqZWN0LmtleXMoYWxsb3dlZE9wZXJhdGlvbnMpIGFzIEhUVFBfTUVUSE9EU1tdXHJcbiAgY29uc3QgYWxsb3dlZE1ldGhvZHMgPSBtZXRob2RzLnJlZHVjZTxIVFRQX01FVEhPRFNbXT4oKGFyciwgbWV0aG9kKSA9PiB7XHJcbiAgICBpZiAoYWxsb3dlZE9wZXJhdGlvbnNbbWV0aG9kXSkge1xyXG4gICAgICBhcnIucHVzaChtZXRob2QpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXJyXHJcbiAgfSwgW10pXHJcblxyXG4gIHJldHVybiBpc0FsbG93ZWRNZXRob2QocmVxLCByZXMsIGFsbG93ZWRNZXRob2RzKVxyXG59XHJcbiIsImV4cG9ydCB0eXBlIEVycm9yRGF0YSA9IHtcclxuICBtZXNzYWdlOiBzdHJpbmdcclxuICBjb2RlPzogc3RyaW5nXHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEVycm9yUHJvcHMgPSB7XHJcbiAgY29kZT86IHN0cmluZ1xyXG59ICYgKFxyXG4gIHwgeyBtZXNzYWdlOiBzdHJpbmc7IGVycm9ycz86IG5ldmVyIH1cclxuICB8IHsgbWVzc2FnZT86IG5ldmVyOyBlcnJvcnM6IEVycm9yRGF0YVtdIH1cclxuKVxyXG5cclxuZXhwb3J0IGNsYXNzIENvbW1lcmNlRXJyb3IgZXh0ZW5kcyBFcnJvciB7XHJcbiAgY29kZT86IHN0cmluZ1xyXG4gIGVycm9yczogRXJyb3JEYXRhW11cclxuXHJcbiAgY29uc3RydWN0b3IoeyBtZXNzYWdlLCBjb2RlLCBlcnJvcnMgfTogRXJyb3JQcm9wcykge1xyXG4gICAgY29uc3QgZXJyb3I6IEVycm9yRGF0YSA9IG1lc3NhZ2VcclxuICAgICAgPyB7IG1lc3NhZ2UsIC4uLihjb2RlID8geyBjb2RlIH0gOiB7fSkgfVxyXG4gICAgICA6IGVycm9ycyFbMF1cclxuXHJcbiAgICBzdXBlcihlcnJvci5tZXNzYWdlKVxyXG4gICAgdGhpcy5lcnJvcnMgPSBtZXNzYWdlID8gW2Vycm9yXSA6IGVycm9ycyFcclxuXHJcbiAgICBpZiAoZXJyb3IuY29kZSkgdGhpcy5jb2RlID0gZXJyb3IuY29kZVxyXG4gIH1cclxufVxyXG5cclxuLy8gVXNlZCBmb3IgZXJyb3JzIHRoYXQgY29tZSBmcm9tIGEgYmFkIGltcGxlbWVudGF0aW9uIG9mIHRoZSBob29rc1xyXG5leHBvcnQgY2xhc3MgVmFsaWRhdGlvbkVycm9yIGV4dGVuZHMgQ29tbWVyY2VFcnJvciB7XHJcbiAgY29uc3RydWN0b3Iob3B0aW9uczogRXJyb3JQcm9wcykge1xyXG4gICAgc3VwZXIob3B0aW9ucylcclxuICAgIHRoaXMuY29kZSA9ICd2YWxpZGF0aW9uX2Vycm9yJ1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEZldGNoZXJFcnJvciBleHRlbmRzIENvbW1lcmNlRXJyb3Ige1xyXG4gIHN0YXR1czogbnVtYmVyXHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgb3B0aW9uczoge1xyXG4gICAgICBzdGF0dXM6IG51bWJlclxyXG4gICAgfSAmIEVycm9yUHJvcHNcclxuICApIHtcclxuICAgIHN1cGVyKG9wdGlvbnMpXHJcbiAgICB0aGlzLnN0YXR1cyA9IG9wdGlvbnMuc3RhdHVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IGdldENvbW1lcmNlQXBpIH0gZnJvbSAnQGZyYW1ld29yay9hcGknXHJcblxyXG5leHBvcnQgZGVmYXVsdCBnZXRDb21tZXJjZUFwaSgpXHJcbiIsImltcG9ydCBjYXJ0QXBpIGZyb20gJ0BmcmFtZXdvcmsvYXBpL2VuZHBvaW50cy9jYXJ0J1xyXG5pbXBvcnQgY29tbWVyY2UgZnJvbSAnQGxpYi9hcGkvY29tbWVyY2UnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjYXJ0QXBpKGNvbW1lcmNlKVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAdmVyY2VsL2ZldGNoXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjb29raWVcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImltbXV0YWJpbGl0eS1oZWxwZXJcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=