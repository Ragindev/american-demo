(function() {
var exports = {};
exports.id = "pages/api/customer";
exports.ids = ["pages/api/customer"];
exports.modules = {

/***/ "./framework/bigcommerce/api/endpoints/customer/get-logged-in-customer.ts":
/*!********************************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/customer/get-logged-in-customer.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getLoggedInCustomerQuery": function() { return /* binding */ getLoggedInCustomerQuery; }
/* harmony export */ });
const getLoggedInCustomerQuery =
/* GraphQL */
`
  query getLoggedInCustomer {
    customer {
      entityId
      firstName
      lastName
      email
      company
      customerGroupId
      notes
      phone
      addressCount
      attributeCount
      storeCredit {
        value
        currencyCode
      }
    }
  }
`;

const getLoggedInCustomer = async ({
  req,
  res,
  config
}) => {
  const token = req.cookies[config.customerCookie];

  if (token) {
    const {
      data
    } = await config.fetch(getLoggedInCustomerQuery, undefined, {
      headers: {
        cookie: `${config.customerCookie}=${token}`
      }
    });
    const {
      customer
    } = data;

    if (!customer) {
      return res.status(400).json({
        data: null,
        errors: [{
          message: 'Customer not found',
          code: 'not_found'
        }]
      });
    }

    return res.status(200).json({
      data: {
        customer
      }
    });
  }

  res.status(200).json({
    data: null
  });
};

/* harmony default export */ __webpack_exports__["default"] = (getLoggedInCustomer);

/***/ }),

/***/ "./framework/bigcommerce/api/endpoints/customer/index.ts":
/*!***************************************************************!*\
  !*** ./framework/bigcommerce/api/endpoints/customer/index.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "handlers": function() { return /* binding */ handlers; }
/* harmony export */ });
/* harmony import */ var _commerce_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @commerce/api */ "./framework/commerce/api/index.ts");
/* harmony import */ var _commerce_api_endpoints_customer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @commerce/api/endpoints/customer */ "./framework/commerce/api/endpoints/customer/index.ts");
/* harmony import */ var _get_logged_in_customer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./get-logged-in-customer */ "./framework/bigcommerce/api/endpoints/customer/get-logged-in-customer.ts");



const handlers = {
  getLoggedInCustomer: _get_logged_in_customer__WEBPACK_IMPORTED_MODULE_0__.default
};
const customerApi = (0,_commerce_api__WEBPACK_IMPORTED_MODULE_1__.createEndpoint)({
  handler: _commerce_api_endpoints_customer__WEBPACK_IMPORTED_MODULE_2__.default,
  handlers
});
/* harmony default export */ __webpack_exports__["default"] = (customerApi);

/***/ }),

/***/ "./framework/bigcommerce/api/fragments/category-tree.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/fragments/category-tree.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "categoryTreeItemFragment": function() { return /* binding */ categoryTreeItemFragment; }
/* harmony export */ });
const categoryTreeItemFragment =
/* GraphQL */
`
  fragment categoryTreeItem on CategoryTreeItem {
    entityId
    name
    path
    description
    productCount
  }
`;

/***/ }),

/***/ "./framework/bigcommerce/api/fragments/product.ts":
/*!********************************************************!*\
  !*** ./framework/bigcommerce/api/fragments/product.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "productPrices": function() { return /* binding */ productPrices; },
/* harmony export */   "swatchOptionFragment": function() { return /* binding */ swatchOptionFragment; },
/* harmony export */   "multipleChoiceOptionFragment": function() { return /* binding */ multipleChoiceOptionFragment; },
/* harmony export */   "productInfoFragment": function() { return /* binding */ productInfoFragment; },
/* harmony export */   "productConnectionFragment": function() { return /* binding */ productConnectionFragment; }
/* harmony export */ });
const productPrices =
/* GraphQL */
`
  fragment productPrices on Prices {
    price {
      value
      currencyCode
    }
    salePrice {
      value
      currencyCode
    }
    retailPrice {
      value
      currencyCode
    }
  }
`;
const swatchOptionFragment =
/* GraphQL */
`
  fragment swatchOption on SwatchOptionValue {
    isDefault
    hexColors
  }
`;
const multipleChoiceOptionFragment =
/* GraphQL */
`
  fragment multipleChoiceOption on MultipleChoiceOption {
    values {
      edges {
        node {
          label
          ...swatchOption
        }
      }
    }
  }

  ${swatchOptionFragment}
`;
const productInfoFragment =
/* GraphQL */
`
  fragment productInfo on Product {
    entityId
    name
    path
    brand {
      entityId
    }
    description
    prices {
      ...productPrices
    }
    images {
      edges {
        node {
          urlOriginal
          altText
          isDefault
        }
      }
    }
    variants {
      edges {
        node {
          entityId
          defaultImage {
            urlOriginal
            altText
            isDefault
          }
        }
      }
    }
    productOptions {
      edges {
        node {
          __typename
          entityId
          displayName
          ...multipleChoiceOption
        }
      }
    }
    localeMeta: metafields(namespace: $locale, keys: ["name", "description"])
      @include(if: $hasLocale) {
      edges {
        node {
          key
          value
        }
      }
    }
  }

  ${productPrices}
  ${multipleChoiceOptionFragment}
`;
const productConnectionFragment =
/* GraphQL */
`
  fragment productConnnection on ProductConnection {
    pageInfo {
      startCursor
      endCursor
    }
    edges {
      cursor
      node {
        ...productInfo
      }
    }
  }

  ${productInfoFragment}
`;

/***/ }),

/***/ "./framework/bigcommerce/api/index.ts":
/*!********************************************!*\
  !*** ./framework/bigcommerce/api/index.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "provider": function() { return /* binding */ provider; },
/* harmony export */   "getCommerceApi": function() { return /* binding */ getCommerceApi; }
/* harmony export */ });
/* harmony import */ var _commerce_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @commerce/api */ "./framework/commerce/api/index.ts");
/* harmony import */ var _utils_fetch_graphql_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/fetch-graphql-api */ "./framework/bigcommerce/api/utils/fetch-graphql-api.ts");
/* harmony import */ var _utils_fetch_store_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/fetch-store-api */ "./framework/bigcommerce/api/utils/fetch-store-api.ts");
/* harmony import */ var _operations_login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./operations/login */ "./framework/bigcommerce/api/operations/login.ts");
/* harmony import */ var _operations_get_all_pages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./operations/get-all-pages */ "./framework/bigcommerce/api/operations/get-all-pages.ts");
/* harmony import */ var _operations_get_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./operations/get-page */ "./framework/bigcommerce/api/operations/get-page.ts");
/* harmony import */ var _operations_get_site_info__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./operations/get-site-info */ "./framework/bigcommerce/api/operations/get-site-info.ts");
/* harmony import */ var _operations_get_customer_wishlist__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./operations/get-customer-wishlist */ "./framework/bigcommerce/api/operations/get-customer-wishlist.ts");
/* harmony import */ var _operations_get_all_product_paths__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./operations/get-all-product-paths */ "./framework/bigcommerce/api/operations/get-all-product-paths.ts");
/* harmony import */ var _operations_get_all_products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./operations/get-all-products */ "./framework/bigcommerce/api/operations/get-all-products.ts");
/* harmony import */ var _operations_get_product__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./operations/get-product */ "./framework/bigcommerce/api/operations/get-product.ts");
var _process$env$BIGCOMME;












const API_URL = process.env.BIGCOMMERCE_STOREFRONT_API_URL;
const API_TOKEN = process.env.BIGCOMMERCE_STOREFRONT_API_TOKEN;
const STORE_API_URL = process.env.BIGCOMMERCE_STORE_API_URL;
const STORE_API_TOKEN = process.env.BIGCOMMERCE_STORE_API_TOKEN;
const STORE_API_CLIENT_ID = process.env.BIGCOMMERCE_STORE_API_CLIENT_ID;
const STORE_CHANNEL_ID = process.env.BIGCOMMERCE_CHANNEL_ID;
const STORE_URL = process.env.BIGCOMMERCE_STORE_URL;
const CLIENT_SECRET = process.env.BIGCOMMERCE_STORE_API_CLIENT_SECRET;
const STOREFRONT_HASH = process.env.BIGCOMMERCE_STORE_API_STORE_HASH;

if (!API_URL) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_URL is missing and it's required to access your store`);
}

if (!API_TOKEN) {
  throw new Error(`The environment variable BIGCOMMERCE_STOREFRONT_API_TOKEN is missing and it's required to access your store`);
}

if (!(STORE_API_URL && STORE_API_TOKEN && STORE_API_CLIENT_ID)) {
  throw new Error(`The environment variables BIGCOMMERCE_STORE_API_URL, BIGCOMMERCE_STORE_API_TOKEN, BIGCOMMERCE_STORE_API_CLIENT_ID have to be set in order to access the REST API of your store`);
}

const ONE_DAY = 60 * 60 * 24;
const config = {
  commerceUrl: API_URL,
  apiToken: API_TOKEN,
  customerCookie: 'SHOP_TOKEN',
  cartCookie: (_process$env$BIGCOMME = process.env.BIGCOMMERCE_CART_COOKIE) !== null && _process$env$BIGCOMME !== void 0 ? _process$env$BIGCOMME : 'bc_cartId',
  cartCookieMaxAge: ONE_DAY * 30,
  fetch: (0,_utils_fetch_graphql_api__WEBPACK_IMPORTED_MODULE_0__.default)(() => getCommerceApi().getConfig()),
  applyLocale: true,
  // REST API only
  storeApiUrl: STORE_API_URL,
  storeApiToken: STORE_API_TOKEN,
  storeApiClientId: STORE_API_CLIENT_ID,
  storeChannelId: STORE_CHANNEL_ID,
  storeUrl: STORE_URL,
  storeApiClientSecret: CLIENT_SECRET,
  storeHash: STOREFRONT_HASH,
  storeApiFetch: (0,_utils_fetch_store_api__WEBPACK_IMPORTED_MODULE_1__.default)(() => getCommerceApi().getConfig())
};
const operations = {
  login: _operations_login__WEBPACK_IMPORTED_MODULE_2__.default,
  getAllPages: _operations_get_all_pages__WEBPACK_IMPORTED_MODULE_3__.default,
  getPage: _operations_get_page__WEBPACK_IMPORTED_MODULE_4__.default,
  getSiteInfo: _operations_get_site_info__WEBPACK_IMPORTED_MODULE_5__.default,
  getCustomerWishlist: _operations_get_customer_wishlist__WEBPACK_IMPORTED_MODULE_6__.default,
  getAllProductPaths: _operations_get_all_product_paths__WEBPACK_IMPORTED_MODULE_7__.default,
  getAllProducts: _operations_get_all_products__WEBPACK_IMPORTED_MODULE_8__.default,
  getProduct: _operations_get_product__WEBPACK_IMPORTED_MODULE_9__.default
};
const provider = {
  config,
  operations
};
function getCommerceApi(customProvider = provider) {
  return (0,_commerce_api__WEBPACK_IMPORTED_MODULE_10__.getCommerceApi)(customProvider);
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-pages.ts":
/*!***************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-pages.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getAllPagesOperation; }
/* harmony export */ });
function getAllPagesOperation({
  commerce
}) {
  async function getAllPages({
    config,
    preview
  } = {}) {
    var _ref;

    const cfg = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch('/v3/content/pages');
    const pages = (_ref = data) !== null && _ref !== void 0 ? _ref : [];
    return {
      pages: preview ? pages : pages.filter(p => p.is_visible)
    };
  }

  return getAllPages;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-product-paths.ts":
/*!***********************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-product-paths.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAllProductPathsQuery": function() { return /* binding */ getAllProductPathsQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductPathsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");

const getAllProductPathsQuery =
/* GraphQL */
`
  query getAllProductPaths($first: Int = 100) {
    site {
      products(first: $first) {
        edges {
          node {
            path
          }
        }
      }
    }
  }
`;
function getAllProductPathsOperation({
  commerce
}) {
  async function getAllProductPaths({
    query = getAllProductPathsQuery,
    variables,
    config
  } = {}) {
    var _data$site, _data$site$products;

    config = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const products = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$products = _data$site.products) === null || _data$site$products === void 0 ? void 0 : _data$site$products.edges;
    return {
      products: (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_0__.default)(products).map(({
        node
      }) => node)
    };
  }

  return getAllProductPaths;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-all-products.ts":
/*!******************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-all-products.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAllProductsQuery": function() { return /* binding */ getAllProductsQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");
/* harmony import */ var _utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/set-product-locale-meta */ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts");
/* harmony import */ var _fragments_product__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/product */ "./framework/bigcommerce/api/fragments/product.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");




const getAllProductsQuery =
/* GraphQL */
`
  query getAllProducts(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $entityIds: [Int!]
    $first: Int = 10
    $products: Boolean = false
    $featuredProducts: Boolean = false
    $bestSellingProducts: Boolean = false
    $newestProducts: Boolean = false
  ) {
    site {
      products(first: $first, entityIds: $entityIds) @include(if: $products) {
        ...productConnnection
      }
      featuredProducts(first: $first) @include(if: $featuredProducts) {
        ...productConnnection
      }
      bestSellingProducts(first: $first) @include(if: $bestSellingProducts) {
        ...productConnnection
      }
      newestProducts(first: $first) @include(if: $newestProducts) {
        ...productConnnection
      }
    }
  }

  ${_fragments_product__WEBPACK_IMPORTED_MODULE_0__.productConnectionFragment}
`;

function getProductsType(relevance) {
  switch (relevance) {
    case 'featured':
      return 'featuredProducts';

    case 'best_selling':
      return 'bestSellingProducts';

    case 'newest':
      return 'newestProducts';

    default:
      return 'products';
  }
}

function getAllProductsOperation({
  commerce
}) {
  async function getAllProducts({
    query = getAllProductsQuery,
    variables: vars = {},
    config: cfg
  } = {}) {
    var _data$site, _data$site$field;

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const field = getProductsType(vars.relevance);
    const variables = {
      locale,
      hasLocale: !!locale
    };
    variables[field] = true;
    if (vars.first) variables.first = vars.first;
    if (vars.ids) variables.entityIds = vars.ids.map(id => Number(id)); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `query`

    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const edges = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$field = _data$site[field]) === null || _data$site$field === void 0 ? void 0 : _data$site$field.edges;
    const products = (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_1__.default)(edges);

    if (locale && config.applyLocale) {
      products.forEach(product => {
        if (product.node) (0,_utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_2__.default)(product.node);
      });
    }

    return {
      products: products.map(({
        node
      }) => (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_3__.normalizeProduct)(node))
    };
  }

  return getAllProducts;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-customer-wishlist.ts":
/*!***********************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-customer-wishlist.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getCustomerWishlistOperation; }
/* harmony export */ });
function getCustomerWishlistOperation({
  commerce
}) {
  async function getCustomerWishlist({
    config,
    variables,
    includeProducts
  }) {
    var _wishlist$items;

    config = commerce.getConfig(config);
    const {
      data = []
    } = await config.storeApiFetch(`/v3/wishlists?customer_id=${variables.customerId}`);
    const wishlist = data[0];

    if (includeProducts && wishlist !== null && wishlist !== void 0 && (_wishlist$items = wishlist.items) !== null && _wishlist$items !== void 0 && _wishlist$items.length) {
      var _wishlist$items2;

      const ids = (_wishlist$items2 = wishlist.items) === null || _wishlist$items2 === void 0 ? void 0 : _wishlist$items2.map(item => item !== null && item !== void 0 && item.product_id ? String(item === null || item === void 0 ? void 0 : item.product_id) : null).filter(id => !!id);

      if (ids !== null && ids !== void 0 && ids.length) {
        const graphqlData = await commerce.getAllProducts({
          variables: {
            first: 50,
            ids
          },
          config
        }); // Put the products in an object that we can use to get them by id

        const productsById = graphqlData.products.reduce((prods, p) => {
          prods[Number(p.id)] = p;
          return prods;
        }, {}); // Populate the wishlist items with the graphql products

        wishlist.items.forEach(item => {
          const product = item && productsById[item.product_id];

          if (item && product) {
            // @ts-ignore Fix this type when the wishlist type is properly defined
            item.product = product;
          }
        });
      }
    }

    return {
      wishlist: wishlist
    };
  }

  return getCustomerWishlist;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-page.ts":
/*!**********************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-page.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ getPageOperation; }
/* harmony export */ });
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");

function getPageOperation({
  commerce
}) {
  async function getPage({
    url,
    variables,
    config,
    preview
  }) {
    const cfg = commerce.getConfig(config); // RecursivePartial forces the method to check for every prop in the data, which is
    // required in case there's a custom `url`

    const {
      data
    } = await cfg.storeApiFetch(url || `/v3/content/pages?id=${variables.id}&include=body`);
    const firstPage = data === null || data === void 0 ? void 0 : data[0];
    const page = firstPage;

    if (preview || page !== null && page !== void 0 && page.is_visible) {
      return {
        page: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_0__.normalizePage)(page)
      };
    }

    return {};
  }

  return getPage;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-product.ts":
/*!*************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-product.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getProductQuery": function() { return /* binding */ getProductQuery; },
/* harmony export */   "default": function() { return /* binding */ getAllProductPathsOperation; }
/* harmony export */ });
/* harmony import */ var _utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/set-product-locale-meta */ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts");
/* harmony import */ var _fragments_product__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/product */ "./framework/bigcommerce/api/fragments/product.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");
function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const getProductQuery =
/* GraphQL */
`
  query getProduct(
    $hasLocale: Boolean = false
    $locale: String = "null"
    $path: String!
  ) {
    site {
      route(path: $path) {
        node {
          __typename
          ... on Product {
            ...productInfo
            variants {
              edges {
                node {
                  entityId
                  defaultImage {
                    urlOriginal
                    altText
                    isDefault
                  }
                  prices {
                    ...productPrices
                  }
                  inventory {
                    aggregated {
                      availableToSell
                      warningLevel
                    }
                    isInStock
                  }
                  productOptions {
                    edges {
                      node {
                        __typename
                        entityId
                        displayName
                        ...multipleChoiceOption
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  ${_fragments_product__WEBPACK_IMPORTED_MODULE_0__.productInfoFragment}
`; // TODO: See if this type is useful for defining the Product type
// export type ProductNode = Extract<
//   GetProductQuery['site']['route']['node'],
//   { __typename: 'Product' }
// >

function getAllProductPathsOperation({
  commerce
}) {
  async function getProduct(_ref) {
    var _data$site, _data$site$route;

    let {
      query = getProductQuery,
      variables: {
        slug
      },
      config: cfg
    } = _ref,
        vars = _objectWithoutProperties(_ref.variables, ["slug"]);

    const config = commerce.getConfig(cfg);
    const {
      locale
    } = config;
    const variables = {
      locale,
      hasLocale: !!locale,
      path: slug ? `/${slug}/` : vars.path
    };
    const {
      data
    } = await config.fetch(query, {
      variables
    });
    const product = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$route = _data$site.route) === null || _data$site$route === void 0 ? void 0 : _data$site$route.node;

    if ((product === null || product === void 0 ? void 0 : product.__typename) === 'Product') {
      if (locale && config.applyLocale) {
        (0,_utils_set_product_locale_meta__WEBPACK_IMPORTED_MODULE_1__.default)(product);
      }

      return {
        product: (0,_lib_normalize__WEBPACK_IMPORTED_MODULE_2__.normalizeProduct)(product)
      };
    }

    return {};
  }

  return getProduct;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/get-site-info.ts":
/*!***************************************************************!*\
  !*** ./framework/bigcommerce/api/operations/get-site-info.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getSiteInfoQuery": function() { return /* binding */ getSiteInfoQuery; },
/* harmony export */   "default": function() { return /* binding */ getSiteInfoOperation; }
/* harmony export */ });
/* harmony import */ var _utils_filter_edges__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/filter-edges */ "./framework/bigcommerce/api/utils/filter-edges.ts");
/* harmony import */ var _fragments_category_tree__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fragments/category-tree */ "./framework/bigcommerce/api/fragments/category-tree.ts");
/* harmony import */ var _lib_normalize__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/normalize */ "./framework/bigcommerce/lib/normalize.ts");


 // Get 3 levels of categories

const getSiteInfoQuery =
/* GraphQL */
`
  query getSiteInfo {
    site {
      categoryTree {
        ...categoryTreeItem
        children {
          ...categoryTreeItem
          children {
            ...categoryTreeItem
          }
        }
      }
      brands {
        pageInfo {
          startCursor
          endCursor
        }
        edges {
          cursor
          node {
            entityId
            name
            defaultImage {
              urlOriginal
              altText
            }
            pageTitle
            metaDesc
            metaKeywords
            searchKeywords
            path
          }
        }
      }
    }
  }
  ${_fragments_category_tree__WEBPACK_IMPORTED_MODULE_0__.categoryTreeItemFragment}
`;
function getSiteInfoOperation({
  commerce
}) {
  async function getSiteInfo({
    query = getSiteInfoQuery,
    config
  } = {}) {
    var _data$site, _data$site$brands;

    const cfg = commerce.getConfig(config);
    const {
      data
    } = await cfg.fetch(query);
    const categories = data.site.categoryTree.map(_lib_normalize__WEBPACK_IMPORTED_MODULE_1__.normalizeCategory);
    const brands = (_data$site = data.site) === null || _data$site === void 0 ? void 0 : (_data$site$brands = _data$site.brands) === null || _data$site$brands === void 0 ? void 0 : _data$site$brands.edges;
    return {
      categories: categories !== null && categories !== void 0 ? categories : [],
      brands: (0,_utils_filter_edges__WEBPACK_IMPORTED_MODULE_2__.default)(brands)
    };
  }

  return getSiteInfo;
}

/***/ }),

/***/ "./framework/bigcommerce/api/operations/login.ts":
/*!*******************************************************!*\
  !*** ./framework/bigcommerce/api/operations/login.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loginMutation": function() { return /* binding */ loginMutation; },
/* harmony export */   "default": function() { return /* binding */ loginOperation; }
/* harmony export */ });
/* harmony import */ var _utils_concat_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/concat-cookie */ "./framework/bigcommerce/api/utils/concat-cookie.ts");

const loginMutation =
/* GraphQL */
`
  mutation login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      result
    }
  }
`;
function loginOperation({
  commerce
}) {
  async function login({
    query = loginMutation,
    variables,
    res: response,
    config
  }) {
    var _data$login;

    config = commerce.getConfig(config);
    const {
      data,
      res
    } = await config.fetch(query, {
      variables
    }); // Bigcommerce returns a Set-Cookie header with the auth cookie

    let cookie = res.headers.get('Set-Cookie');

    if (cookie && typeof cookie === 'string') {
      // In development, don't set a secure cookie or the browser will ignore it
      if (true) {
        cookie = cookie.replace('; Secure', ''); // SameSite=none can't be set unless the cookie is Secure
        // bc seems to sometimes send back SameSite=None rather than none so make
        // this case insensitive

        cookie = cookie.replace(/; SameSite=none/gi, '; SameSite=lax');
      }

      response.setHeader('Set-Cookie', (0,_utils_concat_cookie__WEBPACK_IMPORTED_MODULE_0__.default)(response.getHeader('Set-Cookie'), cookie));
    }

    return {
      result: (_data$login = data.login) === null || _data$login === void 0 ? void 0 : _data$login.result
    };
  }

  return login;
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/concat-cookie.ts":
/*!**********************************************************!*\
  !*** ./framework/bigcommerce/api/utils/concat-cookie.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ concatHeader; }
/* harmony export */ });
function concatHeader(prev, val) {
  if (!val) return prev;
  if (!prev) return val;
  if (Array.isArray(prev)) return prev.concat(String(val));
  prev = String(prev);
  if (Array.isArray(val)) return [prev].concat(val);
  return [prev, String(val)];
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/errors.ts":
/*!***************************************************!*\
  !*** ./framework/bigcommerce/api/utils/errors.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BigcommerceGraphQLError": function() { return /* binding */ BigcommerceGraphQLError; },
/* harmony export */   "BigcommerceApiError": function() { return /* binding */ BigcommerceApiError; },
/* harmony export */   "BigcommerceNetworkError": function() { return /* binding */ BigcommerceNetworkError; }
/* harmony export */ });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// Used for GraphQL errors
class BigcommerceGraphQLError extends Error {}
class BigcommerceApiError extends Error {
  constructor(msg, res, data) {
    super(msg);

    _defineProperty(this, "status", void 0);

    _defineProperty(this, "res", void 0);

    _defineProperty(this, "data", void 0);

    this.name = 'BigcommerceApiError';
    this.status = res.status;
    this.res = res;
    this.data = data;
  }

}
class BigcommerceNetworkError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'BigcommerceNetworkError';
  }

}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch-graphql-api.ts":
/*!**************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch-graphql-api.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @commerce/utils/errors */ "./framework/commerce/utils/errors.ts");
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fetch */ "./framework/bigcommerce/api/utils/fetch.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchGraphqlApi = getConfig => async (query, {
  variables,
  preview
} = {}, fetchOptions) => {
  // log.warn(query)
  const config = getConfig();
  const res = await (0,_fetch__WEBPACK_IMPORTED_MODULE_0__.default)(config.commerceUrl + (preview ? '/preview' : ''), _objectSpread(_objectSpread({}, fetchOptions), {}, {
    method: 'POST',
    headers: _objectSpread(_objectSpread({
      Authorization: `Bearer ${config.apiToken}`
    }, fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.headers), {}, {
      'Content-Type': 'application/json'
    }),
    body: JSON.stringify({
      query,
      variables
    })
  }));
  const json = await res.json();

  if (json.errors) {
    var _json$errors;

    throw new _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__.FetcherError({
      errors: (_json$errors = json.errors) !== null && _json$errors !== void 0 ? _json$errors : [{
        message: 'Failed to fetch Bigcommerce API'
      }],
      status: res.status
    });
  }

  return {
    data: json.data,
    res
  };
};

/* harmony default export */ __webpack_exports__["default"] = (fetchGraphqlApi);

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch-store-api.ts":
/*!************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch-store-api.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./errors */ "./framework/bigcommerce/api/utils/errors.ts");
/* harmony import */ var _fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fetch */ "./framework/bigcommerce/api/utils/fetch.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const fetchStoreApi = getConfig => async (endpoint, options) => {
  const config = getConfig();
  let res;

  try {
    res = await (0,_fetch__WEBPACK_IMPORTED_MODULE_0__.default)(config.storeApiUrl + endpoint, _objectSpread(_objectSpread({}, options), {}, {
      headers: _objectSpread(_objectSpread({}, options === null || options === void 0 ? void 0 : options.headers), {}, {
        'Content-Type': 'application/json',
        'X-Auth-Token': config.storeApiToken,
        'X-Auth-Client': config.storeApiClientId
      })
    }));
  } catch (error) {
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceNetworkError(`Fetch to Bigcommerce failed: ${error.message}`);
  }

  const contentType = res.headers.get('Content-Type');
  const isJSON = contentType === null || contentType === void 0 ? void 0 : contentType.includes('application/json');

  if (!res.ok) {
    const data = isJSON ? await res.json() : await getTextOrNull(res);
    const headers = getRawHeaders(res);
    const msg = `Big Commerce API error (${res.status}) \nHeaders: ${JSON.stringify(headers, null, 2)}\n${typeof data === 'string' ? data : JSON.stringify(data, null, 2)}`;
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceApiError(msg, res, data);
  }

  if (res.status !== 204 && !isJSON) {
    throw new _errors__WEBPACK_IMPORTED_MODULE_1__.BigcommerceApiError(`Fetch to Bigcommerce API failed, expected JSON content but found: ${contentType}`, res);
  } // If something was removed, the response will be empty


  return res.status === 204 ? null : await res.json();
};

/* harmony default export */ __webpack_exports__["default"] = (fetchStoreApi);

function getRawHeaders(res) {
  const headers = {};
  res.headers.forEach((value, key) => {
    headers[key] = value;
  });
  return headers;
}

function getTextOrNull(res) {
  try {
    return res.text();
  } catch (err) {
    return null;
  }
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/fetch.ts":
/*!**************************************************!*\
  !*** ./framework/bigcommerce/api/utils/fetch.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vercel_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @vercel/fetch */ "@vercel/fetch");
/* harmony import */ var _vercel_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_vercel_fetch__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (_vercel_fetch__WEBPACK_IMPORTED_MODULE_0___default()());

/***/ }),

/***/ "./framework/bigcommerce/api/utils/filter-edges.ts":
/*!*********************************************************!*\
  !*** ./framework/bigcommerce/api/utils/filter-edges.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ filterEdges; }
/* harmony export */ });
function filterEdges(edges) {
  var _edges$filter;

  return (_edges$filter = edges === null || edges === void 0 ? void 0 : edges.filter(edge => !!edge)) !== null && _edges$filter !== void 0 ? _edges$filter : [];
}

/***/ }),

/***/ "./framework/bigcommerce/api/utils/set-product-locale-meta.ts":
/*!********************************************************************!*\
  !*** ./framework/bigcommerce/api/utils/set-product-locale-meta.ts ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ setProductLocaleMeta; }
/* harmony export */ });
function setProductLocaleMeta(node) {
  var _node$localeMeta;

  if ((_node$localeMeta = node.localeMeta) !== null && _node$localeMeta !== void 0 && _node$localeMeta.edges) {
    node.localeMeta.edges = node.localeMeta.edges.filter(edge => {
      var _edge$node;

      const {
        key,
        value
      } = (_edge$node = edge === null || edge === void 0 ? void 0 : edge.node) !== null && _edge$node !== void 0 ? _edge$node : {};

      if (key && key in node) {
        ;
        node[key] = value;
        return false;
      }

      return true;
    });

    if (!node.localeMeta.edges.length) {
      delete node.localeMeta;
    }
  }
}

/***/ }),

/***/ "./framework/bigcommerce/lib/get-slug.ts":
/*!***********************************************!*\
  !*** ./framework/bigcommerce/lib/get-slug.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = path => path.replace(/^\/|\/$/g, '');

/* harmony default export */ __webpack_exports__["default"] = (getSlug);

/***/ }),

/***/ "./framework/bigcommerce/lib/immutability.ts":
/*!***************************************************!*\
  !*** ./framework/bigcommerce/lib/immutability.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var immutability_helper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! immutability-helper */ "immutability-helper");
/* harmony import */ var immutability_helper__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(immutability_helper__WEBPACK_IMPORTED_MODULE_0__);

const c = new immutability_helper__WEBPACK_IMPORTED_MODULE_0__.Context();
c.extend('$auto', function (value, object) {
  return object ? c.update(object, value) : c.update({}, value);
});
c.extend('$autoArray', function (value, object) {
  return object ? c.update(object, value) : c.update([], value);
});
/* harmony default export */ __webpack_exports__["default"] = (c.update);

/***/ }),

/***/ "./framework/bigcommerce/lib/normalize.ts":
/*!************************************************!*\
  !*** ./framework/bigcommerce/lib/normalize.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "normalizeProduct": function() { return /* binding */ normalizeProduct; },
/* harmony export */   "normalizePage": function() { return /* binding */ normalizePage; },
/* harmony export */   "normalizeCart": function() { return /* binding */ normalizeCart; },
/* harmony export */   "normalizeCategory": function() { return /* binding */ normalizeCategory; }
/* harmony export */ });
/* harmony import */ var _immutability__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./immutability */ "./framework/bigcommerce/lib/immutability.ts");
/* harmony import */ var _get_slug__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./get-slug */ "./framework/bigcommerce/lib/get-slug.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




function normalizeProductOption(productOption) {
  const {
    node: {
      entityId,
      values: {
        edges = []
      } = {}
    }
  } = productOption,
        rest = _objectWithoutProperties(productOption.node, ["entityId", "values"]);

  return _objectSpread({
    id: entityId,
    values: edges === null || edges === void 0 ? void 0 : edges.map(({
      node
    }) => node)
  }, rest);
}

function normalizeProduct(productNode) {
  const {
    entityId: id,
    productOptions,
    prices,
    path,
    id: _,
    options: _0
  } = productNode;
  return (0,_immutability__WEBPACK_IMPORTED_MODULE_0__.default)(productNode, {
    id: {
      $set: String(id)
    },
    images: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map((_ref) => {
        let {
          node: {
            urlOriginal,
            altText
          }
        } = _ref,
            rest = _objectWithoutProperties(_ref.node, ["urlOriginal", "altText"]);

        return _objectSpread({
          url: urlOriginal,
          alt: altText
        }, rest);
      })
    },
    variants: {
      $apply: ({
        edges
      }) => edges === null || edges === void 0 ? void 0 : edges.map((_ref2) => {
        let {
          node: {
            entityId,
            productOptions
          }
        } = _ref2,
            rest = _objectWithoutProperties(_ref2.node, ["entityId", "productOptions"]);

        return _objectSpread({
          id: entityId,
          options: productOptions !== null && productOptions !== void 0 && productOptions.edges ? productOptions.edges.map(normalizeProductOption) : []
        }, rest);
      })
    },
    options: {
      $set: productOptions.edges ? productOptions === null || productOptions === void 0 ? void 0 : productOptions.edges.map(normalizeProductOption) : []
    },
    brand: {
      $apply: brand => brand !== null && brand !== void 0 && brand.entityId ? brand === null || brand === void 0 ? void 0 : brand.entityId : null
    },
    slug: {
      $set: path === null || path === void 0 ? void 0 : path.replace(/^\/+|\/+$/g, '')
    },
    price: {
      $set: {
        value: prices === null || prices === void 0 ? void 0 : prices.price.value,
        currencyCode: prices === null || prices === void 0 ? void 0 : prices.price.currencyCode
      }
    },
    $unset: ['entityId']
  });
}
function normalizePage(page) {
  return {
    id: String(page.id),
    name: page.name,
    is_visible: page.is_visible,
    sort_order: page.sort_order,
    body: page.body
  };
}
function normalizeCart(data) {
  var _data$discounts;

  return {
    id: data.id,
    customerId: String(data.customer_id),
    email: data.email,
    createdAt: data.created_time,
    currency: data.currency,
    taxesIncluded: data.tax_included,
    lineItems: [...data.line_items.physical_items.map(normalizeLineItem), ...data.line_items.digital_items.map(normalizeLineItem)],
    lineItemsSubtotalPrice: data.base_amount,
    subtotalPrice: data.base_amount + data.discount_amount,
    totalPrice: data.cart_amount,
    discounts: (_data$discounts = data.discounts) === null || _data$discounts === void 0 ? void 0 : _data$discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeLineItem(item) {
  return {
    id: item.id,
    variantId: String(item.variant_id),
    productId: String(item.product_id),
    name: item.name,
    quantity: item.quantity,
    variant: {
      id: String(item.variant_id),
      sku: item.sku,
      name: item.name,
      image: {
        url: item.image_url
      },
      requiresShipping: item.is_require_shipping,
      price: item.sale_price,
      listPrice: item.list_price
    },
    path: item.url.split('/')[3],
    discounts: item.discounts.map(discount => ({
      value: discount.discounted_amount
    }))
  };
}

function normalizeCategory(category) {
  return {
    id: `${category.entityId}`,
    name: category.name,
    slug: (0,_get_slug__WEBPACK_IMPORTED_MODULE_1__.default)(category.path),
    path: category.path
  };
}

/***/ }),

/***/ "./framework/commerce/api/endpoints/customer/index.ts":
/*!************************************************************!*\
  !*** ./framework/commerce/api/endpoints/customer/index.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/errors */ "./framework/commerce/api/utils/errors.ts");
/* harmony import */ var _utils_is_allowed_operation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utils/is-allowed-operation */ "./framework/commerce/api/utils/is-allowed-operation.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const customerEndpoint = async ctx => {
  const {
    req,
    res,
    handlers
  } = ctx;

  if (!(0,_utils_is_allowed_operation__WEBPACK_IMPORTED_MODULE_0__.default)(req, res, {
    GET: handlers['getLoggedInCustomer']
  })) {
    return;
  }

  try {
    const body = null;
    return await handlers['getLoggedInCustomer'](_objectSpread(_objectSpread({}, ctx), {}, {
      body
    }));
  } catch (error) {
    console.error(error);
    const message = error instanceof _utils_errors__WEBPACK_IMPORTED_MODULE_1__.CommerceAPIError ? 'An unexpected error ocurred with the Commerce API' : 'An unexpected error ocurred';
    res.status(500).json({
      data: null,
      errors: [{
        message
      }]
    });
  }
};

/* harmony default export */ __webpack_exports__["default"] = (customerEndpoint);

/***/ }),

/***/ "./framework/commerce/api/index.ts":
/*!*****************************************!*\
  !*** ./framework/commerce/api/index.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceAPICore": function() { return /* binding */ CommerceAPICore; },
/* harmony export */   "getCommerceApi": function() { return /* binding */ getCommerceApi; },
/* harmony export */   "getEndpoint": function() { return /* binding */ getEndpoint; },
/* harmony export */   "createEndpoint": function() { return /* binding */ createEndpoint; }
/* harmony export */ });
/* harmony import */ var _operations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./operations */ "./framework/commerce/api/operations.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


class CommerceAPICore {
  constructor(provider) {
    this.provider = provider;
  }

  getConfig(userConfig = {}) {
    return Object.entries(userConfig).reduce((cfg, [key, value]) => Object.assign(cfg, {
      [key]: value
    }), _objectSpread({}, this.provider.config));
  }

  setConfig(newConfig) {
    Object.assign(this.provider.config, newConfig);
  }

}
function getCommerceApi(customProvider) {
  const commerce = Object.assign(new CommerceAPICore(customProvider), _operations__WEBPACK_IMPORTED_MODULE_0__.defaultOperations);
  const ops = customProvider.operations;
  _operations__WEBPACK_IMPORTED_MODULE_0__.OPERATIONS.forEach(k => {
    const op = ops[k];

    if (op) {
      commerce[k] = op({
        commerce
      });
    }
  });
  return commerce;
}
function getEndpoint(commerce, context) {
  const cfg = commerce.getConfig(context.config);
  return function apiHandler(req, res) {
    var _context$options;

    return context.handler({
      req,
      res,
      commerce,
      config: cfg,
      handlers: context.handlers,
      options: (_context$options = context.options) !== null && _context$options !== void 0 ? _context$options : {}
    });
  };
}
const createEndpoint = endpoint => (commerce, context) => {
  return getEndpoint(commerce, _objectSpread(_objectSpread({}, endpoint), context));
};

/***/ }),

/***/ "./framework/commerce/api/operations.ts":
/*!**********************************************!*\
  !*** ./framework/commerce/api/operations.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OPERATIONS": function() { return /* binding */ OPERATIONS; },
/* harmony export */   "defaultOperations": function() { return /* binding */ defaultOperations; }
/* harmony export */ });
const noop = () => {
  throw new Error('Not implemented');
};

const OPERATIONS = ['login', 'getAllPages', 'getPage', 'getSiteInfo', 'getCustomerWishlist', 'getAllProductPaths', 'getAllProducts', 'getProduct'];
const defaultOperations = OPERATIONS.reduce((ops, k) => {
  ops[k] = noop;
  return ops;
}, {});

/***/ }),

/***/ "./framework/commerce/api/utils/errors.ts":
/*!************************************************!*\
  !*** ./framework/commerce/api/utils/errors.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceAPIError": function() { return /* binding */ CommerceAPIError; },
/* harmony export */   "CommerceNetworkError": function() { return /* binding */ CommerceNetworkError; }
/* harmony export */ });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class CommerceAPIError extends Error {
  constructor(msg, res, data) {
    super(msg);

    _defineProperty(this, "status", void 0);

    _defineProperty(this, "res", void 0);

    _defineProperty(this, "data", void 0);

    this.name = 'CommerceApiError';
    this.status = res.status;
    this.res = res;
    this.data = data;
  }

}
class CommerceNetworkError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'CommerceNetworkError';
  }

}

/***/ }),

/***/ "./framework/commerce/api/utils/is-allowed-method.ts":
/*!***********************************************************!*\
  !*** ./framework/commerce/api/utils/is-allowed-method.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ isAllowedMethod; }
/* harmony export */ });
function isAllowedMethod(req, res, allowedMethods) {
  const methods = allowedMethods.includes('OPTIONS') ? allowedMethods : [...allowedMethods, 'OPTIONS'];

  if (!req.method || !methods.includes(req.method)) {
    res.status(405);
    res.setHeader('Allow', methods.join(', '));
    res.end();
    return false;
  }

  if (req.method === 'OPTIONS') {
    res.status(200);
    res.setHeader('Allow', methods.join(', '));
    res.setHeader('Content-Length', '0');
    res.end();
    return false;
  }

  return true;
}

/***/ }),

/***/ "./framework/commerce/api/utils/is-allowed-operation.ts":
/*!**************************************************************!*\
  !*** ./framework/commerce/api/utils/is-allowed-operation.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ isAllowedOperation; }
/* harmony export */ });
/* harmony import */ var _is_allowed_method__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./is-allowed-method */ "./framework/commerce/api/utils/is-allowed-method.ts");

function isAllowedOperation(req, res, allowedOperations) {
  const methods = Object.keys(allowedOperations);
  const allowedMethods = methods.reduce((arr, method) => {
    if (allowedOperations[method]) {
      arr.push(method);
    }

    return arr;
  }, []);
  return (0,_is_allowed_method__WEBPACK_IMPORTED_MODULE_0__.default)(req, res, allowedMethods);
}

/***/ }),

/***/ "./framework/commerce/utils/errors.ts":
/*!********************************************!*\
  !*** ./framework/commerce/utils/errors.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommerceError": function() { return /* binding */ CommerceError; },
/* harmony export */   "ValidationError": function() { return /* binding */ ValidationError; },
/* harmony export */   "FetcherError": function() { return /* binding */ FetcherError; }
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class CommerceError extends Error {
  constructor({
    message,
    code,
    errors
  }) {
    const error = message ? _objectSpread({
      message
    }, code ? {
      code
    } : {}) : errors[0];
    super(error.message);

    _defineProperty(this, "code", void 0);

    _defineProperty(this, "errors", void 0);

    this.errors = message ? [error] : errors;
    if (error.code) this.code = error.code;
  }

} // Used for errors that come from a bad implementation of the hooks

class ValidationError extends CommerceError {
  constructor(options) {
    super(options);
    this.code = 'validation_error';
  }

}
class FetcherError extends CommerceError {
  constructor(options) {
    super(options);

    _defineProperty(this, "status", void 0);

    this.status = options.status;
  }

}

/***/ }),

/***/ "./lib/api/commerce.ts":
/*!*****************************!*\
  !*** ./lib/api/commerce.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _framework_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @framework/api */ "./framework/bigcommerce/api/index.ts");

/* harmony default export */ __webpack_exports__["default"] = ((0,_framework_api__WEBPACK_IMPORTED_MODULE_0__.getCommerceApi)());

/***/ }),

/***/ "./pages/api/customer/index.ts":
/*!*************************************!*\
  !*** ./pages/api/customer/index.ts ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _framework_api_endpoints_customer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @framework/api/endpoints/customer */ "./framework/bigcommerce/api/endpoints/customer/index.ts");
/* harmony import */ var _lib_api_commerce__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lib/api/commerce */ "./lib/api/commerce.ts");


/* harmony default export */ __webpack_exports__["default"] = ((0,_framework_api_endpoints_customer__WEBPACK_IMPORTED_MODULE_0__.default)(_lib_api_commerce__WEBPACK_IMPORTED_MODULE_1__.default));

/***/ }),

/***/ "@vercel/fetch":
/*!********************************!*\
  !*** external "@vercel/fetch" ***!
  \********************************/
/***/ (function(module) {

"use strict";
module.exports = require("@vercel/fetch");;

/***/ }),

/***/ "immutability-helper":
/*!**************************************!*\
  !*** external "immutability-helper" ***!
  \**************************************/
/***/ (function(module) {

"use strict";
module.exports = require("immutability-helper");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/customer/index.ts"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jdXN0b21lci9nZXQtbG9nZ2VkLWluLWN1c3RvbWVyLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvZW5kcG9pbnRzL2N1c3RvbWVyL2luZGV4LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvZnJhZ21lbnRzL2NhdGVnb3J5LXRyZWUudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9mcmFnbWVudHMvcHJvZHVjdC50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL2luZGV4LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvb3BlcmF0aW9ucy9nZXQtYWxsLXBhZ2VzLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvb3BlcmF0aW9ucy9nZXQtYWxsLXByb2R1Y3QtcGF0aHMudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1hbGwtcHJvZHVjdHMudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1jdXN0b21lci13aXNobGlzdC50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL29wZXJhdGlvbnMvZ2V0LXBhZ2UudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS9vcGVyYXRpb25zL2dldC1wcm9kdWN0LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvb3BlcmF0aW9ucy9nZXQtc2l0ZS1pbmZvLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvb3BlcmF0aW9ucy9sb2dpbi50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL3V0aWxzL2NvbmNhdC1jb29raWUudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS91dGlscy9lcnJvcnMudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2FwaS91dGlscy9mZXRjaC1ncmFwaHFsLWFwaS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL3V0aWxzL2ZldGNoLXN0b3JlLWFwaS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvYXBpL3V0aWxzL2ZldGNoLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvZmlsdGVyLWVkZ2VzLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9iaWdjb21tZXJjZS9hcGkvdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEudHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2JpZ2NvbW1lcmNlL2xpYi9nZXQtc2x1Zy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvbGliL2ltbXV0YWJpbGl0eS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvYmlnY29tbWVyY2UvbGliL25vcm1hbGl6ZS50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvYXBpL2VuZHBvaW50cy9jdXN0b21lci9pbmRleC50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvYXBpL2luZGV4LnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9jb21tZXJjZS9hcGkvb3BlcmF0aW9ucy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvYXBpL3V0aWxzL2Vycm9ycy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9mcmFtZXdvcmsvY29tbWVyY2UvYXBpL3V0aWxzL2lzLWFsbG93ZWQtbWV0aG9kLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL2ZyYW1ld29yay9jb21tZXJjZS9hcGkvdXRpbHMvaXMtYWxsb3dlZC1vcGVyYXRpb24udHMiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlLy4vZnJhbWV3b3JrL2NvbW1lcmNlL3V0aWxzL2Vycm9ycy50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9saWIvYXBpL2NvbW1lcmNlLnRzIiwid2VicGFjazovL25leHRqcy1jb21tZXJjZS8uL3BhZ2VzL2FwaS9jdXN0b21lci9pbmRleC50cyIsIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvZXh0ZXJuYWwgXCJAdmVyY2VsL2ZldGNoXCIiLCJ3ZWJwYWNrOi8vbmV4dGpzLWNvbW1lcmNlL2V4dGVybmFsIFwiaW1tdXRhYmlsaXR5LWhlbHBlclwiIl0sIm5hbWVzIjpbImdldExvZ2dlZEluQ3VzdG9tZXJRdWVyeSIsImdldExvZ2dlZEluQ3VzdG9tZXIiLCJyZXEiLCJyZXMiLCJjb25maWciLCJ0b2tlbiIsImNvb2tpZXMiLCJjdXN0b21lckNvb2tpZSIsImRhdGEiLCJmZXRjaCIsInVuZGVmaW5lZCIsImhlYWRlcnMiLCJjb29raWUiLCJjdXN0b21lciIsInN0YXR1cyIsImpzb24iLCJlcnJvcnMiLCJtZXNzYWdlIiwiY29kZSIsImhhbmRsZXJzIiwiY3VzdG9tZXJBcGkiLCJjcmVhdGVFbmRwb2ludCIsImhhbmRsZXIiLCJjdXN0b21lckVuZHBvaW50IiwiY2F0ZWdvcnlUcmVlSXRlbUZyYWdtZW50IiwicHJvZHVjdFByaWNlcyIsInN3YXRjaE9wdGlvbkZyYWdtZW50IiwibXVsdGlwbGVDaG9pY2VPcHRpb25GcmFnbWVudCIsInByb2R1Y3RJbmZvRnJhZ21lbnQiLCJwcm9kdWN0Q29ubmVjdGlvbkZyYWdtZW50IiwiQVBJX1VSTCIsInByb2Nlc3MiLCJlbnYiLCJCSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9VUkwiLCJBUElfVE9LRU4iLCJCSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9UT0tFTiIsIlNUT1JFX0FQSV9VUkwiLCJCSUdDT01NRVJDRV9TVE9SRV9BUElfVVJMIiwiU1RPUkVfQVBJX1RPS0VOIiwiQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOIiwiU1RPUkVfQVBJX0NMSUVOVF9JRCIsIkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9DTElFTlRfSUQiLCJTVE9SRV9DSEFOTkVMX0lEIiwiQklHQ09NTUVSQ0VfQ0hBTk5FTF9JRCIsIlNUT1JFX1VSTCIsIkJJR0NPTU1FUkNFX1NUT1JFX1VSTCIsIkNMSUVOVF9TRUNSRVQiLCJCSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX1NFQ1JFVCIsIlNUT1JFRlJPTlRfSEFTSCIsIkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9TVE9SRV9IQVNIIiwiRXJyb3IiLCJPTkVfREFZIiwiY29tbWVyY2VVcmwiLCJhcGlUb2tlbiIsImNhcnRDb29raWUiLCJCSUdDT01NRVJDRV9DQVJUX0NPT0tJRSIsImNhcnRDb29raWVNYXhBZ2UiLCJjcmVhdGVGZXRjaEdyYXBocWxBcGkiLCJnZXRDb21tZXJjZUFwaSIsImdldENvbmZpZyIsImFwcGx5TG9jYWxlIiwic3RvcmVBcGlVcmwiLCJzdG9yZUFwaVRva2VuIiwic3RvcmVBcGlDbGllbnRJZCIsInN0b3JlQ2hhbm5lbElkIiwic3RvcmVVcmwiLCJzdG9yZUFwaUNsaWVudFNlY3JldCIsInN0b3JlSGFzaCIsInN0b3JlQXBpRmV0Y2giLCJjcmVhdGVGZXRjaFN0b3JlQXBpIiwib3BlcmF0aW9ucyIsImxvZ2luIiwiZ2V0QWxsUGFnZXMiLCJnZXRQYWdlIiwiZ2V0U2l0ZUluZm8iLCJnZXRDdXN0b21lcldpc2hsaXN0IiwiZ2V0QWxsUHJvZHVjdFBhdGhzIiwiZ2V0QWxsUHJvZHVjdHMiLCJnZXRQcm9kdWN0IiwicHJvdmlkZXIiLCJjdXN0b21Qcm92aWRlciIsImNvbW1lcmNlQXBpIiwiZ2V0QWxsUGFnZXNPcGVyYXRpb24iLCJjb21tZXJjZSIsInByZXZpZXciLCJjZmciLCJwYWdlcyIsImZpbHRlciIsInAiLCJpc192aXNpYmxlIiwiZ2V0QWxsUHJvZHVjdFBhdGhzUXVlcnkiLCJnZXRBbGxQcm9kdWN0UGF0aHNPcGVyYXRpb24iLCJxdWVyeSIsInZhcmlhYmxlcyIsInByb2R1Y3RzIiwic2l0ZSIsImVkZ2VzIiwiZmlsdGVyRWRnZXMiLCJtYXAiLCJub2RlIiwiZ2V0QWxsUHJvZHVjdHNRdWVyeSIsImdldFByb2R1Y3RzVHlwZSIsInJlbGV2YW5jZSIsImdldEFsbFByb2R1Y3RzT3BlcmF0aW9uIiwidmFycyIsImxvY2FsZSIsImZpZWxkIiwiaGFzTG9jYWxlIiwiZmlyc3QiLCJpZHMiLCJlbnRpdHlJZHMiLCJpZCIsIk51bWJlciIsImZvckVhY2giLCJwcm9kdWN0Iiwic2V0UHJvZHVjdExvY2FsZU1ldGEiLCJub3JtYWxpemVQcm9kdWN0IiwiZ2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbiIsImluY2x1ZGVQcm9kdWN0cyIsImN1c3RvbWVySWQiLCJ3aXNobGlzdCIsIml0ZW1zIiwibGVuZ3RoIiwiaXRlbSIsInByb2R1Y3RfaWQiLCJTdHJpbmciLCJncmFwaHFsRGF0YSIsInByb2R1Y3RzQnlJZCIsInJlZHVjZSIsInByb2RzIiwiZ2V0UGFnZU9wZXJhdGlvbiIsInVybCIsImZpcnN0UGFnZSIsInBhZ2UiLCJub3JtYWxpemVQYWdlIiwiZ2V0UHJvZHVjdFF1ZXJ5Iiwic2x1ZyIsInBhdGgiLCJyb3V0ZSIsIl9fdHlwZW5hbWUiLCJnZXRTaXRlSW5mb1F1ZXJ5IiwiZ2V0U2l0ZUluZm9PcGVyYXRpb24iLCJjYXRlZ29yaWVzIiwiY2F0ZWdvcnlUcmVlIiwibm9ybWFsaXplQ2F0ZWdvcnkiLCJicmFuZHMiLCJsb2dpbk11dGF0aW9uIiwibG9naW5PcGVyYXRpb24iLCJyZXNwb25zZSIsImdldCIsInJlcGxhY2UiLCJzZXRIZWFkZXIiLCJjb25jYXRIZWFkZXIiLCJnZXRIZWFkZXIiLCJyZXN1bHQiLCJwcmV2IiwidmFsIiwiQXJyYXkiLCJpc0FycmF5IiwiY29uY2F0IiwiQmlnY29tbWVyY2VHcmFwaFFMRXJyb3IiLCJCaWdjb21tZXJjZUFwaUVycm9yIiwiY29uc3RydWN0b3IiLCJtc2ciLCJuYW1lIiwiQmlnY29tbWVyY2VOZXR3b3JrRXJyb3IiLCJmZXRjaEdyYXBocWxBcGkiLCJmZXRjaE9wdGlvbnMiLCJtZXRob2QiLCJBdXRob3JpemF0aW9uIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJGZXRjaGVyRXJyb3IiLCJmZXRjaFN0b3JlQXBpIiwiZW5kcG9pbnQiLCJvcHRpb25zIiwiZXJyb3IiLCJjb250ZW50VHlwZSIsImlzSlNPTiIsImluY2x1ZGVzIiwib2siLCJnZXRUZXh0T3JOdWxsIiwiZ2V0UmF3SGVhZGVycyIsInZhbHVlIiwia2V5IiwidGV4dCIsImVyciIsInplaXRGZXRjaCIsImVkZ2UiLCJsb2NhbGVNZXRhIiwiZ2V0U2x1ZyIsImMiLCJDb250ZXh0IiwiZXh0ZW5kIiwib2JqZWN0IiwidXBkYXRlIiwibm9ybWFsaXplUHJvZHVjdE9wdGlvbiIsInByb2R1Y3RPcHRpb24iLCJlbnRpdHlJZCIsInZhbHVlcyIsInJlc3QiLCJwcm9kdWN0Tm9kZSIsInByb2R1Y3RPcHRpb25zIiwicHJpY2VzIiwiXyIsIl8wIiwiJHNldCIsImltYWdlcyIsIiRhcHBseSIsInVybE9yaWdpbmFsIiwiYWx0VGV4dCIsImFsdCIsInZhcmlhbnRzIiwiYnJhbmQiLCJwcmljZSIsImN1cnJlbmN5Q29kZSIsIiR1bnNldCIsInNvcnRfb3JkZXIiLCJub3JtYWxpemVDYXJ0IiwiY3VzdG9tZXJfaWQiLCJlbWFpbCIsImNyZWF0ZWRBdCIsImNyZWF0ZWRfdGltZSIsImN1cnJlbmN5IiwidGF4ZXNJbmNsdWRlZCIsInRheF9pbmNsdWRlZCIsImxpbmVJdGVtcyIsImxpbmVfaXRlbXMiLCJwaHlzaWNhbF9pdGVtcyIsIm5vcm1hbGl6ZUxpbmVJdGVtIiwiZGlnaXRhbF9pdGVtcyIsImxpbmVJdGVtc1N1YnRvdGFsUHJpY2UiLCJiYXNlX2Ftb3VudCIsInN1YnRvdGFsUHJpY2UiLCJkaXNjb3VudF9hbW91bnQiLCJ0b3RhbFByaWNlIiwiY2FydF9hbW91bnQiLCJkaXNjb3VudHMiLCJkaXNjb3VudCIsImRpc2NvdW50ZWRfYW1vdW50IiwidmFyaWFudElkIiwidmFyaWFudF9pZCIsInByb2R1Y3RJZCIsInF1YW50aXR5IiwidmFyaWFudCIsInNrdSIsImltYWdlIiwiaW1hZ2VfdXJsIiwicmVxdWlyZXNTaGlwcGluZyIsImlzX3JlcXVpcmVfc2hpcHBpbmciLCJzYWxlX3ByaWNlIiwibGlzdFByaWNlIiwibGlzdF9wcmljZSIsInNwbGl0IiwiY2F0ZWdvcnkiLCJjdHgiLCJpc0FsbG93ZWRPcGVyYXRpb24iLCJHRVQiLCJjb25zb2xlIiwiQ29tbWVyY2VBUElFcnJvciIsIkNvbW1lcmNlQVBJQ29yZSIsInVzZXJDb25maWciLCJPYmplY3QiLCJlbnRyaWVzIiwiYXNzaWduIiwic2V0Q29uZmlnIiwibmV3Q29uZmlnIiwiZGVmYXVsdE9wZXJhdGlvbnMiLCJvcHMiLCJPUEVSQVRJT05TIiwiayIsIm9wIiwiZ2V0RW5kcG9pbnQiLCJjb250ZXh0IiwiYXBpSGFuZGxlciIsIm5vb3AiLCJDb21tZXJjZU5ldHdvcmtFcnJvciIsImlzQWxsb3dlZE1ldGhvZCIsImFsbG93ZWRNZXRob2RzIiwibWV0aG9kcyIsImpvaW4iLCJlbmQiLCJhbGxvd2VkT3BlcmF0aW9ucyIsImtleXMiLCJhcnIiLCJwdXNoIiwiQ29tbWVyY2VFcnJvciIsIlZhbGlkYXRpb25FcnJvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHTyxNQUFNQSx3QkFBd0I7QUFBRztBQUFlO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBbkJPOztBQXVCUCxNQUFNQyxtQkFBd0UsR0FBRyxPQUFPO0FBQ3RGQyxLQURzRjtBQUV0RkMsS0FGc0Y7QUFHdEZDO0FBSHNGLENBQVAsS0FJM0U7QUFDSixRQUFNQyxLQUFLLEdBQUdILEdBQUcsQ0FBQ0ksT0FBSixDQUFZRixNQUFNLENBQUNHLGNBQW5CLENBQWQ7O0FBRUEsTUFBSUYsS0FBSixFQUFXO0FBQ1QsVUFBTTtBQUFFRztBQUFGLFFBQVcsTUFBTUosTUFBTSxDQUFDSyxLQUFQLENBQ3JCVCx3QkFEcUIsRUFFckJVLFNBRnFCLEVBR3JCO0FBQ0VDLGFBQU8sRUFBRTtBQUNQQyxjQUFNLEVBQUcsR0FBRVIsTUFBTSxDQUFDRyxjQUFlLElBQUdGLEtBQU07QUFEbkM7QUFEWCxLQUhxQixDQUF2QjtBQVNBLFVBQU07QUFBRVE7QUFBRixRQUFlTCxJQUFyQjs7QUFFQSxRQUFJLENBQUNLLFFBQUwsRUFBZTtBQUNiLGFBQU9WLEdBQUcsQ0FBQ1csTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQzFCUCxZQUFJLEVBQUUsSUFEb0I7QUFFMUJRLGNBQU0sRUFBRSxDQUFDO0FBQUVDLGlCQUFPLEVBQUUsb0JBQVg7QUFBaUNDLGNBQUksRUFBRTtBQUF2QyxTQUFEO0FBRmtCLE9BQXJCLENBQVA7QUFJRDs7QUFFRCxXQUFPZixHQUFHLENBQUNXLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQjtBQUFFUCxVQUFJLEVBQUU7QUFBRUs7QUFBRjtBQUFSLEtBQXJCLENBQVA7QUFDRDs7QUFFRFYsS0FBRyxDQUFDVyxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFBRVAsUUFBSSxFQUFFO0FBQVIsR0FBckI7QUFDRCxDQTlCRDs7QUFnQ0EsK0RBQWVQLG1CQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFEQTtBQUNBO0FBR0E7QUFNTyxNQUFNa0IsUUFBc0MsR0FBRztBQUFFbEIscUJBQW1CQTtBQUFyQixDQUEvQztBQUVQLE1BQU1tQixXQUFXLEdBQUdDLDZEQUFjLENBQWM7QUFDOUNDLFNBQU8sRUFBRUMscUVBRHFDO0FBRTlDSjtBQUY4QyxDQUFkLENBQWxDO0FBS0EsK0RBQWVDLFdBQWYsRTs7Ozs7Ozs7Ozs7Ozs7O0FDakJPLE1BQU1JLHdCQUF3QjtBQUFHO0FBQWU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJPLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQSxNQUFNQyxhQUFhO0FBQUc7QUFBZTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FmTztBQWlCQSxNQUFNQyxvQkFBb0I7QUFBRztBQUFlO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMTztBQU9BLE1BQU1DLDRCQUE0QjtBQUFHO0FBQWU7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlELG9CQUFxQjtBQUN6QixDQWJPO0FBZUEsTUFBTUUsbUJBQW1CO0FBQUc7QUFBZTtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUgsYUFBYztBQUNsQixJQUFJRSw0QkFBNkI7QUFDakMsQ0F4RE87QUEwREEsTUFBTUUseUJBQXlCO0FBQUc7QUFBZTtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlELG1CQUFvQjtBQUN4QixDQWZPLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEdQO0FBS0E7QUFDQTtBQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFnQkEsTUFBTUUsT0FBTyxHQUFHQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsOEJBQTVCO0FBQ0EsTUFBTUMsU0FBUyxHQUFHSCxPQUFPLENBQUNDLEdBQVIsQ0FBWUcsZ0NBQTlCO0FBQ0EsTUFBTUMsYUFBYSxHQUFHTCxPQUFPLENBQUNDLEdBQVIsQ0FBWUsseUJBQWxDO0FBQ0EsTUFBTUMsZUFBZSxHQUFHUCxPQUFPLENBQUNDLEdBQVIsQ0FBWU8sMkJBQXBDO0FBQ0EsTUFBTUMsbUJBQW1CLEdBQUdULE9BQU8sQ0FBQ0MsR0FBUixDQUFZUywrQkFBeEM7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBR1gsT0FBTyxDQUFDQyxHQUFSLENBQVlXLHNCQUFyQztBQUNBLE1BQU1DLFNBQVMsR0FBR2IsT0FBTyxDQUFDQyxHQUFSLENBQVlhLHFCQUE5QjtBQUNBLE1BQU1DLGFBQWEsR0FBR2YsT0FBTyxDQUFDQyxHQUFSLENBQVllLG1DQUFsQztBQUNBLE1BQU1DLGVBQWUsR0FBR2pCLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaUIsZ0NBQXBDOztBQUVBLElBQUksQ0FBQ25CLE9BQUwsRUFBYztBQUNaLFFBQU0sSUFBSW9CLEtBQUosQ0FDSCwyR0FERyxDQUFOO0FBR0Q7O0FBRUQsSUFBSSxDQUFDaEIsU0FBTCxFQUFnQjtBQUNkLFFBQU0sSUFBSWdCLEtBQUosQ0FDSCw2R0FERyxDQUFOO0FBR0Q7O0FBRUQsSUFBSSxFQUFFZCxhQUFhLElBQUlFLGVBQWpCLElBQW9DRSxtQkFBdEMsQ0FBSixFQUFnRTtBQUM5RCxRQUFNLElBQUlVLEtBQUosQ0FDSCxnTEFERyxDQUFOO0FBR0Q7O0FBRUQsTUFBTUMsT0FBTyxHQUFHLEtBQUssRUFBTCxHQUFVLEVBQTFCO0FBRUEsTUFBTS9DLE1BQXlCLEdBQUc7QUFDaENnRCxhQUFXLEVBQUV0QixPQURtQjtBQUVoQ3VCLFVBQVEsRUFBRW5CLFNBRnNCO0FBR2hDM0IsZ0JBQWMsRUFBRSxZQUhnQjtBQUloQytDLFlBQVUsMkJBQUV2QixPQUFPLENBQUNDLEdBQVIsQ0FBWXVCLHVCQUFkLHlFQUF5QyxXQUpuQjtBQUtoQ0Msa0JBQWdCLEVBQUVMLE9BQU8sR0FBRyxFQUxJO0FBTWhDMUMsT0FBSyxFQUFFZ0QsaUVBQXFCLENBQUMsTUFBTUMsY0FBYyxHQUFHQyxTQUFqQixFQUFQLENBTkk7QUFPaENDLGFBQVcsRUFBRSxJQVBtQjtBQVFoQztBQUNBQyxhQUFXLEVBQUV6QixhQVRtQjtBQVVoQzBCLGVBQWEsRUFBRXhCLGVBVmlCO0FBV2hDeUIsa0JBQWdCLEVBQUV2QixtQkFYYztBQVloQ3dCLGdCQUFjLEVBQUV0QixnQkFaZ0I7QUFhaEN1QixVQUFRLEVBQUNyQixTQWJ1QjtBQWNoQ3NCLHNCQUFvQixFQUFDcEIsYUFkVztBQWVoQ3FCLFdBQVMsRUFBRW5CLGVBZnFCO0FBZ0JoQ29CLGVBQWEsRUFBRUMsK0RBQW1CLENBQUMsTUFBTVgsY0FBYyxHQUFHQyxTQUFqQixFQUFQO0FBaEJGLENBQWxDO0FBbUJBLE1BQU1XLFVBQVUsR0FBRztBQUNqQkMsT0FEaUI7QUFFakJDLGFBRmlCO0FBR2pCQyxTQUhpQjtBQUlqQkMsYUFKaUI7QUFLakJDLHFCQUxpQjtBQU1qQkMsb0JBTmlCO0FBT2pCQyxnQkFQaUI7QUFRakJDLFlBQVVBO0FBUk8sQ0FBbkI7QUFXTyxNQUFNQyxRQUFRLEdBQUc7QUFBRTNFLFFBQUY7QUFBVWtFO0FBQVYsQ0FBakI7QUFlQSxTQUFTWixjQUFULENBQ0xzQixjQUFpQixHQUFHRCxRQURmLEVBRWM7QUFDbkIsU0FBT0UsOERBQVcsQ0FBQ0QsY0FBRCxDQUFsQjtBQUNELEM7Ozs7Ozs7Ozs7Ozs7OztBQy9HYyxTQUFTRSxvQkFBVCxDQUE4QjtBQUMzQ0M7QUFEMkMsQ0FBOUIsRUFFZ0I7QUFhN0IsaUJBQWVYLFdBQWYsQ0FBMkQ7QUFDekRwRSxVQUR5RDtBQUV6RGdGO0FBRnlELE1BT3ZELEVBUEosRUFPNEI7QUFBQTs7QUFDMUIsVUFBTUMsR0FBRyxHQUFHRixRQUFRLENBQUN4QixTQUFULENBQW1CdkQsTUFBbkIsQ0FBWixDQUQwQixDQUUxQjtBQUNBOztBQUNBLFVBQU07QUFBRUk7QUFBRixRQUFXLE1BQU02RSxHQUFHLENBQUNqQixhQUFKLENBRXJCLG1CQUZxQixDQUF2QjtBQUdBLFVBQU1rQixLQUFLLFdBQUk5RSxJQUFKLHVDQUErQyxFQUExRDtBQUVBLFdBQU87QUFDTDhFLFdBQUssRUFBRUYsT0FBTyxHQUFHRSxLQUFILEdBQVdBLEtBQUssQ0FBQ0MsTUFBTixDQUFjQyxDQUFELElBQU9BLENBQUMsQ0FBQ0MsVUFBdEI7QUFEcEIsS0FBUDtBQUdEOztBQUVELFNBQU9qQixXQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0Q7QUFHTyxNQUFNa0IsdUJBQXVCO0FBQUc7QUFBZTtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FaTztBQWNRLFNBQVNDLDJCQUFULENBQXFDO0FBQ2xEUjtBQURrRCxDQUFyQyxFQUVnQjtBQWU3QixpQkFBZVAsa0JBQWYsQ0FBeUU7QUFDdkVnQixTQUFLLEdBQUdGLHVCQUQrRDtBQUV2RUcsYUFGdUU7QUFHdkV6RjtBQUh1RSxNQVFyRSxFQVJKLEVBUTRCO0FBQUE7O0FBQzFCQSxVQUFNLEdBQUcrRSxRQUFRLENBQUN4QixTQUFULENBQW1CdkQsTUFBbkIsQ0FBVCxDQUQwQixDQUUxQjtBQUNBOztBQUNBLFVBQU07QUFBRUk7QUFBRixRQUFXLE1BQU1KLE1BQU0sQ0FBQ0ssS0FBUCxDQUVyQm1GLEtBRnFCLEVBRWQ7QUFBRUM7QUFBRixLQUZjLENBQXZCO0FBR0EsVUFBTUMsUUFBUSxpQkFBR3RGLElBQUksQ0FBQ3VGLElBQVIsc0VBQUcsV0FBV0QsUUFBZCx3REFBRyxvQkFBcUJFLEtBQXRDO0FBRUEsV0FBTztBQUNMRixjQUFRLEVBQUVHLDREQUFXLENBQUNILFFBQUQsQ0FBWCxDQUE0REksR0FBNUQsQ0FDUixDQUFDO0FBQUVDO0FBQUYsT0FBRCxLQUFjQSxJQUROO0FBREwsS0FBUDtBQUtEOztBQUNELFNBQU92QixrQkFBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkREO0FBQ0E7QUFDQTtBQUVBO0FBRU8sTUFBTXdCLG1CQUFtQjtBQUFHO0FBQWU7QUFDbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUl2RSx5RUFBMEI7QUFDOUIsQ0E1Qk87O0FBMENQLFNBQVN3RSxlQUFULENBQ0VDLFNBREYsRUFFRTtBQUNBLFVBQVFBLFNBQVI7QUFDRSxTQUFLLFVBQUw7QUFDRSxhQUFPLGtCQUFQOztBQUNGLFNBQUssY0FBTDtBQUNFLGFBQU8scUJBQVA7O0FBQ0YsU0FBSyxRQUFMO0FBQ0UsYUFBTyxnQkFBUDs7QUFDRjtBQUNFLGFBQU8sVUFBUDtBQVJKO0FBVUQ7O0FBRWMsU0FBU0MsdUJBQVQsQ0FBaUM7QUFDOUNwQjtBQUQ4QyxDQUFqQyxFQUVnQjtBQWU3QixpQkFBZU4sY0FBZixDQUFpRTtBQUMvRGUsU0FBSyxHQUFHUSxtQkFEdUQ7QUFFL0RQLGFBQVMsRUFBRVcsSUFBSSxHQUFHLEVBRjZDO0FBRy9EcEcsVUFBTSxFQUFFaUY7QUFIdUQsTUFTN0QsRUFUSixFQVM0QjtBQUFBOztBQUMxQixVQUFNakYsTUFBTSxHQUFHK0UsUUFBUSxDQUFDeEIsU0FBVCxDQUFtQjBCLEdBQW5CLENBQWY7QUFDQSxVQUFNO0FBQUVvQjtBQUFGLFFBQWFyRyxNQUFuQjtBQUNBLFVBQU1zRyxLQUFLLEdBQUdMLGVBQWUsQ0FBQ0csSUFBSSxDQUFDRixTQUFOLENBQTdCO0FBQ0EsVUFBTVQsU0FBdUMsR0FBRztBQUM5Q1ksWUFEOEM7QUFFOUNFLGVBQVMsRUFBRSxDQUFDLENBQUNGO0FBRmlDLEtBQWhEO0FBS0FaLGFBQVMsQ0FBQ2EsS0FBRCxDQUFULEdBQW1CLElBQW5CO0FBRUEsUUFBSUYsSUFBSSxDQUFDSSxLQUFULEVBQWdCZixTQUFTLENBQUNlLEtBQVYsR0FBa0JKLElBQUksQ0FBQ0ksS0FBdkI7QUFDaEIsUUFBSUosSUFBSSxDQUFDSyxHQUFULEVBQWNoQixTQUFTLENBQUNpQixTQUFWLEdBQXNCTixJQUFJLENBQUNLLEdBQUwsQ0FBU1gsR0FBVCxDQUFjYSxFQUFELElBQVFDLE1BQU0sQ0FBQ0QsRUFBRCxDQUEzQixDQUF0QixDQVpZLENBYzFCO0FBQ0E7O0FBQ0EsVUFBTTtBQUFFdkc7QUFBRixRQUFXLE1BQU1KLE1BQU0sQ0FBQ0ssS0FBUCxDQUNyQm1GLEtBRHFCLEVBRXJCO0FBQUVDO0FBQUYsS0FGcUIsQ0FBdkI7QUFJQSxVQUFNRyxLQUFLLGlCQUFHeEYsSUFBSSxDQUFDdUYsSUFBUixtRUFBRyxXQUFZVyxLQUFaLENBQUgscURBQUcsaUJBQW9CVixLQUFsQztBQUNBLFVBQU1GLFFBQVEsR0FBR0csNERBQVcsQ0FBQ0QsS0FBRCxDQUE1Qjs7QUFFQSxRQUFJUyxNQUFNLElBQUlyRyxNQUFNLENBQUN3RCxXQUFyQixFQUFrQztBQUNoQ2tDLGNBQVEsQ0FBQ21CLE9BQVQsQ0FBa0JDLE9BQUQsSUFBNEM7QUFDM0QsWUFBSUEsT0FBTyxDQUFDZixJQUFaLEVBQWtCZ0IsdUVBQW9CLENBQUNELE9BQU8sQ0FBQ2YsSUFBVCxDQUFwQjtBQUNuQixPQUZEO0FBR0Q7O0FBRUQsV0FBTztBQUNMTCxjQUFRLEVBQUVBLFFBQVEsQ0FBQ0ksR0FBVCxDQUFhLENBQUM7QUFBRUM7QUFBRixPQUFELEtBQWNpQixnRUFBZ0IsQ0FBQ2pCLElBQUQsQ0FBM0M7QUFETCxLQUFQO0FBR0Q7O0FBRUQsU0FBT3RCLGNBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7QUMxSGMsU0FBU3dDLDRCQUFULENBQXNDO0FBQ25EbEM7QUFEbUQsQ0FBdEMsRUFFZ0I7QUFpQjdCLGlCQUFlUixtQkFBZixDQUEyRTtBQUN6RXZFLFVBRHlFO0FBRXpFeUYsYUFGeUU7QUFHekV5QjtBQUh5RSxHQUEzRSxFQVN1QjtBQUFBOztBQUNyQmxILFVBQU0sR0FBRytFLFFBQVEsQ0FBQ3hCLFNBQVQsQ0FBbUJ2RCxNQUFuQixDQUFUO0FBRUEsVUFBTTtBQUFFSSxVQUFJLEdBQUc7QUFBVCxRQUFnQixNQUFNSixNQUFNLENBQUNnRSxhQUFQLENBRXpCLDZCQUE0QnlCLFNBQVMsQ0FBQzBCLFVBQVcsRUFGeEIsQ0FBNUI7QUFHQSxVQUFNQyxRQUFRLEdBQUdoSCxJQUFJLENBQUMsQ0FBRCxDQUFyQjs7QUFFQSxRQUFJOEcsZUFBZSxJQUFJRSxRQUFKLGFBQUlBLFFBQUosa0NBQUlBLFFBQVEsQ0FBRUMsS0FBZCw0Q0FBSSxnQkFBaUJDLE1BQXhDLEVBQWdEO0FBQUE7O0FBQzlDLFlBQU1iLEdBQUcsdUJBQUdXLFFBQVEsQ0FBQ0MsS0FBWixxREFBRyxpQkFDUnZCLEdBRFEsQ0FDSHlCLElBQUQsSUFBV0EsSUFBSSxTQUFKLElBQUFBLElBQUksV0FBSixJQUFBQSxJQUFJLENBQUVDLFVBQU4sR0FBbUJDLE1BQU0sQ0FBQ0YsSUFBRCxhQUFDQSxJQUFELHVCQUFDQSxJQUFJLENBQUVDLFVBQVAsQ0FBekIsR0FBOEMsSUFEckQsRUFFVHJDLE1BRlMsQ0FFRHdCLEVBQUQsSUFBc0IsQ0FBQyxDQUFDQSxFQUZ0QixDQUFaOztBQUlBLFVBQUlGLEdBQUosYUFBSUEsR0FBSixlQUFJQSxHQUFHLENBQUVhLE1BQVQsRUFBaUI7QUFDZixjQUFNSSxXQUFXLEdBQUcsTUFBTTNDLFFBQVEsQ0FBQ04sY0FBVCxDQUF3QjtBQUNoRGdCLG1CQUFTLEVBQUU7QUFBRWUsaUJBQUssRUFBRSxFQUFUO0FBQWFDO0FBQWIsV0FEcUM7QUFFaER6RztBQUZnRCxTQUF4QixDQUExQixDQURlLENBS2Y7O0FBQ0EsY0FBTTJILFlBQVksR0FBR0QsV0FBVyxDQUFDaEMsUUFBWixDQUFxQmtDLE1BQXJCLENBRWxCLENBQUNDLEtBQUQsRUFBUXpDLENBQVIsS0FBYztBQUNmeUMsZUFBSyxDQUFDakIsTUFBTSxDQUFDeEIsQ0FBQyxDQUFDdUIsRUFBSCxDQUFQLENBQUwsR0FBc0J2QixDQUF0QjtBQUNBLGlCQUFPeUMsS0FBUDtBQUNELFNBTG9CLEVBS2xCLEVBTGtCLENBQXJCLENBTmUsQ0FZZjs7QUFDQVQsZ0JBQVEsQ0FBQ0MsS0FBVCxDQUFlUixPQUFmLENBQXdCVSxJQUFELElBQVU7QUFDL0IsZ0JBQU1ULE9BQU8sR0FBR1MsSUFBSSxJQUFJSSxZQUFZLENBQUNKLElBQUksQ0FBQ0MsVUFBTixDQUFwQzs7QUFDQSxjQUFJRCxJQUFJLElBQUlULE9BQVosRUFBcUI7QUFDbkI7QUFDQVMsZ0JBQUksQ0FBQ1QsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7QUFDRixTQU5EO0FBT0Q7QUFDRjs7QUFFRCxXQUFPO0FBQUVNLGNBQVEsRUFBRUE7QUFBWixLQUFQO0FBQ0Q7O0FBRUQsU0FBTzdDLG1CQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3pFRDtBQUVlLFNBQVN1RCxnQkFBVCxDQUEwQjtBQUN2Qy9DO0FBRHVDLENBQTFCLEVBRWdCO0FBZTdCLGlCQUFlVixPQUFmLENBQW1EO0FBQ2pEMEQsT0FEaUQ7QUFFakR0QyxhQUZpRDtBQUdqRHpGLFVBSGlEO0FBSWpEZ0Y7QUFKaUQsR0FBbkQsRUFVdUI7QUFDckIsVUFBTUMsR0FBRyxHQUFHRixRQUFRLENBQUN4QixTQUFULENBQW1CdkQsTUFBbkIsQ0FBWixDQURxQixDQUVyQjtBQUNBOztBQUNBLFVBQU07QUFBRUk7QUFBRixRQUFXLE1BQU02RSxHQUFHLENBQUNqQixhQUFKLENBRXJCK0QsR0FBRyxJQUFLLHdCQUF1QnRDLFNBQVMsQ0FBQ2tCLEVBQUcsZUFGdkIsQ0FBdkI7QUFHQSxVQUFNcUIsU0FBUyxHQUFHNUgsSUFBSCxhQUFHQSxJQUFILHVCQUFHQSxJQUFJLENBQUcsQ0FBSCxDQUF0QjtBQUNBLFVBQU02SCxJQUFJLEdBQUdELFNBQWI7O0FBRUEsUUFBSWhELE9BQU8sSUFBSWlELElBQUosYUFBSUEsSUFBSixlQUFJQSxJQUFJLENBQUU1QyxVQUFyQixFQUFpQztBQUMvQixhQUFPO0FBQUU0QyxZQUFJLEVBQUVDLDZEQUFhLENBQUNELElBQUQ7QUFBckIsT0FBUDtBQUNEOztBQUNELFdBQU8sRUFBUDtBQUNEOztBQUVELFNBQU81RCxPQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvQ0Q7QUFDQTtBQUVBO0FBRU8sTUFBTThELGVBQWU7QUFBRztBQUFlO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTNHLG1FQUFvQjtBQUN4QixDQW5ETyxDLENBcURQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUsU0FBUytELDJCQUFULENBQXFDO0FBQ2xEUjtBQURrRCxDQUFyQyxFQUVnQjtBQWU3QixpQkFBZUwsVUFBZixPQVN1QjtBQUFBOztBQUFBLFFBVGtDO0FBQ3ZEYyxXQUFLLEdBQUcyQyxlQUQrQztBQUV2RDFDLGVBQVMsRUFBRTtBQUFFMkM7QUFBRixPQUY0QztBQUd2RHBJLFlBQU0sRUFBRWlGO0FBSCtDLEtBU2xDO0FBQUEsUUFQQ21CLElBT0QsaUNBUHJCWCxTQU9xQjs7QUFDckIsVUFBTXpGLE1BQU0sR0FBRytFLFFBQVEsQ0FBQ3hCLFNBQVQsQ0FBbUIwQixHQUFuQixDQUFmO0FBQ0EsVUFBTTtBQUFFb0I7QUFBRixRQUFhckcsTUFBbkI7QUFDQSxVQUFNeUYsU0FBbUMsR0FBRztBQUMxQ1ksWUFEMEM7QUFFMUNFLGVBQVMsRUFBRSxDQUFDLENBQUNGLE1BRjZCO0FBRzFDZ0MsVUFBSSxFQUFFRCxJQUFJLEdBQUksSUFBR0EsSUFBSyxHQUFaLEdBQWlCaEMsSUFBSSxDQUFDaUM7QUFIVSxLQUE1QztBQUtBLFVBQU07QUFBRWpJO0FBQUYsUUFBVyxNQUFNSixNQUFNLENBQUNLLEtBQVAsQ0FBOEJtRixLQUE5QixFQUFxQztBQUFFQztBQUFGLEtBQXJDLENBQXZCO0FBQ0EsVUFBTXFCLE9BQU8saUJBQUcxRyxJQUFJLENBQUN1RixJQUFSLG1FQUFHLFdBQVcyQyxLQUFkLHFEQUFHLGlCQUFrQnZDLElBQWxDOztBQUVBLFFBQUksQ0FBQWUsT0FBTyxTQUFQLElBQUFBLE9BQU8sV0FBUCxZQUFBQSxPQUFPLENBQUV5QixVQUFULE1BQXdCLFNBQTVCLEVBQXVDO0FBQ3JDLFVBQUlsQyxNQUFNLElBQUlyRyxNQUFNLENBQUN3RCxXQUFyQixFQUFrQztBQUNoQ3VELCtFQUFvQixDQUFDRCxPQUFELENBQXBCO0FBQ0Q7O0FBRUQsYUFBTztBQUFFQSxlQUFPLEVBQUVFLGdFQUFnQixDQUFDRixPQUFEO0FBQTNCLE9BQVA7QUFDRDs7QUFFRCxXQUFPLEVBQVA7QUFDRDs7QUFDRCxTQUFPcEMsVUFBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSEQ7QUFFQTtDQUdBOztBQUNPLE1BQU04RCxnQkFBZ0I7QUFBRztBQUFlO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJcEgsOEVBQXlCO0FBQzdCLENBckNPO0FBdUNRLFNBQVNxSCxvQkFBVCxDQUE4QjtBQUMzQzFEO0FBRDJDLENBQTlCLEVBRWdCO0FBYTdCLGlCQUFlVCxXQUFmLENBQTJEO0FBQ3pEa0IsU0FBSyxHQUFHZ0QsZ0JBRGlEO0FBRXpEeEk7QUFGeUQsTUFPdkQsRUFQSixFQU80QjtBQUFBOztBQUMxQixVQUFNaUYsR0FBRyxHQUFHRixRQUFRLENBQUN4QixTQUFULENBQW1CdkQsTUFBbkIsQ0FBWjtBQUNBLFVBQU07QUFBRUk7QUFBRixRQUFXLE1BQU02RSxHQUFHLENBQUM1RSxLQUFKLENBQTRCbUYsS0FBNUIsQ0FBdkI7QUFDQSxVQUFNa0QsVUFBVSxHQUFHdEksSUFBSSxDQUFDdUYsSUFBTCxDQUFVZ0QsWUFBVixDQUF1QjdDLEdBQXZCLENBQTJCOEMsNkRBQTNCLENBQW5CO0FBQ0EsVUFBTUMsTUFBTSxpQkFBR3pJLElBQUksQ0FBQ3VGLElBQVIsb0VBQUcsV0FBV2tELE1BQWQsc0RBQUcsa0JBQW1CakQsS0FBbEM7QUFFQSxXQUFPO0FBQ0w4QyxnQkFBVSxFQUFFQSxVQUFGLGFBQUVBLFVBQUYsY0FBRUEsVUFBRixHQUFnQixFQURyQjtBQUVMRyxZQUFNLEVBQUVoRCw0REFBVyxDQUFDZ0QsTUFBRDtBQUZkLEtBQVA7QUFJRDs7QUFFRCxTQUFPdkUsV0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUVEO0FBR08sTUFBTXdFLGFBQWE7QUFBRztBQUFlO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5PO0FBUVEsU0FBU0MsY0FBVCxDQUF3QjtBQUNyQ2hFO0FBRHFDLENBQXhCLEVBRWdCO0FBZTdCLGlCQUFlWixLQUFmLENBQStDO0FBQzdDcUIsU0FBSyxHQUFHc0QsYUFEcUM7QUFFN0NyRCxhQUY2QztBQUc3QzFGLE9BQUcsRUFBRWlKLFFBSHdDO0FBSTdDaEo7QUFKNkMsR0FBL0MsRUFVdUI7QUFBQTs7QUFDckJBLFVBQU0sR0FBRytFLFFBQVEsQ0FBQ3hCLFNBQVQsQ0FBbUJ2RCxNQUFuQixDQUFUO0FBRUEsVUFBTTtBQUFFSSxVQUFGO0FBQVFMO0FBQVIsUUFBZ0IsTUFBTUMsTUFBTSxDQUFDSyxLQUFQLENBQzFCbUYsS0FEMEIsRUFFMUI7QUFBRUM7QUFBRixLQUYwQixDQUE1QixDQUhxQixDQU9yQjs7QUFDQSxRQUFJakYsTUFBTSxHQUFHVCxHQUFHLENBQUNRLE9BQUosQ0FBWTBJLEdBQVosQ0FBZ0IsWUFBaEIsQ0FBYjs7QUFFQSxRQUFJekksTUFBTSxJQUFJLE9BQU9BLE1BQVAsS0FBa0IsUUFBaEMsRUFBMEM7QUFDeEM7QUFDQSxnQkFBMkM7QUFDekNBLGNBQU0sR0FBR0EsTUFBTSxDQUFDMEksT0FBUCxDQUFlLFVBQWYsRUFBMkIsRUFBM0IsQ0FBVCxDQUR5QyxDQUV6QztBQUNBO0FBQ0E7O0FBQ0ExSSxjQUFNLEdBQUdBLE1BQU0sQ0FBQzBJLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxnQkFBcEMsQ0FBVDtBQUNEOztBQUVERixjQUFRLENBQUNHLFNBQVQsQ0FDRSxZQURGLEVBRUVDLDZEQUFZLENBQUNKLFFBQVEsQ0FBQ0ssU0FBVCxDQUFtQixZQUFuQixDQUFELEVBQW1DN0ksTUFBbkMsQ0FGZDtBQUlEOztBQUVELFdBQU87QUFDTDhJLFlBQU0saUJBQUVsSixJQUFJLENBQUMrRCxLQUFQLGdEQUFFLFlBQVltRjtBQURmLEtBQVA7QUFHRDs7QUFFRCxTQUFPbkYsS0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7OztBQzVFYyxTQUFTaUYsWUFBVCxDQUFzQkcsSUFBdEIsRUFBb0NDLEdBQXBDLEVBQWlEO0FBQzlELE1BQUksQ0FBQ0EsR0FBTCxFQUFVLE9BQU9ELElBQVA7QUFDVixNQUFJLENBQUNBLElBQUwsRUFBVyxPQUFPQyxHQUFQO0FBRVgsTUFBSUMsS0FBSyxDQUFDQyxPQUFOLENBQWNILElBQWQsQ0FBSixFQUF5QixPQUFPQSxJQUFJLENBQUNJLE1BQUwsQ0FBWWxDLE1BQU0sQ0FBQytCLEdBQUQsQ0FBbEIsQ0FBUDtBQUV6QkQsTUFBSSxHQUFHOUIsTUFBTSxDQUFDOEIsSUFBRCxDQUFiO0FBRUEsTUFBSUUsS0FBSyxDQUFDQyxPQUFOLENBQWNGLEdBQWQsQ0FBSixFQUF3QixPQUFPLENBQUNELElBQUQsRUFBT0ksTUFBUCxDQUFjSCxHQUFkLENBQVA7QUFFeEIsU0FBTyxDQUFDRCxJQUFELEVBQU85QixNQUFNLENBQUMrQixHQUFELENBQWIsQ0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYRDtBQUNPLE1BQU1JLHVCQUFOLFNBQXNDOUcsS0FBdEMsQ0FBNEM7QUFFNUMsTUFBTStHLG1CQUFOLFNBQWtDL0csS0FBbEMsQ0FBd0M7QUFLN0NnSCxhQUFXLENBQUNDLEdBQUQsRUFBY2hLLEdBQWQsRUFBNkJLLElBQTdCLEVBQXlDO0FBQ2xELFVBQU0ySixHQUFOOztBQURrRDs7QUFBQTs7QUFBQTs7QUFFbEQsU0FBS0MsSUFBTCxHQUFZLHFCQUFaO0FBQ0EsU0FBS3RKLE1BQUwsR0FBY1gsR0FBRyxDQUFDVyxNQUFsQjtBQUNBLFNBQUtYLEdBQUwsR0FBV0EsR0FBWDtBQUNBLFNBQUtLLElBQUwsR0FBWUEsSUFBWjtBQUNEOztBQVg0QztBQWN4QyxNQUFNNkosdUJBQU4sU0FBc0NuSCxLQUF0QyxDQUE0QztBQUNqRGdILGFBQVcsQ0FBQ0MsR0FBRCxFQUFjO0FBQ3ZCLFVBQU1BLEdBQU47QUFDQSxTQUFLQyxJQUFMLEdBQVkseUJBQVo7QUFDRDs7QUFKZ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQm5EO0FBR0E7O0FBRUEsTUFBTUUsZUFBdUUsR0FDMUUzRyxTQUFELElBQ0EsT0FBT2lDLEtBQVAsRUFBc0I7QUFBRUMsV0FBRjtBQUFhVDtBQUFiLElBQXlCLEVBQS9DLEVBQW1EbUYsWUFBbkQsS0FBb0U7QUFDbEU7QUFDQSxRQUFNbkssTUFBTSxHQUFHdUQsU0FBUyxFQUF4QjtBQUNBLFFBQU14RCxHQUFHLEdBQUcsTUFBTU0sK0NBQUssQ0FBQ0wsTUFBTSxDQUFDZ0QsV0FBUCxJQUFzQmdDLE9BQU8sR0FBRyxVQUFILEdBQWdCLEVBQTdDLENBQUQsa0NBQ2xCbUYsWUFEa0I7QUFFckJDLFVBQU0sRUFBRSxNQUZhO0FBR3JCN0osV0FBTztBQUNMOEosbUJBQWEsRUFBRyxVQUFTckssTUFBTSxDQUFDaUQsUUFBUztBQURwQyxPQUVGa0gsWUFGRSxhQUVGQSxZQUZFLHVCQUVGQSxZQUFZLENBQUU1SixPQUZaO0FBR0wsc0JBQWdCO0FBSFgsTUFIYztBQVFyQitKLFFBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDbkJoRixXQURtQjtBQUVuQkM7QUFGbUIsS0FBZjtBQVJlLEtBQXZCO0FBY0EsUUFBTTlFLElBQUksR0FBRyxNQUFNWixHQUFHLENBQUNZLElBQUosRUFBbkI7O0FBQ0EsTUFBSUEsSUFBSSxDQUFDQyxNQUFULEVBQWlCO0FBQUE7O0FBQ2YsVUFBTSxJQUFJNkosZ0VBQUosQ0FBaUI7QUFDckI3SixZQUFNLGtCQUFFRCxJQUFJLENBQUNDLE1BQVAsdURBQWlCLENBQUM7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBRCxDQURGO0FBRXJCSCxZQUFNLEVBQUVYLEdBQUcsQ0FBQ1c7QUFGUyxLQUFqQixDQUFOO0FBSUQ7O0FBRUQsU0FBTztBQUFFTixRQUFJLEVBQUVPLElBQUksQ0FBQ1AsSUFBYjtBQUFtQkw7QUFBbkIsR0FBUDtBQUNELENBNUJIOztBQThCQSwrREFBZW1LLGVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqQ0E7QUFDQTs7QUFFQSxNQUFNUSxhQUFhLEdBQ2JuSCxTQUFKLElBQ0EsT0FBT29ILFFBQVAsRUFBeUJDLE9BQXpCLEtBQStEO0FBQzdELFFBQU01SyxNQUFNLEdBQUd1RCxTQUFTLEVBQXhCO0FBQ0EsTUFBSXhELEdBQUo7O0FBRUEsTUFBSTtBQUNGQSxPQUFHLEdBQUcsTUFBTU0sK0NBQUssQ0FBQ0wsTUFBTSxDQUFDeUQsV0FBUCxHQUFxQmtILFFBQXRCLGtDQUNaQyxPQURZO0FBRWZySyxhQUFPLGtDQUNGcUssT0FERSxhQUNGQSxPQURFLHVCQUNGQSxPQUFPLENBQUVySyxPQURQO0FBRUwsd0JBQWdCLGtCQUZYO0FBR0wsd0JBQWdCUCxNQUFNLENBQUMwRCxhQUhsQjtBQUlMLHlCQUFpQjFELE1BQU0sQ0FBQzJEO0FBSm5CO0FBRlEsT0FBakI7QUFTRCxHQVZELENBVUUsT0FBT2tILEtBQVAsRUFBYztBQUNkLFVBQU0sSUFBSVosNERBQUosQ0FDSCxnQ0FBK0JZLEtBQUssQ0FBQ2hLLE9BQVEsRUFEMUMsQ0FBTjtBQUdEOztBQUVELFFBQU1pSyxXQUFXLEdBQUcvSyxHQUFHLENBQUNRLE9BQUosQ0FBWTBJLEdBQVosQ0FBZ0IsY0FBaEIsQ0FBcEI7QUFDQSxRQUFNOEIsTUFBTSxHQUFHRCxXQUFILGFBQUdBLFdBQUgsdUJBQUdBLFdBQVcsQ0FBRUUsUUFBYixDQUFzQixrQkFBdEIsQ0FBZjs7QUFFQSxNQUFJLENBQUNqTCxHQUFHLENBQUNrTCxFQUFULEVBQWE7QUFDWCxVQUFNN0ssSUFBSSxHQUFHMkssTUFBTSxHQUFHLE1BQU1oTCxHQUFHLENBQUNZLElBQUosRUFBVCxHQUFzQixNQUFNdUssYUFBYSxDQUFDbkwsR0FBRCxDQUE1RDtBQUNBLFVBQU1RLE9BQU8sR0FBRzRLLGFBQWEsQ0FBQ3BMLEdBQUQsQ0FBN0I7QUFDQSxVQUFNZ0ssR0FBRyxHQUFJLDJCQUNYaEssR0FBRyxDQUFDVyxNQUNMLGdCQUFlNkosSUFBSSxDQUFDQyxTQUFMLENBQWVqSyxPQUFmLEVBQXdCLElBQXhCLEVBQThCLENBQTlCLENBQWlDLEtBQy9DLE9BQU9ILElBQVAsS0FBZ0IsUUFBaEIsR0FBMkJBLElBQTNCLEdBQWtDbUssSUFBSSxDQUFDQyxTQUFMLENBQWVwSyxJQUFmLEVBQXFCLElBQXJCLEVBQTJCLENBQTNCLENBQ25DLEVBSkQ7QUFNQSxVQUFNLElBQUl5Six3REFBSixDQUF3QkUsR0FBeEIsRUFBNkJoSyxHQUE3QixFQUFrQ0ssSUFBbEMsQ0FBTjtBQUNEOztBQUVELE1BQUlMLEdBQUcsQ0FBQ1csTUFBSixLQUFlLEdBQWYsSUFBc0IsQ0FBQ3FLLE1BQTNCLEVBQW1DO0FBQ2pDLFVBQU0sSUFBSWxCLHdEQUFKLENBQ0gscUVBQW9FaUIsV0FBWSxFQUQ3RSxFQUVKL0ssR0FGSSxDQUFOO0FBSUQsR0F4QzRELENBMEM3RDs7O0FBQ0EsU0FBT0EsR0FBRyxDQUFDVyxNQUFKLEtBQWUsR0FBZixHQUFxQixJQUFyQixHQUE0QixNQUFNWCxHQUFHLENBQUNZLElBQUosRUFBekM7QUFDRCxDQTlDSDs7QUErQ0EsK0RBQWUrSixhQUFmOztBQUVBLFNBQVNTLGFBQVQsQ0FBdUJwTCxHQUF2QixFQUFzQztBQUNwQyxRQUFNUSxPQUFrQyxHQUFHLEVBQTNDO0FBRUFSLEtBQUcsQ0FBQ1EsT0FBSixDQUFZc0csT0FBWixDQUFvQixDQUFDdUUsS0FBRCxFQUFRQyxHQUFSLEtBQWdCO0FBQ2xDOUssV0FBTyxDQUFDOEssR0FBRCxDQUFQLEdBQWVELEtBQWY7QUFDRCxHQUZEO0FBSUEsU0FBTzdLLE9BQVA7QUFDRDs7QUFFRCxTQUFTMkssYUFBVCxDQUF1Qm5MLEdBQXZCLEVBQXNDO0FBQ3BDLE1BQUk7QUFDRixXQUFPQSxHQUFHLENBQUN1TCxJQUFKLEVBQVA7QUFDRCxHQUZELENBRUUsT0FBT0MsR0FBUCxFQUFZO0FBQ1osV0FBTyxJQUFQO0FBQ0Q7QUFDRixDOzs7Ozs7Ozs7Ozs7OztBQ3RFRDtBQUVBLCtEQUFlQyxvREFBUyxFQUF4QixFOzs7Ozs7Ozs7Ozs7Ozs7QUNGZSxTQUFTM0YsV0FBVCxDQUNiRCxLQURhLEVBRWI7QUFBQTs7QUFDQSwwQkFBT0EsS0FBUCxhQUFPQSxLQUFQLHVCQUFPQSxLQUFLLENBQUVULE1BQVAsQ0FBZXNHLElBQUQsSUFBcUIsQ0FBQyxDQUFDQSxJQUFyQyxDQUFQLHlEQUFxRCxFQUFyRDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7OztBQ0RjLFNBQVMxRSxvQkFBVCxDQUNiaEIsSUFEYSxFQUViO0FBQUE7O0FBQ0EsMEJBQUlBLElBQUksQ0FBQzJGLFVBQVQsNkNBQUksaUJBQWlCOUYsS0FBckIsRUFBNEI7QUFDMUJHLFFBQUksQ0FBQzJGLFVBQUwsQ0FBZ0I5RixLQUFoQixHQUF3QkcsSUFBSSxDQUFDMkYsVUFBTCxDQUFnQjlGLEtBQWhCLENBQXNCVCxNQUF0QixDQUE4QnNHLElBQUQsSUFBVTtBQUFBOztBQUM3RCxZQUFNO0FBQUVKLFdBQUY7QUFBT0Q7QUFBUCx3QkFBaUJLLElBQWpCLGFBQWlCQSxJQUFqQix1QkFBaUJBLElBQUksQ0FBRTFGLElBQXZCLG1EQUErQixFQUFyQzs7QUFDQSxVQUFJc0YsR0FBRyxJQUFJQSxHQUFHLElBQUl0RixJQUFsQixFQUF3QjtBQUN0QjtBQUFFQSxZQUFELENBQWNzRixHQUFkLElBQXFCRCxLQUFyQjtBQUNELGVBQU8sS0FBUDtBQUNEOztBQUNELGFBQU8sSUFBUDtBQUNELEtBUHVCLENBQXhCOztBQVNBLFFBQUksQ0FBQ3JGLElBQUksQ0FBQzJGLFVBQUwsQ0FBZ0I5RixLQUFoQixDQUFzQjBCLE1BQTNCLEVBQW1DO0FBQ2pDLGFBQU92QixJQUFJLENBQUMyRixVQUFaO0FBQ0Q7QUFDRjtBQUNGLEM7Ozs7Ozs7Ozs7OztBQ3BCRDtBQUNBO0FBQ0EsTUFBTUMsT0FBTyxHQUFJdEQsSUFBRCxJQUFrQkEsSUFBSSxDQUFDYSxPQUFMLENBQWEsVUFBYixFQUF5QixFQUF6QixDQUFsQzs7QUFFQSwrREFBZXlDLE9BQWYsRTs7Ozs7Ozs7Ozs7Ozs7QUNKQTtBQUVBLE1BQU1DLENBQUMsR0FBRyxJQUFJQyx3REFBSixFQUFWO0FBRUFELENBQUMsQ0FBQ0UsTUFBRixDQUFTLE9BQVQsRUFBa0IsVUFBVVYsS0FBVixFQUFpQlcsTUFBakIsRUFBeUI7QUFDekMsU0FBT0EsTUFBTSxHQUFHSCxDQUFDLENBQUNJLE1BQUYsQ0FBU0QsTUFBVCxFQUFpQlgsS0FBakIsQ0FBSCxHQUE2QlEsQ0FBQyxDQUFDSSxNQUFGLENBQVMsRUFBVCxFQUFhWixLQUFiLENBQTFDO0FBQ0QsQ0FGRDtBQUlBUSxDQUFDLENBQUNFLE1BQUYsQ0FBUyxZQUFULEVBQXVCLFVBQVVWLEtBQVYsRUFBaUJXLE1BQWpCLEVBQXlCO0FBQzlDLFNBQU9BLE1BQU0sR0FBR0gsQ0FBQyxDQUFDSSxNQUFGLENBQVNELE1BQVQsRUFBaUJYLEtBQWpCLENBQUgsR0FBNkJRLENBQUMsQ0FBQ0ksTUFBRixDQUFTLEVBQVQsRUFBYVosS0FBYixDQUExQztBQUNELENBRkQ7QUFJQSwrREFBZVEsQ0FBQyxDQUFDSSxNQUFqQixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTtBQUNBOztBQUVBLFNBQVNDLHNCQUFULENBQWdDQyxhQUFoQyxFQUFvRDtBQUNsRCxRQUFNO0FBQ0puRyxRQUFJLEVBQUU7QUFDSm9HLGNBREk7QUFFSkMsWUFBTSxFQUFFO0FBQUV4RyxhQUFLLEdBQUc7QUFBVixVQUFpQjtBQUZyQjtBQURGLE1BTUZzRyxhQU5KO0FBQUEsUUFJT0csSUFKUCw0QkFNSUgsYUFOSixDQUNFbkcsSUFERjs7QUFRQTtBQUNFWSxNQUFFLEVBQUV3RixRQUROO0FBRUVDLFVBQU0sRUFBRXhHLEtBQUYsYUFBRUEsS0FBRix1QkFBRUEsS0FBSyxDQUFFRSxHQUFQLENBQVcsQ0FBQztBQUFFQztBQUFGLEtBQUQsS0FBbUJBLElBQTlCO0FBRlYsS0FHS3NHLElBSEw7QUFLRDs7QUFFTSxTQUFTckYsZ0JBQVQsQ0FBMEJzRixXQUExQixFQUFxRDtBQUMxRCxRQUFNO0FBQ0pILFlBQVEsRUFBRXhGLEVBRE47QUFFSjRGLGtCQUZJO0FBR0pDLFVBSEk7QUFJSm5FLFFBSkk7QUFLSjFCLE1BQUUsRUFBRThGLENBTEE7QUFNSjdCLFdBQU8sRUFBRThCO0FBTkwsTUFPRkosV0FQSjtBQVNBLFNBQU9OLHNEQUFNLENBQUNNLFdBQUQsRUFBYztBQUN6QjNGLE1BQUUsRUFBRTtBQUFFZ0csVUFBSSxFQUFFbEYsTUFBTSxDQUFDZCxFQUFEO0FBQWQsS0FEcUI7QUFFekJpRyxVQUFNLEVBQUU7QUFDTkMsWUFBTSxFQUFFLENBQUM7QUFBRWpIO0FBQUYsT0FBRCxLQUNOQSxLQURNLGFBQ05BLEtBRE0sdUJBQ05BLEtBQUssQ0FBRUUsR0FBUCxDQUFXO0FBQUEsWUFBQztBQUFFQyxjQUFJLEVBQUU7QUFBRStHLHVCQUFGO0FBQWVDO0FBQWY7QUFBUixTQUFEO0FBQUEsWUFBb0NWLElBQXBDLGlDQUFHdEcsSUFBSDs7QUFBQTtBQUNUZ0MsYUFBRyxFQUFFK0UsV0FESTtBQUVURSxhQUFHLEVBQUVEO0FBRkksV0FHTlYsSUFITTtBQUFBLE9BQVg7QUFGSSxLQUZpQjtBQVV6QlksWUFBUSxFQUFFO0FBQ1JKLFlBQU0sRUFBRSxDQUFDO0FBQUVqSDtBQUFGLE9BQUQsS0FDTkEsS0FETSxhQUNOQSxLQURNLHVCQUNOQSxLQUFLLENBQUVFLEdBQVAsQ0FBVztBQUFBLFlBQUM7QUFBRUMsY0FBSSxFQUFFO0FBQUVvRyxvQkFBRjtBQUFZSTtBQUFaO0FBQVIsU0FBRDtBQUFBLFlBQXdDRixJQUF4QyxrQ0FBR3RHLElBQUg7O0FBQUE7QUFDVFksWUFBRSxFQUFFd0YsUUFESztBQUVUdkIsaUJBQU8sRUFBRTJCLGNBQWMsU0FBZCxJQUFBQSxjQUFjLFdBQWQsSUFBQUEsY0FBYyxDQUFFM0csS0FBaEIsR0FDTDJHLGNBQWMsQ0FBQzNHLEtBQWYsQ0FBcUJFLEdBQXJCLENBQXlCbUcsc0JBQXpCLENBREssR0FFTDtBQUpLLFdBS05JLElBTE07QUFBQSxPQUFYO0FBRk0sS0FWZTtBQW9CekJ6QixXQUFPLEVBQUU7QUFDUCtCLFVBQUksRUFBRUosY0FBYyxDQUFDM0csS0FBZixHQUNGMkcsY0FERSxhQUNGQSxjQURFLHVCQUNGQSxjQUFjLENBQUUzRyxLQUFoQixDQUFzQkUsR0FBdEIsQ0FBMEJtRyxzQkFBMUIsQ0FERSxHQUVGO0FBSEcsS0FwQmdCO0FBeUJ6QmlCLFNBQUssRUFBRTtBQUNMTCxZQUFNLEVBQUdLLEtBQUQsSUFBaUJBLEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsSUFBQUEsS0FBSyxDQUFFZixRQUFQLEdBQWtCZSxLQUFsQixhQUFrQkEsS0FBbEIsdUJBQWtCQSxLQUFLLENBQUVmLFFBQXpCLEdBQW9DO0FBRHhELEtBekJrQjtBQTRCekIvRCxRQUFJLEVBQUU7QUFDSnVFLFVBQUksRUFBRXRFLElBQUYsYUFBRUEsSUFBRix1QkFBRUEsSUFBSSxDQUFFYSxPQUFOLENBQWMsWUFBZCxFQUE0QixFQUE1QjtBQURGLEtBNUJtQjtBQStCekJpRSxTQUFLLEVBQUU7QUFDTFIsVUFBSSxFQUFFO0FBQ0p2QixhQUFLLEVBQUVvQixNQUFGLGFBQUVBLE1BQUYsdUJBQUVBLE1BQU0sQ0FBRVcsS0FBUixDQUFjL0IsS0FEakI7QUFFSmdDLG9CQUFZLEVBQUVaLE1BQUYsYUFBRUEsTUFBRix1QkFBRUEsTUFBTSxDQUFFVyxLQUFSLENBQWNDO0FBRnhCO0FBREQsS0EvQmtCO0FBcUN6QkMsVUFBTSxFQUFFLENBQUMsVUFBRDtBQXJDaUIsR0FBZCxDQUFiO0FBdUNEO0FBRU0sU0FBU25GLGFBQVQsQ0FBdUJELElBQXZCLEVBQTZEO0FBQ2xFLFNBQU87QUFDTHRCLE1BQUUsRUFBRWMsTUFBTSxDQUFDUSxJQUFJLENBQUN0QixFQUFOLENBREw7QUFFTHFELFFBQUksRUFBRS9CLElBQUksQ0FBQytCLElBRk47QUFHTDNFLGNBQVUsRUFBRTRDLElBQUksQ0FBQzVDLFVBSFo7QUFJTGlJLGNBQVUsRUFBRXJGLElBQUksQ0FBQ3FGLFVBSlo7QUFLTGhELFFBQUksRUFBRXJDLElBQUksQ0FBQ3FDO0FBTE4sR0FBUDtBQU9EO0FBRU0sU0FBU2lELGFBQVQsQ0FBdUJuTixJQUF2QixFQUFvRDtBQUFBOztBQUN6RCxTQUFPO0FBQ0x1RyxNQUFFLEVBQUV2RyxJQUFJLENBQUN1RyxFQURKO0FBRUxRLGNBQVUsRUFBRU0sTUFBTSxDQUFDckgsSUFBSSxDQUFDb04sV0FBTixDQUZiO0FBR0xDLFNBQUssRUFBRXJOLElBQUksQ0FBQ3FOLEtBSFA7QUFJTEMsYUFBUyxFQUFFdE4sSUFBSSxDQUFDdU4sWUFKWDtBQUtMQyxZQUFRLEVBQUV4TixJQUFJLENBQUN3TixRQUxWO0FBTUxDLGlCQUFhLEVBQUV6TixJQUFJLENBQUMwTixZQU5mO0FBT0xDLGFBQVMsRUFBRSxDQUNULEdBQUczTixJQUFJLENBQUM0TixVQUFMLENBQWdCQyxjQUFoQixDQUErQm5JLEdBQS9CLENBQW1Db0ksaUJBQW5DLENBRE0sRUFFVCxHQUFHOU4sSUFBSSxDQUFDNE4sVUFBTCxDQUFnQkcsYUFBaEIsQ0FBOEJySSxHQUE5QixDQUFrQ29JLGlCQUFsQyxDQUZNLENBUE47QUFXTEUsMEJBQXNCLEVBQUVoTyxJQUFJLENBQUNpTyxXQVh4QjtBQVlMQyxpQkFBYSxFQUFFbE8sSUFBSSxDQUFDaU8sV0FBTCxHQUFtQmpPLElBQUksQ0FBQ21PLGVBWmxDO0FBYUxDLGNBQVUsRUFBRXBPLElBQUksQ0FBQ3FPLFdBYlo7QUFjTEMsYUFBUyxxQkFBRXRPLElBQUksQ0FBQ3NPLFNBQVAsb0RBQUUsZ0JBQWdCNUksR0FBaEIsQ0FBcUI2SSxRQUFELEtBQWU7QUFDNUN2RCxXQUFLLEVBQUV1RCxRQUFRLENBQUNDO0FBRDRCLEtBQWYsQ0FBcEI7QUFkTixHQUFQO0FBa0JEOztBQUVELFNBQVNWLGlCQUFULENBQTJCM0csSUFBM0IsRUFBZ0Q7QUFDOUMsU0FBTztBQUNMWixNQUFFLEVBQUVZLElBQUksQ0FBQ1osRUFESjtBQUVMa0ksYUFBUyxFQUFFcEgsTUFBTSxDQUFDRixJQUFJLENBQUN1SCxVQUFOLENBRlo7QUFHTEMsYUFBUyxFQUFFdEgsTUFBTSxDQUFDRixJQUFJLENBQUNDLFVBQU4sQ0FIWjtBQUlMd0MsUUFBSSxFQUFFekMsSUFBSSxDQUFDeUMsSUFKTjtBQUtMZ0YsWUFBUSxFQUFFekgsSUFBSSxDQUFDeUgsUUFMVjtBQU1MQyxXQUFPLEVBQUU7QUFDUHRJLFFBQUUsRUFBRWMsTUFBTSxDQUFDRixJQUFJLENBQUN1SCxVQUFOLENBREg7QUFFUEksU0FBRyxFQUFFM0gsSUFBSSxDQUFDMkgsR0FGSDtBQUdQbEYsVUFBSSxFQUFFekMsSUFBSSxDQUFDeUMsSUFISjtBQUlQbUYsV0FBSyxFQUFFO0FBQ0xwSCxXQUFHLEVBQUVSLElBQUksQ0FBQzZIO0FBREwsT0FKQTtBQU9QQyxzQkFBZ0IsRUFBRTlILElBQUksQ0FBQytILG1CQVBoQjtBQVFQbkMsV0FBSyxFQUFFNUYsSUFBSSxDQUFDZ0ksVUFSTDtBQVNQQyxlQUFTLEVBQUVqSSxJQUFJLENBQUNrSTtBQVRULEtBTko7QUFpQkxwSCxRQUFJLEVBQUVkLElBQUksQ0FBQ1EsR0FBTCxDQUFTMkgsS0FBVCxDQUFlLEdBQWYsRUFBb0IsQ0FBcEIsQ0FqQkQ7QUFrQkxoQixhQUFTLEVBQUVuSCxJQUFJLENBQUNtSCxTQUFMLENBQWU1SSxHQUFmLENBQW9CNkksUUFBRCxLQUFvQjtBQUNoRHZELFdBQUssRUFBRXVELFFBQVEsQ0FBQ0M7QUFEZ0MsS0FBcEIsQ0FBbkI7QUFsQk4sR0FBUDtBQXNCRDs7QUFFTSxTQUFTaEcsaUJBQVQsQ0FBMkIrRyxRQUEzQixFQUEyRDtBQUNoRSxTQUFPO0FBQ0xoSixNQUFFLEVBQUcsR0FBRWdKLFFBQVEsQ0FBQ3hELFFBQVMsRUFEcEI7QUFFTG5DLFFBQUksRUFBRTJGLFFBQVEsQ0FBQzNGLElBRlY7QUFHTDVCLFFBQUksRUFBRXVELGtEQUFPLENBQUNnRSxRQUFRLENBQUN0SCxJQUFWLENBSFI7QUFJTEEsUUFBSSxFQUFFc0gsUUFBUSxDQUFDdEg7QUFKVixHQUFQO0FBTUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2SUQ7QUFDQTs7QUFFQSxNQUFNbEgsZ0JBR2tCLEdBQUcsTUFBT3lPLEdBQVAsSUFBZTtBQUN4QyxRQUFNO0FBQUU5UCxPQUFGO0FBQU9DLE9BQVA7QUFBWWdCO0FBQVosTUFBeUI2TyxHQUEvQjs7QUFFQSxNQUNFLENBQUNDLG9FQUFrQixDQUFDL1AsR0FBRCxFQUFNQyxHQUFOLEVBQVc7QUFDNUIrUCxPQUFHLEVBQUUvTyxRQUFRLENBQUMscUJBQUQ7QUFEZSxHQUFYLENBRHJCLEVBSUU7QUFDQTtBQUNEOztBQUVELE1BQUk7QUFDRixVQUFNdUosSUFBSSxHQUFHLElBQWI7QUFDQSxXQUFPLE1BQU12SixRQUFRLENBQUMscUJBQUQsQ0FBUixpQ0FBcUM2TyxHQUFyQztBQUEwQ3RGO0FBQTFDLE9BQWI7QUFDRCxHQUhELENBR0UsT0FBT08sS0FBUCxFQUFjO0FBQ2RrRixXQUFPLENBQUNsRixLQUFSLENBQWNBLEtBQWQ7QUFFQSxVQUFNaEssT0FBTyxHQUNYZ0ssS0FBSyxZQUFZbUYsMkRBQWpCLEdBQ0ksbURBREosR0FFSSw2QkFITjtBQUtBalEsT0FBRyxDQUFDVyxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFBRVAsVUFBSSxFQUFFLElBQVI7QUFBY1EsWUFBTSxFQUFFLENBQUM7QUFBRUM7QUFBRixPQUFEO0FBQXRCLEtBQXJCO0FBQ0Q7QUFDRixDQTNCRDs7QUE2QkEsK0RBQWVNLGdCQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QkE7QUFvRU8sTUFBTThPLGVBQU4sQ0FBMkQ7QUFDaEVuRyxhQUFXLENBQVVuRixRQUFWLEVBQXVCO0FBQUEsU0FBYkEsUUFBYSxHQUFiQSxRQUFhO0FBQUU7O0FBRXBDcEIsV0FBUyxDQUFDMk0sVUFBZ0MsR0FBRyxFQUFwQyxFQUFxRDtBQUM1RCxXQUFPQyxNQUFNLENBQUNDLE9BQVAsQ0FBZUYsVUFBZixFQUEyQnRJLE1BQTNCLENBQ0wsQ0FBQzNDLEdBQUQsRUFBTSxDQUFDb0csR0FBRCxFQUFNRCxLQUFOLENBQU4sS0FBdUIrRSxNQUFNLENBQUNFLE1BQVAsQ0FBY3BMLEdBQWQsRUFBbUI7QUFBRSxPQUFDb0csR0FBRCxHQUFPRDtBQUFULEtBQW5CLENBRGxCLG9CQUVBLEtBQUt6RyxRQUFMLENBQWMzRSxNQUZkLEVBQVA7QUFJRDs7QUFFRHNRLFdBQVMsQ0FBQ0MsU0FBRCxFQUFrQztBQUN6Q0osVUFBTSxDQUFDRSxNQUFQLENBQWMsS0FBSzFMLFFBQUwsQ0FBYzNFLE1BQTVCLEVBQW9DdVEsU0FBcEM7QUFDRDs7QUFaK0Q7QUFlM0QsU0FBU2pOLGNBQVQsQ0FDTHNCLGNBREssRUFFVztBQUNoQixRQUFNRyxRQUFRLEdBQUdvTCxNQUFNLENBQUNFLE1BQVAsQ0FDZixJQUFJSixlQUFKLENBQW9CckwsY0FBcEIsQ0FEZSxFQUVmNEwsMERBRmUsQ0FBakI7QUFJQSxRQUFNQyxHQUFHLEdBQUc3TCxjQUFjLENBQUNWLFVBQTNCO0FBRUF3TSw2REFBQSxDQUFvQkMsQ0FBRCxJQUFPO0FBQ3hCLFVBQU1DLEVBQUUsR0FBR0gsR0FBRyxDQUFDRSxDQUFELENBQWQ7O0FBQ0EsUUFBSUMsRUFBSixFQUFRO0FBQ043TCxjQUFRLENBQUM0TCxDQUFELENBQVIsR0FBY0MsRUFBRSxDQUFDO0FBQUU3TDtBQUFGLE9BQUQsQ0FBaEI7QUFDRDtBQUNGLEdBTEQ7QUFPQSxTQUFPQSxRQUFQO0FBQ0Q7QUFFTSxTQUFTOEwsV0FBVCxDQUlMOUwsUUFKSyxFQUtMK0wsT0FMSyxFQVNXO0FBQ2hCLFFBQU03TCxHQUFHLEdBQUdGLFFBQVEsQ0FBQ3hCLFNBQVQsQ0FBbUJ1TixPQUFPLENBQUM5USxNQUEzQixDQUFaO0FBRUEsU0FBTyxTQUFTK1EsVUFBVCxDQUFvQmpSLEdBQXBCLEVBQXlCQyxHQUF6QixFQUE4QjtBQUFBOztBQUNuQyxXQUFPK1EsT0FBTyxDQUFDNVAsT0FBUixDQUFnQjtBQUNyQnBCLFNBRHFCO0FBRXJCQyxTQUZxQjtBQUdyQmdGLGNBSHFCO0FBSXJCL0UsWUFBTSxFQUFFaUYsR0FKYTtBQUtyQmxFLGNBQVEsRUFBRStQLE9BQU8sQ0FBQy9QLFFBTEc7QUFNckI2SixhQUFPLHNCQUFFa0csT0FBTyxDQUFDbEcsT0FBViwrREFBcUI7QUFOUCxLQUFoQixDQUFQO0FBUUQsR0FURDtBQVVEO0FBRU0sTUFBTTNKLGNBQWMsR0FDWTBKLFFBQXJDLElBQ0EsQ0FDRTVGLFFBREYsRUFFRStMLE9BRkYsS0FNcUI7QUFDbkIsU0FBT0QsV0FBVyxDQUFDOUwsUUFBRCxrQ0FBZ0I0RixRQUFoQixHQUE2Qm1HLE9BQTdCLEVBQWxCO0FBQ0QsQ0FWSSxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDL0hQLE1BQU1FLElBQUksR0FBRyxNQUFNO0FBQ2pCLFFBQU0sSUFBSWxPLEtBQUosQ0FBVSxpQkFBVixDQUFOO0FBQ0QsQ0FGRDs7QUFJTyxNQUFNNE4sVUFBVSxHQUFHLENBQ3hCLE9BRHdCLEVBRXhCLGFBRndCLEVBR3hCLFNBSHdCLEVBSXhCLGFBSndCLEVBS3hCLHFCQUx3QixFQU14QixvQkFOd0IsRUFPeEIsZ0JBUHdCLEVBUXhCLFlBUndCLENBQW5CO0FBV0EsTUFBTUYsaUJBQWlCLEdBQUdFLFVBQVUsQ0FBQzlJLE1BQVgsQ0FBa0IsQ0FBQzZJLEdBQUQsRUFBTUUsQ0FBTixLQUFZO0FBQzdERixLQUFHLENBQUNFLENBQUQsQ0FBSCxHQUFTSyxJQUFUO0FBQ0EsU0FBT1AsR0FBUDtBQUNELENBSGdDLEVBRzlCLEVBSDhCLENBQTFCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pCQSxNQUFNVCxnQkFBTixTQUErQmxOLEtBQS9CLENBQXFDO0FBSzFDZ0gsYUFBVyxDQUFDQyxHQUFELEVBQWNoSyxHQUFkLEVBQTZCSyxJQUE3QixFQUF5QztBQUNsRCxVQUFNMkosR0FBTjs7QUFEa0Q7O0FBQUE7O0FBQUE7O0FBRWxELFNBQUtDLElBQUwsR0FBWSxrQkFBWjtBQUNBLFNBQUt0SixNQUFMLEdBQWNYLEdBQUcsQ0FBQ1csTUFBbEI7QUFDQSxTQUFLWCxHQUFMLEdBQVdBLEdBQVg7QUFDQSxTQUFLSyxJQUFMLEdBQVlBLElBQVo7QUFDRDs7QUFYeUM7QUFjckMsTUFBTTZRLG9CQUFOLFNBQW1Dbk8sS0FBbkMsQ0FBeUM7QUFDOUNnSCxhQUFXLENBQUNDLEdBQUQsRUFBYztBQUN2QixVQUFNQSxHQUFOO0FBQ0EsU0FBS0MsSUFBTCxHQUFZLHNCQUFaO0FBQ0Q7O0FBSjZDLEM7Ozs7Ozs7Ozs7Ozs7OztBQ1pqQyxTQUFTa0gsZUFBVCxDQUNicFIsR0FEYSxFQUViQyxHQUZhLEVBR2JvUixjQUhhLEVBSWI7QUFDQSxRQUFNQyxPQUFPLEdBQUdELGNBQWMsQ0FBQ25HLFFBQWYsQ0FBd0IsU0FBeEIsSUFDWm1HLGNBRFksR0FFWixDQUFDLEdBQUdBLGNBQUosRUFBb0IsU0FBcEIsQ0FGSjs7QUFJQSxNQUFJLENBQUNyUixHQUFHLENBQUNzSyxNQUFMLElBQWUsQ0FBQ2dILE9BQU8sQ0FBQ3BHLFFBQVIsQ0FBaUJsTCxHQUFHLENBQUNzSyxNQUFyQixDQUFwQixFQUFrRDtBQUNoRHJLLE9BQUcsQ0FBQ1csTUFBSixDQUFXLEdBQVg7QUFDQVgsT0FBRyxDQUFDb0osU0FBSixDQUFjLE9BQWQsRUFBdUJpSSxPQUFPLENBQUNDLElBQVIsQ0FBYSxJQUFiLENBQXZCO0FBQ0F0UixPQUFHLENBQUN1UixHQUFKO0FBQ0EsV0FBTyxLQUFQO0FBQ0Q7O0FBRUQsTUFBSXhSLEdBQUcsQ0FBQ3NLLE1BQUosS0FBZSxTQUFuQixFQUE4QjtBQUM1QnJLLE9BQUcsQ0FBQ1csTUFBSixDQUFXLEdBQVg7QUFDQVgsT0FBRyxDQUFDb0osU0FBSixDQUFjLE9BQWQsRUFBdUJpSSxPQUFPLENBQUNDLElBQVIsQ0FBYSxJQUFiLENBQXZCO0FBQ0F0UixPQUFHLENBQUNvSixTQUFKLENBQWMsZ0JBQWQsRUFBZ0MsR0FBaEM7QUFDQXBKLE9BQUcsQ0FBQ3VSLEdBQUo7QUFDQSxXQUFPLEtBQVA7QUFDRDs7QUFFRCxTQUFPLElBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUJEO0FBR2UsU0FBU3pCLGtCQUFULENBQ2IvUCxHQURhLEVBRWJDLEdBRmEsRUFHYndSLGlCQUhhLEVBSWI7QUFDQSxRQUFNSCxPQUFPLEdBQUdqQixNQUFNLENBQUNxQixJQUFQLENBQVlELGlCQUFaLENBQWhCO0FBQ0EsUUFBTUosY0FBYyxHQUFHQyxPQUFPLENBQUN4SixNQUFSLENBQStCLENBQUM2SixHQUFELEVBQU1ySCxNQUFOLEtBQWlCO0FBQ3JFLFFBQUltSCxpQkFBaUIsQ0FBQ25ILE1BQUQsQ0FBckIsRUFBK0I7QUFDN0JxSCxTQUFHLENBQUNDLElBQUosQ0FBU3RILE1BQVQ7QUFDRDs7QUFDRCxXQUFPcUgsR0FBUDtBQUNELEdBTHNCLEVBS3BCLEVBTG9CLENBQXZCO0FBT0EsU0FBT1AsMkRBQWUsQ0FBQ3BSLEdBQUQsRUFBTUMsR0FBTixFQUFXb1IsY0FBWCxDQUF0QjtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTk0sTUFBTVEsYUFBTixTQUE0QjdPLEtBQTVCLENBQWtDO0FBSXZDZ0gsYUFBVyxDQUFDO0FBQUVqSixXQUFGO0FBQVdDLFFBQVg7QUFBaUJGO0FBQWpCLEdBQUQsRUFBd0M7QUFDakQsVUFBTWlLLEtBQWdCLEdBQUdoSyxPQUFPO0FBQzFCQTtBQUQwQixPQUNiQyxJQUFJLEdBQUc7QUFBRUE7QUFBRixLQUFILEdBQWMsRUFETCxJQUU1QkYsTUFBTSxDQUFFLENBQUYsQ0FGVjtBQUlBLFVBQU1pSyxLQUFLLENBQUNoSyxPQUFaOztBQUxpRDs7QUFBQTs7QUFNakQsU0FBS0QsTUFBTCxHQUFjQyxPQUFPLEdBQUcsQ0FBQ2dLLEtBQUQsQ0FBSCxHQUFhakssTUFBbEM7QUFFQSxRQUFJaUssS0FBSyxDQUFDL0osSUFBVixFQUFnQixLQUFLQSxJQUFMLEdBQVkrSixLQUFLLENBQUMvSixJQUFsQjtBQUNqQjs7QUFic0MsQyxDQWdCekM7O0FBQ08sTUFBTThRLGVBQU4sU0FBOEJELGFBQTlCLENBQTRDO0FBQ2pEN0gsYUFBVyxDQUFDYyxPQUFELEVBQXNCO0FBQy9CLFVBQU1BLE9BQU47QUFDQSxTQUFLOUosSUFBTCxHQUFZLGtCQUFaO0FBQ0Q7O0FBSmdEO0FBTzVDLE1BQU0ySixZQUFOLFNBQTJCa0gsYUFBM0IsQ0FBeUM7QUFHOUM3SCxhQUFXLENBQ1RjLE9BRFMsRUFJVDtBQUNBLFVBQU1BLE9BQU47O0FBREE7O0FBRUEsU0FBS2xLLE1BQUwsR0FBY2tLLE9BQU8sQ0FBQ2xLLE1BQXRCO0FBQ0Q7O0FBVjZDLEM7Ozs7Ozs7Ozs7Ozs7QUNwQ2hEO0FBRUEsK0RBQWU0Qyw4REFBYyxFQUE3QixFOzs7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFFQSwrREFBZXRDLDBFQUFXLENBQUMrRCxzREFBRCxDQUExQixFOzs7Ozs7Ozs7OztBQ0hBLDJDOzs7Ozs7Ozs7OztBQ0FBLGlEIiwiZmlsZSI6InBhZ2VzL2FwaS9jdXN0b21lci5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgR2V0TG9nZ2VkSW5DdXN0b21lclF1ZXJ5IH0gZnJvbSAnLi4vLi4vLi4vc2NoZW1hJ1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyRW5kcG9pbnQgfSBmcm9tICcuJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldExvZ2dlZEluQ3VzdG9tZXJRdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldExvZ2dlZEluQ3VzdG9tZXIge1xyXG4gICAgY3VzdG9tZXIge1xyXG4gICAgICBlbnRpdHlJZFxyXG4gICAgICBmaXJzdE5hbWVcclxuICAgICAgbGFzdE5hbWVcclxuICAgICAgZW1haWxcclxuICAgICAgY29tcGFueVxyXG4gICAgICBjdXN0b21lckdyb3VwSWRcclxuICAgICAgbm90ZXNcclxuICAgICAgcGhvbmVcclxuICAgICAgYWRkcmVzc0NvdW50XHJcbiAgICAgIGF0dHJpYnV0ZUNvdW50XHJcbiAgICAgIHN0b3JlQ3JlZGl0IHtcclxuICAgICAgICB2YWx1ZVxyXG4gICAgICAgIGN1cnJlbmN5Q29kZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5gXHJcblxyXG5leHBvcnQgdHlwZSBDdXN0b21lciA9IE5vbk51bGxhYmxlPEdldExvZ2dlZEluQ3VzdG9tZXJRdWVyeVsnY3VzdG9tZXInXT5cclxuXHJcbmNvbnN0IGdldExvZ2dlZEluQ3VzdG9tZXI6IEN1c3RvbWVyRW5kcG9pbnRbJ2hhbmRsZXJzJ11bJ2dldExvZ2dlZEluQ3VzdG9tZXInXSA9IGFzeW5jICh7XHJcbiAgcmVxLFxyXG4gIHJlcyxcclxuICBjb25maWcsXHJcbn0pID0+IHtcclxuICBjb25zdCB0b2tlbiA9IHJlcS5jb29raWVzW2NvbmZpZy5jdXN0b21lckNvb2tpZV1cclxuXHJcbiAgaWYgKHRva2VuKSB7XHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGNvbmZpZy5mZXRjaDxHZXRMb2dnZWRJbkN1c3RvbWVyUXVlcnk+KFxyXG4gICAgICBnZXRMb2dnZWRJbkN1c3RvbWVyUXVlcnksXHJcbiAgICAgIHVuZGVmaW5lZCxcclxuICAgICAge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIGNvb2tpZTogYCR7Y29uZmlnLmN1c3RvbWVyQ29va2llfT0ke3Rva2VufWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgY29uc3QgeyBjdXN0b21lciB9ID0gZGF0YVxyXG5cclxuICAgIGlmICghY3VzdG9tZXIpIHtcclxuICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcclxuICAgICAgICBkYXRhOiBudWxsLFxyXG4gICAgICAgIGVycm9yczogW3sgbWVzc2FnZTogJ0N1c3RvbWVyIG5vdCBmb3VuZCcsIGNvZGU6ICdub3RfZm91bmQnIH1dLFxyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7IGRhdGE6IHsgY3VzdG9tZXIgfSB9KVxyXG4gIH1cclxuXHJcbiAgcmVzLnN0YXR1cygyMDApLmpzb24oeyBkYXRhOiBudWxsIH0pXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGdldExvZ2dlZEluQ3VzdG9tZXJcclxuIiwiaW1wb3J0IHsgR2V0QVBJU2NoZW1hLCBjcmVhdGVFbmRwb2ludCB9IGZyb20gJ0Bjb21tZXJjZS9hcGknXHJcbmltcG9ydCBjdXN0b21lckVuZHBvaW50IGZyb20gJ0Bjb21tZXJjZS9hcGkvZW5kcG9pbnRzL2N1c3RvbWVyJ1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyU2NoZW1hIH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvY3VzdG9tZXInXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VBUEkgfSBmcm9tICcuLi8uLidcclxuaW1wb3J0IGdldExvZ2dlZEluQ3VzdG9tZXIgZnJvbSAnLi9nZXQtbG9nZ2VkLWluLWN1c3RvbWVyJ1xyXG5cclxuZXhwb3J0IHR5cGUgQ3VzdG9tZXJBUEkgPSBHZXRBUElTY2hlbWE8QmlnY29tbWVyY2VBUEksIEN1c3RvbWVyU2NoZW1hPlxyXG5cclxuZXhwb3J0IHR5cGUgQ3VzdG9tZXJFbmRwb2ludCA9IEN1c3RvbWVyQVBJWydlbmRwb2ludCddXHJcblxyXG5leHBvcnQgY29uc3QgaGFuZGxlcnM6IEN1c3RvbWVyRW5kcG9pbnRbJ2hhbmRsZXJzJ10gPSB7IGdldExvZ2dlZEluQ3VzdG9tZXIgfVxyXG5cclxuY29uc3QgY3VzdG9tZXJBcGkgPSBjcmVhdGVFbmRwb2ludDxDdXN0b21lckFQST4oe1xyXG4gIGhhbmRsZXI6IGN1c3RvbWVyRW5kcG9pbnQsXHJcbiAgaGFuZGxlcnMsXHJcbn0pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjdXN0b21lckFwaVxyXG4iLCJleHBvcnQgY29uc3QgY2F0ZWdvcnlUcmVlSXRlbUZyYWdtZW50ID0gLyogR3JhcGhRTCAqLyBgXHJcbiAgZnJhZ21lbnQgY2F0ZWdvcnlUcmVlSXRlbSBvbiBDYXRlZ29yeVRyZWVJdGVtIHtcclxuICAgIGVudGl0eUlkXHJcbiAgICBuYW1lXHJcbiAgICBwYXRoXHJcbiAgICBkZXNjcmlwdGlvblxyXG4gICAgcHJvZHVjdENvdW50XHJcbiAgfVxyXG5gXHJcbiIsImV4cG9ydCBjb25zdCBwcm9kdWN0UHJpY2VzID0gLyogR3JhcGhRTCAqLyBgXHJcbiAgZnJhZ21lbnQgcHJvZHVjdFByaWNlcyBvbiBQcmljZXMge1xyXG4gICAgcHJpY2Uge1xyXG4gICAgICB2YWx1ZVxyXG4gICAgICBjdXJyZW5jeUNvZGVcclxuICAgIH1cclxuICAgIHNhbGVQcmljZSB7XHJcbiAgICAgIHZhbHVlXHJcbiAgICAgIGN1cnJlbmN5Q29kZVxyXG4gICAgfVxyXG4gICAgcmV0YWlsUHJpY2Uge1xyXG4gICAgICB2YWx1ZVxyXG4gICAgICBjdXJyZW5jeUNvZGVcclxuICAgIH1cclxuICB9XHJcbmBcclxuXHJcbmV4cG9ydCBjb25zdCBzd2F0Y2hPcHRpb25GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHN3YXRjaE9wdGlvbiBvbiBTd2F0Y2hPcHRpb25WYWx1ZSB7XHJcbiAgICBpc0RlZmF1bHRcclxuICAgIGhleENvbG9yc1xyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IG11bHRpcGxlQ2hvaWNlT3B0aW9uRnJhZ21lbnQgPSAvKiBHcmFwaFFMICovIGBcclxuICBmcmFnbWVudCBtdWx0aXBsZUNob2ljZU9wdGlvbiBvbiBNdWx0aXBsZUNob2ljZU9wdGlvbiB7XHJcbiAgICB2YWx1ZXMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBsYWJlbFxyXG4gICAgICAgICAgLi4uc3dhdGNoT3B0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3N3YXRjaE9wdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdEluZm9GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHByb2R1Y3RJbmZvIG9uIFByb2R1Y3Qge1xyXG4gICAgZW50aXR5SWRcclxuICAgIG5hbWVcclxuICAgIHBhdGhcclxuICAgIGJyYW5kIHtcclxuICAgICAgZW50aXR5SWRcclxuICAgIH1cclxuICAgIGRlc2NyaXB0aW9uXHJcbiAgICBwcmljZXMge1xyXG4gICAgICAuLi5wcm9kdWN0UHJpY2VzXHJcbiAgICB9XHJcbiAgICBpbWFnZXMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgYWx0VGV4dFxyXG4gICAgICAgICAgaXNEZWZhdWx0XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB2YXJpYW50cyB7XHJcbiAgICAgIGVkZ2VzIHtcclxuICAgICAgICBub2RlIHtcclxuICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICBkZWZhdWx0SW1hZ2Uge1xyXG4gICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICBhbHRUZXh0XHJcbiAgICAgICAgICAgIGlzRGVmYXVsdFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcHJvZHVjdE9wdGlvbnMge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICBlbnRpdHlJZFxyXG4gICAgICAgICAgZGlzcGxheU5hbWVcclxuICAgICAgICAgIC4uLm11bHRpcGxlQ2hvaWNlT3B0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBsb2NhbGVNZXRhOiBtZXRhZmllbGRzKG5hbWVzcGFjZTogJGxvY2FsZSwga2V5czogW1wibmFtZVwiLCBcImRlc2NyaXB0aW9uXCJdKVxyXG4gICAgICBAaW5jbHVkZShpZjogJGhhc0xvY2FsZSkge1xyXG4gICAgICBlZGdlcyB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBrZXlcclxuICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3Byb2R1Y3RQcmljZXN9XHJcbiAgJHttdWx0aXBsZUNob2ljZU9wdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdENvbm5lY3Rpb25GcmFnbWVudCA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIGZyYWdtZW50IHByb2R1Y3RDb25ubmVjdGlvbiBvbiBQcm9kdWN0Q29ubmVjdGlvbiB7XHJcbiAgICBwYWdlSW5mbyB7XHJcbiAgICAgIHN0YXJ0Q3Vyc29yXHJcbiAgICAgIGVuZEN1cnNvclxyXG4gICAgfVxyXG4gICAgZWRnZXMge1xyXG4gICAgICBjdXJzb3JcclxuICAgICAgbm9kZSB7XHJcbiAgICAgICAgLi4ucHJvZHVjdEluZm9cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJHtwcm9kdWN0SW5mb0ZyYWdtZW50fVxyXG5gXHJcbiIsImltcG9ydCB0eXBlIHsgUmVxdWVzdEluaXQgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5pbXBvcnQge1xyXG4gIENvbW1lcmNlQVBJLFxyXG4gIENvbW1lcmNlQVBJQ29uZmlnLFxyXG4gIGdldENvbW1lcmNlQXBpIGFzIGNvbW1lcmNlQXBpLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGknXHJcbmltcG9ydCBjcmVhdGVGZXRjaEdyYXBocWxBcGkgZnJvbSAnLi91dGlscy9mZXRjaC1ncmFwaHFsLWFwaSdcclxuaW1wb3J0IGNyZWF0ZUZldGNoU3RvcmVBcGkgZnJvbSAnLi91dGlscy9mZXRjaC1zdG9yZS1hcGknXHJcblxyXG5pbXBvcnQgdHlwZSB7IENhcnRBUEkgfSBmcm9tICcuL2VuZHBvaW50cy9jYXJ0J1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvY3VzdG9tZXInXHJcbmltcG9ydCB0eXBlIHsgTG9naW5BUEkgfSBmcm9tICcuL2VuZHBvaW50cy9sb2dpbidcclxuaW1wb3J0IHR5cGUgeyBMb2dvdXRBUEkgfSBmcm9tICcuL2VuZHBvaW50cy9sb2dvdXQnXHJcbmltcG9ydCB0eXBlIHsgU2lnbnVwQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvc2lnbnVwJ1xyXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3RzQVBJIH0gZnJvbSAnLi9lbmRwb2ludHMvY2F0YWxvZy9wcm9kdWN0cydcclxuaW1wb3J0IHR5cGUgeyBXaXNobGlzdEFQSSB9IGZyb20gJy4vZW5kcG9pbnRzL3dpc2hsaXN0J1xyXG5cclxuaW1wb3J0IGxvZ2luIGZyb20gJy4vb3BlcmF0aW9ucy9sb2dpbidcclxuaW1wb3J0IGdldEFsbFBhZ2VzIGZyb20gJy4vb3BlcmF0aW9ucy9nZXQtYWxsLXBhZ2VzJ1xyXG5pbXBvcnQgZ2V0UGFnZSBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LXBhZ2UnXHJcbmltcG9ydCBnZXRTaXRlSW5mbyBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LXNpdGUtaW5mbydcclxuaW1wb3J0IGdldEN1c3RvbWVyV2lzaGxpc3QgZnJvbSAnLi9vcGVyYXRpb25zL2dldC1jdXN0b21lci13aXNobGlzdCdcclxuaW1wb3J0IGdldEFsbFByb2R1Y3RQYXRocyBmcm9tICcuL29wZXJhdGlvbnMvZ2V0LWFsbC1wcm9kdWN0LXBhdGhzJ1xyXG5pbXBvcnQgZ2V0QWxsUHJvZHVjdHMgZnJvbSAnLi9vcGVyYXRpb25zL2dldC1hbGwtcHJvZHVjdHMnXHJcbmltcG9ydCBnZXRQcm9kdWN0IGZyb20gJy4vb3BlcmF0aW9ucy9nZXQtcHJvZHVjdCdcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQmlnY29tbWVyY2VDb25maWcgZXh0ZW5kcyBDb21tZXJjZUFQSUNvbmZpZyB7XHJcbiAgLy8gSW5kaWNhdGVzIGlmIHRoZSByZXR1cm5lZCBtZXRhZGF0YSB3aXRoIHRyYW5zbGF0aW9ucyBzaG91bGQgYmUgYXBwbGllZCB0byB0aGVcclxuICAvLyBkYXRhIG9yIHJldHVybmVkIGFzIGl0IGlzXHJcbiAgYXBwbHlMb2NhbGU/OiBib29sZWFuXHJcbiAgc3RvcmVBcGlVcmw6IHN0cmluZ1xyXG4gIHN0b3JlQXBpVG9rZW46IHN0cmluZ1xyXG4gIHN0b3JlQXBpQ2xpZW50SWQ6IHN0cmluZ1xyXG4gIHN0b3JlQ2hhbm5lbElkPzogc3RyaW5nXHJcbiAgc3RvcmVVcmw/OiBzdHJpbmdcclxuICBzdG9yZUFwaUNsaWVudFNlY3JldD86IHN0cmluZ1xyXG4gIHN0b3JlSGFzaD86c3RyaW5nXHJcbiAgc3RvcmVBcGlGZXRjaDxUPihlbmRwb2ludDogc3RyaW5nLCBvcHRpb25zPzogUmVxdWVzdEluaXQpOiBQcm9taXNlPFQ+XHJcbn1cclxuXHJcbmNvbnN0IEFQSV9VUkwgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9TVE9SRUZST05UX0FQSV9VUkxcclxuY29uc3QgQVBJX1RPS0VOID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVE9LRU5cclxuY29uc3QgU1RPUkVfQVBJX1VSTCA9IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX1NUT1JFX0FQSV9VUkxcclxuY29uc3QgU1RPUkVfQVBJX1RPS0VOID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOXHJcbmNvbnN0IFNUT1JFX0FQSV9DTElFTlRfSUQgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX0lEXHJcbmNvbnN0IFNUT1JFX0NIQU5ORUxfSUQgPSBwcm9jZXNzLmVudi5CSUdDT01NRVJDRV9DSEFOTkVMX0lEXHJcbmNvbnN0IFNUT1JFX1VSTCA9IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX1NUT1JFX1VSTFxyXG5jb25zdCBDTElFTlRfU0VDUkVUID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX0NMSUVOVF9TRUNSRVRcclxuY29uc3QgU1RPUkVGUk9OVF9IQVNIID0gcHJvY2Vzcy5lbnYuQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1NUT1JFX0hBU0hcclxuXHJcbmlmICghQVBJX1VSTCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIGBUaGUgZW52aXJvbm1lbnQgdmFyaWFibGUgQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVVJMIGlzIG1pc3NpbmcgYW5kIGl0J3MgcmVxdWlyZWQgdG8gYWNjZXNzIHlvdXIgc3RvcmVgXHJcbiAgKVxyXG59XHJcblxyXG5pZiAoIUFQSV9UT0tFTikge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIGBUaGUgZW52aXJvbm1lbnQgdmFyaWFibGUgQklHQ09NTUVSQ0VfU1RPUkVGUk9OVF9BUElfVE9LRU4gaXMgbWlzc2luZyBhbmQgaXQncyByZXF1aXJlZCB0byBhY2Nlc3MgeW91ciBzdG9yZWBcclxuICApXHJcbn1cclxuXHJcbmlmICghKFNUT1JFX0FQSV9VUkwgJiYgU1RPUkVfQVBJX1RPS0VOICYmIFNUT1JFX0FQSV9DTElFTlRfSUQpKSB7XHJcbiAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgYFRoZSBlbnZpcm9ubWVudCB2YXJpYWJsZXMgQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1VSTCwgQklHQ09NTUVSQ0VfU1RPUkVfQVBJX1RPS0VOLCBCSUdDT01NRVJDRV9TVE9SRV9BUElfQ0xJRU5UX0lEIGhhdmUgdG8gYmUgc2V0IGluIG9yZGVyIHRvIGFjY2VzcyB0aGUgUkVTVCBBUEkgb2YgeW91ciBzdG9yZWBcclxuICApXHJcbn1cclxuXHJcbmNvbnN0IE9ORV9EQVkgPSA2MCAqIDYwICogMjRcclxuXHJcbmNvbnN0IGNvbmZpZzogQmlnY29tbWVyY2VDb25maWcgPSB7XHJcbiAgY29tbWVyY2VVcmw6IEFQSV9VUkwsXHJcbiAgYXBpVG9rZW46IEFQSV9UT0tFTixcclxuICBjdXN0b21lckNvb2tpZTogJ1NIT1BfVE9LRU4nLFxyXG4gIGNhcnRDb29raWU6IHByb2Nlc3MuZW52LkJJR0NPTU1FUkNFX0NBUlRfQ09PS0lFID8/ICdiY19jYXJ0SWQnLFxyXG4gIGNhcnRDb29raWVNYXhBZ2U6IE9ORV9EQVkgKiAzMCxcclxuICBmZXRjaDogY3JlYXRlRmV0Y2hHcmFwaHFsQXBpKCgpID0+IGdldENvbW1lcmNlQXBpKCkuZ2V0Q29uZmlnKCkpLFxyXG4gIGFwcGx5TG9jYWxlOiB0cnVlLFxyXG4gIC8vIFJFU1QgQVBJIG9ubHlcclxuICBzdG9yZUFwaVVybDogU1RPUkVfQVBJX1VSTCxcclxuICBzdG9yZUFwaVRva2VuOiBTVE9SRV9BUElfVE9LRU4sXHJcbiAgc3RvcmVBcGlDbGllbnRJZDogU1RPUkVfQVBJX0NMSUVOVF9JRCxcclxuICBzdG9yZUNoYW5uZWxJZDogU1RPUkVfQ0hBTk5FTF9JRCxcclxuICBzdG9yZVVybDpTVE9SRV9VUkwsXHJcbiAgc3RvcmVBcGlDbGllbnRTZWNyZXQ6Q0xJRU5UX1NFQ1JFVCxcclxuICBzdG9yZUhhc2g6IFNUT1JFRlJPTlRfSEFTSCxcclxuICBzdG9yZUFwaUZldGNoOiBjcmVhdGVGZXRjaFN0b3JlQXBpKCgpID0+IGdldENvbW1lcmNlQXBpKCkuZ2V0Q29uZmlnKCkpLFxyXG59XHJcblxyXG5jb25zdCBvcGVyYXRpb25zID0ge1xyXG4gIGxvZ2luLFxyXG4gIGdldEFsbFBhZ2VzLFxyXG4gIGdldFBhZ2UsXHJcbiAgZ2V0U2l0ZUluZm8sXHJcbiAgZ2V0Q3VzdG9tZXJXaXNobGlzdCxcclxuICBnZXRBbGxQcm9kdWN0UGF0aHMsXHJcbiAgZ2V0QWxsUHJvZHVjdHMsXHJcbiAgZ2V0UHJvZHVjdCxcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHByb3ZpZGVyID0geyBjb25maWcsIG9wZXJhdGlvbnMgfVxyXG5cclxuZXhwb3J0IHR5cGUgUHJvdmlkZXIgPSB0eXBlb2YgcHJvdmlkZXJcclxuXHJcbmV4cG9ydCB0eXBlIEFQSXMgPVxyXG4gIHwgQ2FydEFQSVxyXG4gIHwgQ3VzdG9tZXJBUElcclxuICB8IExvZ2luQVBJXHJcbiAgfCBMb2dvdXRBUElcclxuICB8IFNpZ251cEFQSVxyXG4gIHwgUHJvZHVjdHNBUElcclxuICB8IFdpc2hsaXN0QVBJXHJcblxyXG5leHBvcnQgdHlwZSBCaWdjb21tZXJjZUFQSTxQIGV4dGVuZHMgUHJvdmlkZXIgPSBQcm92aWRlcj4gPSBDb21tZXJjZUFQSTxQPlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbW1lcmNlQXBpPFAgZXh0ZW5kcyBQcm92aWRlcj4oXHJcbiAgY3VzdG9tUHJvdmlkZXI6IFAgPSBwcm92aWRlciBhcyBhbnlcclxuKTogQmlnY29tbWVyY2VBUEk8UD4ge1xyXG4gIHJldHVybiBjb21tZXJjZUFwaShjdXN0b21Qcm92aWRlcilcclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7XHJcbiAgT3BlcmF0aW9uQ29udGV4dCxcclxuICBPcGVyYXRpb25PcHRpb25zLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGkvb3BlcmF0aW9ucydcclxuaW1wb3J0IHR5cGUgeyBQYWdlLCBHZXRBbGxQYWdlc09wZXJhdGlvbiB9IGZyb20gJy4uLy4uL3R5cGVzL3BhZ2UnXHJcbmltcG9ydCB0eXBlIHsgUmVjdXJzaXZlUGFydGlhbCwgUmVjdXJzaXZlUmVxdWlyZWQgfSBmcm9tICcuLi91dGlscy90eXBlcydcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZXRBbGxQYWdlc09wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUGFnZXM8VCBleHRlbmRzIEdldEFsbFBhZ2VzT3BlcmF0aW9uPihvcHRzPzoge1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQYWdlczxUIGV4dGVuZHMgR2V0QWxsUGFnZXNPcGVyYXRpb24+KFxyXG4gICAgb3B0czoge1xyXG4gICAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0QWxsUGFnZXM8VCBleHRlbmRzIEdldEFsbFBhZ2VzT3BlcmF0aW9uPih7XHJcbiAgICBjb25maWcsXHJcbiAgICBwcmV2aWV3LFxyXG4gIH06IHtcclxuICAgIHVybD86IHN0cmluZ1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbnN0IGNmZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGB1cmxgXHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGNmZy5zdG9yZUFwaUZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPHsgZGF0YTogUGFnZVtdIH0+XHJcbiAgICA+KCcvdjMvY29udGVudC9wYWdlcycpXHJcbiAgICBjb25zdCBwYWdlcyA9IChkYXRhIGFzIFJlY3Vyc2l2ZVJlcXVpcmVkPHR5cGVvZiBkYXRhPikgPz8gW11cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBwYWdlczogcHJldmlldyA/IHBhZ2VzIDogcGFnZXMuZmlsdGVyKChwKSA9PiBwLmlzX3Zpc2libGUpLFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGdldEFsbFBhZ2VzXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHsgR2V0QWxsUHJvZHVjdFBhdGhzUXVlcnkgfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCB0eXBlIHsgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uIH0gZnJvbSAnLi4vLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgZmlsdGVyRWRnZXMgZnJvbSAnLi4vdXRpbHMvZmlsdGVyLWVkZ2VzJ1xyXG5pbXBvcnQgeyBCaWdjb21tZXJjZUNvbmZpZywgUHJvdmlkZXIgfSBmcm9tICcuLidcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRBbGxQcm9kdWN0UGF0aHNRdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldEFsbFByb2R1Y3RQYXRocygkZmlyc3Q6IEludCA9IDEwMCkge1xyXG4gICAgc2l0ZSB7XHJcbiAgICAgIHByb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIHtcclxuICAgICAgICBlZGdlcyB7XHJcbiAgICAgICAgICBub2RlIHtcclxuICAgICAgICAgICAgcGF0aFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8XHJcbiAgICBUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uXHJcbiAgPihvcHRzPzoge1xyXG4gICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0UGF0aHM8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbj4oe1xyXG4gICAgcXVlcnkgPSBnZXRBbGxQcm9kdWN0UGF0aHNRdWVyeSxcclxuICAgIHZhcmlhYmxlcyxcclxuICAgIGNvbmZpZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IEJpZ2NvbW1lcmNlQ29uZmlnXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbmZpZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGBxdWVyeWBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPEdldEFsbFByb2R1Y3RQYXRoc1F1ZXJ5PlxyXG4gICAgPihxdWVyeSwgeyB2YXJpYWJsZXMgfSlcclxuICAgIGNvbnN0IHByb2R1Y3RzID0gZGF0YS5zaXRlPy5wcm9kdWN0cz8uZWRnZXNcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBwcm9kdWN0czogZmlsdGVyRWRnZXMocHJvZHVjdHMgYXMgUmVjdXJzaXZlUmVxdWlyZWQ8dHlwZW9mIHByb2R1Y3RzPikubWFwKFxyXG4gICAgICAgICh7IG5vZGUgfSkgPT4gbm9kZVxyXG4gICAgICApLFxyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gZ2V0QWxsUHJvZHVjdFBhdGhzXHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHtcclxuICBHZXRBbGxQcm9kdWN0c1F1ZXJ5LFxyXG4gIEdldEFsbFByb2R1Y3RzUXVlcnlWYXJpYWJsZXMsXHJcbn0gZnJvbSAnLi4vLi4vc2NoZW1hJ1xyXG5pbXBvcnQgdHlwZSB7IEdldEFsbFByb2R1Y3RzT3BlcmF0aW9uIH0gZnJvbSAnLi4vLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgZmlsdGVyRWRnZXMgZnJvbSAnLi4vdXRpbHMvZmlsdGVyLWVkZ2VzJ1xyXG5pbXBvcnQgc2V0UHJvZHVjdExvY2FsZU1ldGEgZnJvbSAnLi4vdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEnXHJcbmltcG9ydCB7IHByb2R1Y3RDb25uZWN0aW9uRnJhZ21lbnQgfSBmcm9tICcuLi9mcmFnbWVudHMvcHJvZHVjdCdcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVByb2R1Y3QgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldEFsbFByb2R1Y3RzUXVlcnkgPSAvKiBHcmFwaFFMICovIGBcclxuICBxdWVyeSBnZXRBbGxQcm9kdWN0cyhcclxuICAgICRoYXNMb2NhbGU6IEJvb2xlYW4gPSBmYWxzZVxyXG4gICAgJGxvY2FsZTogU3RyaW5nID0gXCJudWxsXCJcclxuICAgICRlbnRpdHlJZHM6IFtJbnQhXVxyXG4gICAgJGZpcnN0OiBJbnQgPSAxMFxyXG4gICAgJHByb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRmZWF0dXJlZFByb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRiZXN0U2VsbGluZ1Byb2R1Y3RzOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRuZXdlc3RQcm9kdWN0czogQm9vbGVhbiA9IGZhbHNlXHJcbiAgKSB7XHJcbiAgICBzaXRlIHtcclxuICAgICAgcHJvZHVjdHMoZmlyc3Q6ICRmaXJzdCwgZW50aXR5SWRzOiAkZW50aXR5SWRzKSBAaW5jbHVkZShpZjogJHByb2R1Y3RzKSB7XHJcbiAgICAgICAgLi4ucHJvZHVjdENvbm5uZWN0aW9uXHJcbiAgICAgIH1cclxuICAgICAgZmVhdHVyZWRQcm9kdWN0cyhmaXJzdDogJGZpcnN0KSBAaW5jbHVkZShpZjogJGZlYXR1cmVkUHJvZHVjdHMpIHtcclxuICAgICAgICAuLi5wcm9kdWN0Q29ubm5lY3Rpb25cclxuICAgICAgfVxyXG4gICAgICBiZXN0U2VsbGluZ1Byb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIEBpbmNsdWRlKGlmOiAkYmVzdFNlbGxpbmdQcm9kdWN0cykge1xyXG4gICAgICAgIC4uLnByb2R1Y3RDb25ubmVjdGlvblxyXG4gICAgICB9XHJcbiAgICAgIG5ld2VzdFByb2R1Y3RzKGZpcnN0OiAkZmlyc3QpIEBpbmNsdWRlKGlmOiAkbmV3ZXN0UHJvZHVjdHMpIHtcclxuICAgICAgICAuLi5wcm9kdWN0Q29ubm5lY3Rpb25cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJHtwcm9kdWN0Q29ubmVjdGlvbkZyYWdtZW50fVxyXG5gXHJcblxyXG5leHBvcnQgdHlwZSBQcm9kdWN0RWRnZSA9IE5vbk51bGxhYmxlPFxyXG4gIE5vbk51bGxhYmxlPEdldEFsbFByb2R1Y3RzUXVlcnlbJ3NpdGUnXVsncHJvZHVjdHMnXVsnZWRnZXMnXT5bMF1cclxuPlxyXG5cclxuZXhwb3J0IHR5cGUgUHJvZHVjdE5vZGUgPSBQcm9kdWN0RWRnZVsnbm9kZSddXHJcblxyXG5leHBvcnQgdHlwZSBHZXRBbGxQcm9kdWN0c1Jlc3VsdDxcclxuICBUIGV4dGVuZHMgUmVjb3JkPGtleW9mIEdldEFsbFByb2R1Y3RzUmVzdWx0LCBhbnlbXT4gPSB7XHJcbiAgICBwcm9kdWN0czogUHJvZHVjdEVkZ2VbXVxyXG4gIH1cclxuPiA9IFRcclxuXHJcbmZ1bmN0aW9uIGdldFByb2R1Y3RzVHlwZShcclxuICByZWxldmFuY2U/OiBHZXRBbGxQcm9kdWN0c09wZXJhdGlvblsndmFyaWFibGVzJ11bJ3JlbGV2YW5jZSddXHJcbikge1xyXG4gIHN3aXRjaCAocmVsZXZhbmNlKSB7XHJcbiAgICBjYXNlICdmZWF0dXJlZCc6XHJcbiAgICAgIHJldHVybiAnZmVhdHVyZWRQcm9kdWN0cydcclxuICAgIGNhc2UgJ2Jlc3Rfc2VsbGluZyc6XHJcbiAgICAgIHJldHVybiAnYmVzdFNlbGxpbmdQcm9kdWN0cydcclxuICAgIGNhc2UgJ25ld2VzdCc6XHJcbiAgICAgIHJldHVybiAnbmV3ZXN0UHJvZHVjdHMnXHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gJ3Byb2R1Y3RzJ1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdHNPcGVyYXRpb24oe1xyXG4gIGNvbW1lcmNlLFxyXG59OiBPcGVyYXRpb25Db250ZXh0PFByb3ZpZGVyPikge1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFByb2R1Y3RzPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbj4ob3B0cz86IHtcclxuICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFByb2R1Y3RzPFQgZXh0ZW5kcyBHZXRBbGxQcm9kdWN0c09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRBbGxQcm9kdWN0czxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdHNPcGVyYXRpb24+KHtcclxuICAgIHF1ZXJ5ID0gZ2V0QWxsUHJvZHVjdHNRdWVyeSxcclxuICAgIHZhcmlhYmxlczogdmFycyA9IHt9LFxyXG4gICAgY29uZmlnOiBjZmcsXHJcbiAgfToge1xyXG4gICAgcXVlcnk/OiBzdHJpbmdcclxuICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9ID0ge30pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uc3QgY29uZmlnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNmZylcclxuICAgIGNvbnN0IHsgbG9jYWxlIH0gPSBjb25maWdcclxuICAgIGNvbnN0IGZpZWxkID0gZ2V0UHJvZHVjdHNUeXBlKHZhcnMucmVsZXZhbmNlKVxyXG4gICAgY29uc3QgdmFyaWFibGVzOiBHZXRBbGxQcm9kdWN0c1F1ZXJ5VmFyaWFibGVzID0ge1xyXG4gICAgICBsb2NhbGUsXHJcbiAgICAgIGhhc0xvY2FsZTogISFsb2NhbGUsXHJcbiAgICB9XHJcblxyXG4gICAgdmFyaWFibGVzW2ZpZWxkXSA9IHRydWVcclxuXHJcbiAgICBpZiAodmFycy5maXJzdCkgdmFyaWFibGVzLmZpcnN0ID0gdmFycy5maXJzdFxyXG4gICAgaWYgKHZhcnMuaWRzKSB2YXJpYWJsZXMuZW50aXR5SWRzID0gdmFycy5pZHMubWFwKChpZCkgPT4gTnVtYmVyKGlkKSlcclxuXHJcbiAgICAvLyBSZWN1cnNpdmVQYXJ0aWFsIGZvcmNlcyB0aGUgbWV0aG9kIHRvIGNoZWNrIGZvciBldmVyeSBwcm9wIGluIHRoZSBkYXRhLCB3aGljaCBpc1xyXG4gICAgLy8gcmVxdWlyZWQgaW4gY2FzZSB0aGVyZSdzIGEgY3VzdG9tIGBxdWVyeWBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFJlY3Vyc2l2ZVBhcnRpYWw8R2V0QWxsUHJvZHVjdHNRdWVyeT4+KFxyXG4gICAgICBxdWVyeSxcclxuICAgICAgeyB2YXJpYWJsZXMgfVxyXG4gICAgKVxyXG4gICAgY29uc3QgZWRnZXMgPSBkYXRhLnNpdGU/LltmaWVsZF0/LmVkZ2VzXHJcbiAgICBjb25zdCBwcm9kdWN0cyA9IGZpbHRlckVkZ2VzKGVkZ2VzIGFzIFJlY3Vyc2l2ZVJlcXVpcmVkPHR5cGVvZiBlZGdlcz4pXHJcblxyXG4gICAgaWYgKGxvY2FsZSAmJiBjb25maWcuYXBwbHlMb2NhbGUpIHtcclxuICAgICAgcHJvZHVjdHMuZm9yRWFjaCgocHJvZHVjdDogUmVjdXJzaXZlUGFydGlhbDxQcm9kdWN0RWRnZT4pID0+IHtcclxuICAgICAgICBpZiAocHJvZHVjdC5ub2RlKSBzZXRQcm9kdWN0TG9jYWxlTWV0YShwcm9kdWN0Lm5vZGUpXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcHJvZHVjdHM6IHByb2R1Y3RzLm1hcCgoeyBub2RlIH0pID0+IG5vcm1hbGl6ZVByb2R1Y3Qobm9kZSBhcyBhbnkpKSxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiBnZXRBbGxQcm9kdWN0c1xyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbixcclxuICBXaXNobGlzdCxcclxufSBmcm9tICcuLi8uLi90eXBlcy93aXNobGlzdCdcclxuaW1wb3J0IHR5cGUgeyBSZWN1cnNpdmVQYXJ0aWFsLCBSZWN1cnNpdmVSZXF1aXJlZCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgeyBCaWdjb21tZXJjZUNvbmZpZywgUHJvdmlkZXIgfSBmcm9tICcuLidcclxuaW1wb3J0IGdldEFsbFByb2R1Y3RzLCB7IFByb2R1Y3RFZGdlIH0gZnJvbSAnLi9nZXQtYWxsLXByb2R1Y3RzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxcclxuICAgIFQgZXh0ZW5kcyBHZXRDdXN0b21lcldpc2hsaXN0T3BlcmF0aW9uXHJcbiAgPihvcHRzOiB7XHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBCaWdjb21tZXJjZUNvbmZpZ1xyXG4gICAgaW5jbHVkZVByb2R1Y3RzPzogYm9vbGVhblxyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxUIGV4dGVuZHMgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgICAgaW5jbHVkZVByb2R1Y3RzPzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJXaXNobGlzdDxUIGV4dGVuZHMgR2V0Q3VzdG9tZXJXaXNobGlzdE9wZXJhdGlvbj4oe1xyXG4gICAgY29uZmlnLFxyXG4gICAgdmFyaWFibGVzLFxyXG4gICAgaW5jbHVkZVByb2R1Y3RzLFxyXG4gIH06IHtcclxuICAgIHVybD86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgIGluY2x1ZGVQcm9kdWN0cz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbmZpZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcblxyXG4gICAgY29uc3QgeyBkYXRhID0gW10gfSA9IGF3YWl0IGNvbmZpZy5zdG9yZUFwaUZldGNoPFxyXG4gICAgICBSZWN1cnNpdmVQYXJ0aWFsPHsgZGF0YTogV2lzaGxpc3RbXSB9PlxyXG4gICAgPihgL3YzL3dpc2hsaXN0cz9jdXN0b21lcl9pZD0ke3ZhcmlhYmxlcy5jdXN0b21lcklkfWApXHJcbiAgICBjb25zdCB3aXNobGlzdCA9IGRhdGFbMF1cclxuXHJcbiAgICBpZiAoaW5jbHVkZVByb2R1Y3RzICYmIHdpc2hsaXN0Py5pdGVtcz8ubGVuZ3RoKSB7XHJcbiAgICAgIGNvbnN0IGlkcyA9IHdpc2hsaXN0Lml0ZW1zXHJcbiAgICAgICAgPy5tYXAoKGl0ZW0pID0+IChpdGVtPy5wcm9kdWN0X2lkID8gU3RyaW5nKGl0ZW0/LnByb2R1Y3RfaWQpIDogbnVsbCkpXHJcbiAgICAgICAgLmZpbHRlcigoaWQpOiBpZCBpcyBzdHJpbmcgPT4gISFpZClcclxuXHJcbiAgICAgIGlmIChpZHM/Lmxlbmd0aCkge1xyXG4gICAgICAgIGNvbnN0IGdyYXBocWxEYXRhID0gYXdhaXQgY29tbWVyY2UuZ2V0QWxsUHJvZHVjdHMoe1xyXG4gICAgICAgICAgdmFyaWFibGVzOiB7IGZpcnN0OiA1MCwgaWRzIH0sXHJcbiAgICAgICAgICBjb25maWcsXHJcbiAgICAgICAgfSlcclxuICAgICAgICAvLyBQdXQgdGhlIHByb2R1Y3RzIGluIGFuIG9iamVjdCB0aGF0IHdlIGNhbiB1c2UgdG8gZ2V0IHRoZW0gYnkgaWRcclxuICAgICAgICBjb25zdCBwcm9kdWN0c0J5SWQgPSBncmFwaHFsRGF0YS5wcm9kdWN0cy5yZWR1Y2U8e1xyXG4gICAgICAgICAgW2s6IG51bWJlcl06IFByb2R1Y3RFZGdlXHJcbiAgICAgICAgfT4oKHByb2RzLCBwKSA9PiB7XHJcbiAgICAgICAgICBwcm9kc1tOdW1iZXIocC5pZCldID0gcCBhcyBhbnlcclxuICAgICAgICAgIHJldHVybiBwcm9kc1xyXG4gICAgICAgIH0sIHt9KVxyXG4gICAgICAgIC8vIFBvcHVsYXRlIHRoZSB3aXNobGlzdCBpdGVtcyB3aXRoIHRoZSBncmFwaHFsIHByb2R1Y3RzXHJcbiAgICAgICAgd2lzaGxpc3QuaXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcHJvZHVjdCA9IGl0ZW0gJiYgcHJvZHVjdHNCeUlkW2l0ZW0ucHJvZHVjdF9pZCFdXHJcbiAgICAgICAgICBpZiAoaXRlbSAmJiBwcm9kdWN0KSB7XHJcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgRml4IHRoaXMgdHlwZSB3aGVuIHRoZSB3aXNobGlzdCB0eXBlIGlzIHByb3Blcmx5IGRlZmluZWRcclxuICAgICAgICAgICAgaXRlbS5wcm9kdWN0ID0gcHJvZHVjdFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4geyB3aXNobGlzdDogd2lzaGxpc3QgYXMgUmVjdXJzaXZlUmVxdWlyZWQ8dHlwZW9mIHdpc2hsaXN0PiB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZ2V0Q3VzdG9tZXJXaXNobGlzdFxyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFBhZ2VPcGVyYXRpb24sIFBhZ2UgfSBmcm9tICcuLi8uLi90eXBlcy9wYWdlJ1xyXG5pbXBvcnQgdHlwZSB7IFJlY3Vyc2l2ZVBhcnRpYWwsIFJlY3Vyc2l2ZVJlcXVpcmVkIH0gZnJvbSAnLi4vdXRpbHMvdHlwZXMnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVBhZ2UgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0UGFnZU9wZXJhdGlvbih7XHJcbiAgY29tbWVyY2UsXHJcbn06IE9wZXJhdGlvbkNvbnRleHQ8UHJvdmlkZXI+KSB7XHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UGFnZTxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRQYWdlPFQgZXh0ZW5kcyBHZXRQYWdlT3BlcmF0aW9uPihcclxuICAgIG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0UGFnZTxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4oe1xyXG4gICAgdXJsLFxyXG4gICAgdmFyaWFibGVzLFxyXG4gICAgY29uZmlnLFxyXG4gICAgcHJldmlldyxcclxuICB9OiB7XHJcbiAgICB1cmw/OiBzdHJpbmdcclxuICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uc3QgY2ZnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNvbmZpZylcclxuICAgIC8vIFJlY3Vyc2l2ZVBhcnRpYWwgZm9yY2VzIHRoZSBtZXRob2QgdG8gY2hlY2sgZm9yIGV2ZXJ5IHByb3AgaW4gdGhlIGRhdGEsIHdoaWNoIGlzXHJcbiAgICAvLyByZXF1aXJlZCBpbiBjYXNlIHRoZXJlJ3MgYSBjdXN0b20gYHVybGBcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY2ZnLnN0b3JlQXBpRmV0Y2g8XHJcbiAgICAgIFJlY3Vyc2l2ZVBhcnRpYWw8eyBkYXRhOiBQYWdlW10gfT5cclxuICAgID4odXJsIHx8IGAvdjMvY29udGVudC9wYWdlcz9pZD0ke3ZhcmlhYmxlcy5pZH0maW5jbHVkZT1ib2R5YClcclxuICAgIGNvbnN0IGZpcnN0UGFnZSA9IGRhdGE/LlswXVxyXG4gICAgY29uc3QgcGFnZSA9IGZpcnN0UGFnZSBhcyBSZWN1cnNpdmVSZXF1aXJlZDx0eXBlb2YgZmlyc3RQYWdlPlxyXG5cclxuICAgIGlmIChwcmV2aWV3IHx8IHBhZ2U/LmlzX3Zpc2libGUpIHtcclxuICAgICAgcmV0dXJuIHsgcGFnZTogbm9ybWFsaXplUGFnZShwYWdlIGFzIGFueSkgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHt9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZ2V0UGFnZVxyXG59XHJcbiIsImltcG9ydCB0eXBlIHtcclxuICBPcGVyYXRpb25Db250ZXh0LFxyXG4gIE9wZXJhdGlvbk9wdGlvbnMsXHJcbn0gZnJvbSAnQGNvbW1lcmNlL2FwaS9vcGVyYXRpb25zJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFByb2R1Y3RPcGVyYXRpb24gfSBmcm9tICcuLi8uLi90eXBlcy9wcm9kdWN0J1xyXG5pbXBvcnQgdHlwZSB7IEdldFByb2R1Y3RRdWVyeSwgR2V0UHJvZHVjdFF1ZXJ5VmFyaWFibGVzIH0gZnJvbSAnLi4vLi4vc2NoZW1hJ1xyXG5pbXBvcnQgc2V0UHJvZHVjdExvY2FsZU1ldGEgZnJvbSAnLi4vdXRpbHMvc2V0LXByb2R1Y3QtbG9jYWxlLW1ldGEnXHJcbmltcG9ydCB7IHByb2R1Y3RJbmZvRnJhZ21lbnQgfSBmcm9tICcuLi9mcmFnbWVudHMvcHJvZHVjdCdcclxuaW1wb3J0IHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IG5vcm1hbGl6ZVByb2R1Y3QgfSBmcm9tICcuLi8uLi9saWIvbm9ybWFsaXplJ1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldFByb2R1Y3RRdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldFByb2R1Y3QoXHJcbiAgICAkaGFzTG9jYWxlOiBCb29sZWFuID0gZmFsc2VcclxuICAgICRsb2NhbGU6IFN0cmluZyA9IFwibnVsbFwiXHJcbiAgICAkcGF0aDogU3RyaW5nIVxyXG4gICkge1xyXG4gICAgc2l0ZSB7XHJcbiAgICAgIHJvdXRlKHBhdGg6ICRwYXRoKSB7XHJcbiAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICAuLi4gb24gUHJvZHVjdCB7XHJcbiAgICAgICAgICAgIC4uLnByb2R1Y3RJbmZvXHJcbiAgICAgICAgICAgIHZhcmlhbnRzIHtcclxuICAgICAgICAgICAgICBlZGdlcyB7XHJcbiAgICAgICAgICAgICAgICBub2RlIHtcclxuICAgICAgICAgICAgICAgICAgZW50aXR5SWRcclxuICAgICAgICAgICAgICAgICAgZGVmYXVsdEltYWdlIHtcclxuICAgICAgICAgICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICAgICAgICAgIGFsdFRleHRcclxuICAgICAgICAgICAgICAgICAgICBpc0RlZmF1bHRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBwcmljZXMge1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLnByb2R1Y3RQcmljZXNcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpbnZlbnRvcnkge1xyXG4gICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZWQge1xyXG4gICAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlVG9TZWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICB3YXJuaW5nTGV2ZWxcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaXNJblN0b2NrXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcHJvZHVjdE9wdGlvbnMge1xyXG4gICAgICAgICAgICAgICAgICAgIGVkZ2VzIHtcclxuICAgICAgICAgICAgICAgICAgICAgIG5vZGUge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfX3R5cGVuYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLm11bHRpcGxlQ2hvaWNlT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAke3Byb2R1Y3RJbmZvRnJhZ21lbnR9XHJcbmBcclxuXHJcbi8vIFRPRE86IFNlZSBpZiB0aGlzIHR5cGUgaXMgdXNlZnVsIGZvciBkZWZpbmluZyB0aGUgUHJvZHVjdCB0eXBlXHJcbi8vIGV4cG9ydCB0eXBlIFByb2R1Y3ROb2RlID0gRXh0cmFjdDxcclxuLy8gICBHZXRQcm9kdWN0UXVlcnlbJ3NpdGUnXVsncm91dGUnXVsnbm9kZSddLFxyXG4vLyAgIHsgX190eXBlbmFtZTogJ1Byb2R1Y3QnIH1cclxuLy8gPlxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0PFQgZXh0ZW5kcyBHZXRQcm9kdWN0T3BlcmF0aW9uPihvcHRzOiB7XHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFByb2R1Y3Q8VCBleHRlbmRzIEdldFByb2R1Y3RPcGVyYXRpb24+KFxyXG4gICAgb3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRQcm9kdWN0PFQgZXh0ZW5kcyBHZXRQcm9kdWN0T3BlcmF0aW9uPih7XHJcbiAgICBxdWVyeSA9IGdldFByb2R1Y3RRdWVyeSxcclxuICAgIHZhcmlhYmxlczogeyBzbHVnLCAuLi52YXJzIH0sXHJcbiAgICBjb25maWc6IGNmZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSk6IFByb21pc2U8VFsnZGF0YSddPiB7XHJcbiAgICBjb25zdCBjb25maWcgPSBjb21tZXJjZS5nZXRDb25maWcoY2ZnKVxyXG4gICAgY29uc3QgeyBsb2NhbGUgfSA9IGNvbmZpZ1xyXG4gICAgY29uc3QgdmFyaWFibGVzOiBHZXRQcm9kdWN0UXVlcnlWYXJpYWJsZXMgPSB7XHJcbiAgICAgIGxvY2FsZSxcclxuICAgICAgaGFzTG9jYWxlOiAhIWxvY2FsZSxcclxuICAgICAgcGF0aDogc2x1ZyA/IGAvJHtzbHVnfS9gIDogdmFycy5wYXRoISxcclxuICAgIH1cclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY29uZmlnLmZldGNoPEdldFByb2R1Y3RRdWVyeT4ocXVlcnksIHsgdmFyaWFibGVzIH0pXHJcbiAgICBjb25zdCBwcm9kdWN0ID0gZGF0YS5zaXRlPy5yb3V0ZT8ubm9kZVxyXG5cclxuICAgIGlmIChwcm9kdWN0Py5fX3R5cGVuYW1lID09PSAnUHJvZHVjdCcpIHtcclxuICAgICAgaWYgKGxvY2FsZSAmJiBjb25maWcuYXBwbHlMb2NhbGUpIHtcclxuICAgICAgICBzZXRQcm9kdWN0TG9jYWxlTWV0YShwcm9kdWN0KVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geyBwcm9kdWN0OiBub3JtYWxpemVQcm9kdWN0KHByb2R1Y3QgYXMgYW55KSB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHt9XHJcbiAgfVxyXG4gIHJldHVybiBnZXRQcm9kdWN0XHJcbn1cclxuIiwiaW1wb3J0IHR5cGUge1xyXG4gIE9wZXJhdGlvbkNvbnRleHQsXHJcbiAgT3BlcmF0aW9uT3B0aW9ucyxcclxufSBmcm9tICdAY29tbWVyY2UvYXBpL29wZXJhdGlvbnMnXHJcbmltcG9ydCB0eXBlIHsgR2V0U2l0ZUluZm9PcGVyYXRpb24gfSBmcm9tICcuLi8uLi90eXBlcy9zaXRlJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFNpdGVJbmZvUXVlcnkgfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCBmaWx0ZXJFZGdlcyBmcm9tICcuLi91dGlscy9maWx0ZXItZWRnZXMnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcbmltcG9ydCB7IGNhdGVnb3J5VHJlZUl0ZW1GcmFnbWVudCB9IGZyb20gJy4uL2ZyYWdtZW50cy9jYXRlZ29yeS10cmVlJ1xyXG5pbXBvcnQgeyBub3JtYWxpemVDYXRlZ29yeSB9IGZyb20gJy4uLy4uL2xpYi9ub3JtYWxpemUnXHJcblxyXG4vLyBHZXQgMyBsZXZlbHMgb2YgY2F0ZWdvcmllc1xyXG5leHBvcnQgY29uc3QgZ2V0U2l0ZUluZm9RdWVyeSA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIHF1ZXJ5IGdldFNpdGVJbmZvIHtcclxuICAgIHNpdGUge1xyXG4gICAgICBjYXRlZ29yeVRyZWUge1xyXG4gICAgICAgIC4uLmNhdGVnb3J5VHJlZUl0ZW1cclxuICAgICAgICBjaGlsZHJlbiB7XHJcbiAgICAgICAgICAuLi5jYXRlZ29yeVRyZWVJdGVtXHJcbiAgICAgICAgICBjaGlsZHJlbiB7XHJcbiAgICAgICAgICAgIC4uLmNhdGVnb3J5VHJlZUl0ZW1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgYnJhbmRzIHtcclxuICAgICAgICBwYWdlSW5mbyB7XHJcbiAgICAgICAgICBzdGFydEN1cnNvclxyXG4gICAgICAgICAgZW5kQ3Vyc29yXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVkZ2VzIHtcclxuICAgICAgICAgIGN1cnNvclxyXG4gICAgICAgICAgbm9kZSB7XHJcbiAgICAgICAgICAgIGVudGl0eUlkXHJcbiAgICAgICAgICAgIG5hbWVcclxuICAgICAgICAgICAgZGVmYXVsdEltYWdlIHtcclxuICAgICAgICAgICAgICB1cmxPcmlnaW5hbFxyXG4gICAgICAgICAgICAgIGFsdFRleHRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBwYWdlVGl0bGVcclxuICAgICAgICAgICAgbWV0YURlc2NcclxuICAgICAgICAgICAgbWV0YUtleXdvcmRzXHJcbiAgICAgICAgICAgIHNlYXJjaEtleXdvcmRzXHJcbiAgICAgICAgICAgIHBhdGhcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgJHtjYXRlZ29yeVRyZWVJdGVtRnJhZ21lbnR9XHJcbmBcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGdldFNpdGVJbmZvT3BlcmF0aW9uKHtcclxuICBjb21tZXJjZSxcclxufTogT3BlcmF0aW9uQ29udGV4dDxQcm92aWRlcj4pIHtcclxuICBhc3luYyBmdW5jdGlvbiBnZXRTaXRlSW5mbzxUIGV4dGVuZHMgR2V0U2l0ZUluZm9PcGVyYXRpb24+KG9wdHM/OiB7XHJcbiAgICBjb25maWc/OiBQYXJ0aWFsPEJpZ2NvbW1lcmNlQ29uZmlnPlxyXG4gICAgcHJldmlldz86IGJvb2xlYW5cclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFNpdGVJbmZvPFQgZXh0ZW5kcyBHZXRTaXRlSW5mb09wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIGNvbmZpZz86IFBhcnRpYWw8QmlnY29tbWVyY2VDb25maWc+XHJcbiAgICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRTaXRlSW5mbzxUIGV4dGVuZHMgR2V0U2l0ZUluZm9PcGVyYXRpb24+KHtcclxuICAgIHF1ZXJ5ID0gZ2V0U2l0ZUluZm9RdWVyeSxcclxuICAgIGNvbmZpZyxcclxuICB9OiB7XHJcbiAgICBxdWVyeT86IHN0cmluZ1xyXG4gICAgY29uZmlnPzogUGFydGlhbDxCaWdjb21tZXJjZUNvbmZpZz5cclxuICAgIHByZXZpZXc/OiBib29sZWFuXHJcbiAgfSA9IHt9KTogUHJvbWlzZTxUWydkYXRhJ10+IHtcclxuICAgIGNvbnN0IGNmZyA9IGNvbW1lcmNlLmdldENvbmZpZyhjb25maWcpXHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGNmZy5mZXRjaDxHZXRTaXRlSW5mb1F1ZXJ5PihxdWVyeSlcclxuICAgIGNvbnN0IGNhdGVnb3JpZXMgPSBkYXRhLnNpdGUuY2F0ZWdvcnlUcmVlLm1hcChub3JtYWxpemVDYXRlZ29yeSlcclxuICAgIGNvbnN0IGJyYW5kcyA9IGRhdGEuc2l0ZT8uYnJhbmRzPy5lZGdlc1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGNhdGVnb3JpZXM6IGNhdGVnb3JpZXMgPz8gW10sXHJcbiAgICAgIGJyYW5kczogZmlsdGVyRWRnZXMoYnJhbmRzKSxcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiBnZXRTaXRlSW5mb1xyXG59XHJcbiIsImltcG9ydCB0eXBlIHsgU2VydmVyUmVzcG9uc2UgfSBmcm9tICdodHRwJ1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgT3BlcmF0aW9uQ29udGV4dCxcclxuICBPcGVyYXRpb25PcHRpb25zLFxyXG59IGZyb20gJ0Bjb21tZXJjZS9hcGkvb3BlcmF0aW9ucydcclxuaW1wb3J0IHR5cGUgeyBMb2dpbk9wZXJhdGlvbiB9IGZyb20gJy4uLy4uL3R5cGVzL2xvZ2luJ1xyXG5pbXBvcnQgdHlwZSB7IExvZ2luTXV0YXRpb24gfSBmcm9tICcuLi8uLi9zY2hlbWEnXHJcbmltcG9ydCB0eXBlIHsgUmVjdXJzaXZlUGFydGlhbCB9IGZyb20gJy4uL3V0aWxzL3R5cGVzJ1xyXG5pbXBvcnQgY29uY2F0SGVhZGVyIGZyb20gJy4uL3V0aWxzL2NvbmNhdC1jb29raWUnXHJcbmltcG9ydCB0eXBlIHsgQmlnY29tbWVyY2VDb25maWcsIFByb3ZpZGVyIH0gZnJvbSAnLi4nXHJcblxyXG5leHBvcnQgY29uc3QgbG9naW5NdXRhdGlvbiA9IC8qIEdyYXBoUUwgKi8gYFxyXG4gIG11dGF0aW9uIGxvZ2luKCRlbWFpbDogU3RyaW5nISwgJHBhc3N3b3JkOiBTdHJpbmchKSB7XHJcbiAgICBsb2dpbihlbWFpbDogJGVtYWlsLCBwYXNzd29yZDogJHBhc3N3b3JkKSB7XHJcbiAgICAgIHJlc3VsdFxyXG4gICAgfVxyXG4gIH1cclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbG9naW5PcGVyYXRpb24oe1xyXG4gIGNvbW1lcmNlLFxyXG59OiBPcGVyYXRpb25Db250ZXh0PFByb3ZpZGVyPikge1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvZ2luPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgIHJlczogU2VydmVyUmVzcG9uc2VcclxuICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGxvZ2luPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4oXHJcbiAgICBvcHRzOiB7XHJcbiAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgY29uZmlnPzogQmlnY29tbWVyY2VDb25maWdcclxuICAgICAgcmVzOiBTZXJ2ZXJSZXNwb25zZVxyXG4gICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gbG9naW48VCBleHRlbmRzIExvZ2luT3BlcmF0aW9uPih7XHJcbiAgICBxdWVyeSA9IGxvZ2luTXV0YXRpb24sXHJcbiAgICB2YXJpYWJsZXMsXHJcbiAgICByZXM6IHJlc3BvbnNlLFxyXG4gICAgY29uZmlnLFxyXG4gIH06IHtcclxuICAgIHF1ZXJ5Pzogc3RyaW5nXHJcbiAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICByZXM6IFNlcnZlclJlc3BvbnNlXHJcbiAgICBjb25maWc/OiBCaWdjb21tZXJjZUNvbmZpZ1xyXG4gIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT4ge1xyXG4gICAgY29uZmlnID0gY29tbWVyY2UuZ2V0Q29uZmlnKGNvbmZpZylcclxuXHJcbiAgICBjb25zdCB7IGRhdGEsIHJlcyB9ID0gYXdhaXQgY29uZmlnLmZldGNoPFJlY3Vyc2l2ZVBhcnRpYWw8TG9naW5NdXRhdGlvbj4+KFxyXG4gICAgICBxdWVyeSxcclxuICAgICAgeyB2YXJpYWJsZXMgfVxyXG4gICAgKVxyXG4gICAgLy8gQmlnY29tbWVyY2UgcmV0dXJucyBhIFNldC1Db29raWUgaGVhZGVyIHdpdGggdGhlIGF1dGggY29va2llXHJcbiAgICBsZXQgY29va2llID0gcmVzLmhlYWRlcnMuZ2V0KCdTZXQtQ29va2llJylcclxuXHJcbiAgICBpZiAoY29va2llICYmIHR5cGVvZiBjb29raWUgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIC8vIEluIGRldmVsb3BtZW50LCBkb24ndCBzZXQgYSBzZWN1cmUgY29va2llIG9yIHRoZSBicm93c2VyIHdpbGwgaWdub3JlIGl0XHJcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XHJcbiAgICAgICAgY29va2llID0gY29va2llLnJlcGxhY2UoJzsgU2VjdXJlJywgJycpXHJcbiAgICAgICAgLy8gU2FtZVNpdGU9bm9uZSBjYW4ndCBiZSBzZXQgdW5sZXNzIHRoZSBjb29raWUgaXMgU2VjdXJlXHJcbiAgICAgICAgLy8gYmMgc2VlbXMgdG8gc29tZXRpbWVzIHNlbmQgYmFjayBTYW1lU2l0ZT1Ob25lIHJhdGhlciB0aGFuIG5vbmUgc28gbWFrZVxyXG4gICAgICAgIC8vIHRoaXMgY2FzZSBpbnNlbnNpdGl2ZVxyXG4gICAgICAgIGNvb2tpZSA9IGNvb2tpZS5yZXBsYWNlKC87IFNhbWVTaXRlPW5vbmUvZ2ksICc7IFNhbWVTaXRlPWxheCcpXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJlc3BvbnNlLnNldEhlYWRlcihcclxuICAgICAgICAnU2V0LUNvb2tpZScsXHJcbiAgICAgICAgY29uY2F0SGVhZGVyKHJlc3BvbnNlLmdldEhlYWRlcignU2V0LUNvb2tpZScpLCBjb29raWUpIVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzdWx0OiBkYXRhLmxvZ2luPy5yZXN1bHQsXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gbG9naW5cclxufVxyXG4iLCJ0eXBlIEhlYWRlciA9IHN0cmluZyB8IG51bWJlciB8IHN0cmluZ1tdIHwgdW5kZWZpbmVkXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjb25jYXRIZWFkZXIocHJldjogSGVhZGVyLCB2YWw6IEhlYWRlcikge1xyXG4gIGlmICghdmFsKSByZXR1cm4gcHJldlxyXG4gIGlmICghcHJldikgcmV0dXJuIHZhbFxyXG5cclxuICBpZiAoQXJyYXkuaXNBcnJheShwcmV2KSkgcmV0dXJuIHByZXYuY29uY2F0KFN0cmluZyh2YWwpKVxyXG5cclxuICBwcmV2ID0gU3RyaW5nKHByZXYpXHJcblxyXG4gIGlmIChBcnJheS5pc0FycmF5KHZhbCkpIHJldHVybiBbcHJldl0uY29uY2F0KHZhbClcclxuXHJcbiAgcmV0dXJuIFtwcmV2LCBTdHJpbmcodmFsKV1cclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IFJlc3BvbnNlIH0gZnJvbSAnQHZlcmNlbC9mZXRjaCdcclxuXHJcbi8vIFVzZWQgZm9yIEdyYXBoUUwgZXJyb3JzXHJcbmV4cG9ydCBjbGFzcyBCaWdjb21tZXJjZUdyYXBoUUxFcnJvciBleHRlbmRzIEVycm9yIHt9XHJcblxyXG5leHBvcnQgY2xhc3MgQmlnY29tbWVyY2VBcGlFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlclxyXG4gIHJlczogUmVzcG9uc2VcclxuICBkYXRhOiBhbnlcclxuXHJcbiAgY29uc3RydWN0b3IobXNnOiBzdHJpbmcsIHJlczogUmVzcG9uc2UsIGRhdGE/OiBhbnkpIHtcclxuICAgIHN1cGVyKG1zZylcclxuICAgIHRoaXMubmFtZSA9ICdCaWdjb21tZXJjZUFwaUVycm9yJ1xyXG4gICAgdGhpcy5zdGF0dXMgPSByZXMuc3RhdHVzXHJcbiAgICB0aGlzLnJlcyA9IHJlc1xyXG4gICAgdGhpcy5kYXRhID0gZGF0YVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIGNvbnN0cnVjdG9yKG1zZzogc3RyaW5nKSB7XHJcbiAgICBzdXBlcihtc2cpXHJcbiAgICB0aGlzLm5hbWUgPSAnQmlnY29tbWVyY2VOZXR3b3JrRXJyb3InXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEZldGNoZXJFcnJvciB9IGZyb20gJ0Bjb21tZXJjZS91dGlscy9lcnJvcnMnXHJcbmltcG9ydCB0eXBlIHsgR3JhcGhRTEZldGNoZXIgfSBmcm9tICdAY29tbWVyY2UvYXBpJ1xyXG5pbXBvcnQgdHlwZSB7IEJpZ2NvbW1lcmNlQ29uZmlnIH0gZnJvbSAnLi4vaW5kZXgnXHJcbmltcG9ydCBmZXRjaCBmcm9tICcuL2ZldGNoJ1xyXG5cclxuY29uc3QgZmV0Y2hHcmFwaHFsQXBpOiAoZ2V0Q29uZmlnOiAoKSA9PiBCaWdjb21tZXJjZUNvbmZpZykgPT4gR3JhcGhRTEZldGNoZXIgPVxyXG4gIChnZXRDb25maWcpID0+XHJcbiAgYXN5bmMgKHF1ZXJ5OiBzdHJpbmcsIHsgdmFyaWFibGVzLCBwcmV2aWV3IH0gPSB7fSwgZmV0Y2hPcHRpb25zKSA9PiB7XHJcbiAgICAvLyBsb2cud2FybihxdWVyeSlcclxuICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZygpXHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChjb25maWcuY29tbWVyY2VVcmwgKyAocHJldmlldyA/ICcvcHJldmlldycgOiAnJyksIHtcclxuICAgICAgLi4uZmV0Y2hPcHRpb25zLFxyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjb25maWcuYXBpVG9rZW59YCxcclxuICAgICAgICAuLi5mZXRjaE9wdGlvbnM/LmhlYWRlcnMsXHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgfSxcclxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHF1ZXJ5LFxyXG4gICAgICAgIHZhcmlhYmxlcyxcclxuICAgICAgfSksXHJcbiAgICB9KVxyXG5cclxuICAgIGNvbnN0IGpzb24gPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICBpZiAoanNvbi5lcnJvcnMpIHtcclxuICAgICAgdGhyb3cgbmV3IEZldGNoZXJFcnJvcih7XHJcbiAgICAgICAgZXJyb3JzOiBqc29uLmVycm9ycyA/PyBbeyBtZXNzYWdlOiAnRmFpbGVkIHRvIGZldGNoIEJpZ2NvbW1lcmNlIEFQSScgfV0sXHJcbiAgICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7IGRhdGE6IGpzb24uZGF0YSwgcmVzIH1cclxuICB9XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaEdyYXBocWxBcGlcclxuIiwiaW1wb3J0IHR5cGUgeyBSZXF1ZXN0SW5pdCwgUmVzcG9uc2UgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5pbXBvcnQgdHlwZSB7IEJpZ2NvbW1lcmNlQ29uZmlnIH0gZnJvbSAnLi4vaW5kZXgnXHJcbmltcG9ydCB7IEJpZ2NvbW1lcmNlQXBpRXJyb3IsIEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yIH0gZnJvbSAnLi9lcnJvcnMnXHJcbmltcG9ydCBmZXRjaCBmcm9tICcuL2ZldGNoJ1xyXG5cclxuY29uc3QgZmV0Y2hTdG9yZUFwaSA9XHJcbiAgPFQ+KGdldENvbmZpZzogKCkgPT4gQmlnY29tbWVyY2VDb25maWcpID0+XHJcbiAgYXN5bmMgKGVuZHBvaW50OiBzdHJpbmcsIG9wdGlvbnM/OiBSZXF1ZXN0SW5pdCk6IFByb21pc2U8VD4gPT4ge1xyXG4gICAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnKClcclxuICAgIGxldCByZXM6IFJlc3BvbnNlXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgcmVzID0gYXdhaXQgZmV0Y2goY29uZmlnLnN0b3JlQXBpVXJsICsgZW5kcG9pbnQsIHtcclxuICAgICAgICAuLi5vcHRpb25zLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIC4uLm9wdGlvbnM/LmhlYWRlcnMsXHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgJ1gtQXV0aC1Ub2tlbic6IGNvbmZpZy5zdG9yZUFwaVRva2VuLFxyXG4gICAgICAgICAgJ1gtQXV0aC1DbGllbnQnOiBjb25maWcuc3RvcmVBcGlDbGllbnRJZCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgdGhyb3cgbmV3IEJpZ2NvbW1lcmNlTmV0d29ya0Vycm9yKFxyXG4gICAgICAgIGBGZXRjaCB0byBCaWdjb21tZXJjZSBmYWlsZWQ6ICR7ZXJyb3IubWVzc2FnZX1gXHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlcy5oZWFkZXJzLmdldCgnQ29udGVudC1UeXBlJylcclxuICAgIGNvbnN0IGlzSlNPTiA9IGNvbnRlbnRUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpXHJcblxyXG4gICAgaWYgKCFyZXMub2spIHtcclxuICAgICAgY29uc3QgZGF0YSA9IGlzSlNPTiA/IGF3YWl0IHJlcy5qc29uKCkgOiBhd2FpdCBnZXRUZXh0T3JOdWxsKHJlcylcclxuICAgICAgY29uc3QgaGVhZGVycyA9IGdldFJhd0hlYWRlcnMocmVzKVxyXG4gICAgICBjb25zdCBtc2cgPSBgQmlnIENvbW1lcmNlIEFQSSBlcnJvciAoJHtcclxuICAgICAgICByZXMuc3RhdHVzXHJcbiAgICAgIH0pIFxcbkhlYWRlcnM6ICR7SlNPTi5zdHJpbmdpZnkoaGVhZGVycywgbnVsbCwgMil9XFxuJHtcclxuICAgICAgICB0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycgPyBkYXRhIDogSlNPTi5zdHJpbmdpZnkoZGF0YSwgbnVsbCwgMilcclxuICAgICAgfWBcclxuXHJcbiAgICAgIHRocm93IG5ldyBCaWdjb21tZXJjZUFwaUVycm9yKG1zZywgcmVzLCBkYXRhKVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChyZXMuc3RhdHVzICE9PSAyMDQgJiYgIWlzSlNPTikge1xyXG4gICAgICB0aHJvdyBuZXcgQmlnY29tbWVyY2VBcGlFcnJvcihcclxuICAgICAgICBgRmV0Y2ggdG8gQmlnY29tbWVyY2UgQVBJIGZhaWxlZCwgZXhwZWN0ZWQgSlNPTiBjb250ZW50IGJ1dCBmb3VuZDogJHtjb250ZW50VHlwZX1gLFxyXG4gICAgICAgIHJlc1xyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgLy8gSWYgc29tZXRoaW5nIHdhcyByZW1vdmVkLCB0aGUgcmVzcG9uc2Ugd2lsbCBiZSBlbXB0eVxyXG4gICAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwNCA/IG51bGwgOiBhd2FpdCByZXMuanNvbigpXHJcbiAgfVxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaFN0b3JlQXBpXHJcblxyXG5mdW5jdGlvbiBnZXRSYXdIZWFkZXJzKHJlczogUmVzcG9uc2UpIHtcclxuICBjb25zdCBoZWFkZXJzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge31cclxuXHJcbiAgcmVzLmhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xyXG4gICAgaGVhZGVyc1trZXldID0gdmFsdWVcclxuICB9KVxyXG5cclxuICByZXR1cm4gaGVhZGVyc1xyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRUZXh0T3JOdWxsKHJlczogUmVzcG9uc2UpIHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIHJlcy50ZXh0KClcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHJldHVybiBudWxsXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB6ZWl0RmV0Y2ggZnJvbSAnQHZlcmNlbC9mZXRjaCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHplaXRGZXRjaCgpXHJcbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGZpbHRlckVkZ2VzPFQ+KFxyXG4gIGVkZ2VzOiAoVCB8IG51bGwgfCB1bmRlZmluZWQpW10gfCBudWxsIHwgdW5kZWZpbmVkXHJcbikge1xyXG4gIHJldHVybiBlZGdlcz8uZmlsdGVyKChlZGdlKTogZWRnZSBpcyBUID0+ICEhZWRnZSkgPz8gW11cclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IFByb2R1Y3ROb2RlIH0gZnJvbSAnLi4vb3BlcmF0aW9ucy9nZXQtYWxsLXByb2R1Y3RzJ1xyXG5pbXBvcnQgdHlwZSB7IFJlY3Vyc2l2ZVBhcnRpYWwgfSBmcm9tICcuL3R5cGVzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2V0UHJvZHVjdExvY2FsZU1ldGEoXHJcbiAgbm9kZTogUmVjdXJzaXZlUGFydGlhbDxQcm9kdWN0Tm9kZT5cclxuKSB7XHJcbiAgaWYgKG5vZGUubG9jYWxlTWV0YT8uZWRnZXMpIHtcclxuICAgIG5vZGUubG9jYWxlTWV0YS5lZGdlcyA9IG5vZGUubG9jYWxlTWV0YS5lZGdlcy5maWx0ZXIoKGVkZ2UpID0+IHtcclxuICAgICAgY29uc3QgeyBrZXksIHZhbHVlIH0gPSBlZGdlPy5ub2RlID8/IHt9XHJcbiAgICAgIGlmIChrZXkgJiYga2V5IGluIG5vZGUpIHtcclxuICAgICAgICA7KG5vZGUgYXMgYW55KVtrZXldID0gdmFsdWVcclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gdHJ1ZVxyXG4gICAgfSlcclxuXHJcbiAgICBpZiAoIW5vZGUubG9jYWxlTWV0YS5lZGdlcy5sZW5ndGgpIHtcclxuICAgICAgZGVsZXRlIG5vZGUubG9jYWxlTWV0YVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCIvLyBSZW1vdmUgdHJhaWxpbmcgYW5kIGxlYWRpbmcgc2xhc2gsIHVzdWFsbHkgaW5jbHVkZWQgaW4gbm9kZXNcclxuLy8gcmV0dXJuZWQgYnkgdGhlIEJpZ0NvbW1lcmNlIEFQSVxyXG5jb25zdCBnZXRTbHVnID0gKHBhdGg6IHN0cmluZykgPT4gcGF0aC5yZXBsYWNlKC9eXFwvfFxcLyQvZywgJycpXHJcblxyXG5leHBvcnQgZGVmYXVsdCBnZXRTbHVnXHJcbiIsImltcG9ydCB1cGRhdGUsIHsgQ29udGV4dCB9IGZyb20gJ2ltbXV0YWJpbGl0eS1oZWxwZXInXHJcblxyXG5jb25zdCBjID0gbmV3IENvbnRleHQoKVxyXG5cclxuYy5leHRlbmQoJyRhdXRvJywgZnVuY3Rpb24gKHZhbHVlLCBvYmplY3QpIHtcclxuICByZXR1cm4gb2JqZWN0ID8gYy51cGRhdGUob2JqZWN0LCB2YWx1ZSkgOiBjLnVwZGF0ZSh7fSwgdmFsdWUpXHJcbn0pXHJcblxyXG5jLmV4dGVuZCgnJGF1dG9BcnJheScsIGZ1bmN0aW9uICh2YWx1ZSwgb2JqZWN0KSB7XHJcbiAgcmV0dXJuIG9iamVjdCA/IGMudXBkYXRlKG9iamVjdCwgdmFsdWUpIDogYy51cGRhdGUoW10sIHZhbHVlKVxyXG59KVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYy51cGRhdGVcclxuIiwiaW1wb3J0IHR5cGUgeyBQcm9kdWN0IH0gZnJvbSAnLi4vdHlwZXMvcHJvZHVjdCdcclxuaW1wb3J0IHR5cGUgeyBDYXJ0LCBCaWdjb21tZXJjZUNhcnQsIExpbmVJdGVtIH0gZnJvbSAnLi4vdHlwZXMvY2FydCdcclxuaW1wb3J0IHR5cGUgeyBQYWdlIH0gZnJvbSAnLi4vdHlwZXMvcGFnZSdcclxuaW1wb3J0IHR5cGUgeyBCQ0NhdGVnb3J5LCBDYXRlZ29yeSB9IGZyb20gJy4uL3R5cGVzL3NpdGUnXHJcbmltcG9ydCB7IGRlZmluaXRpb25zIH0gZnJvbSAnLi4vYXBpL2RlZmluaXRpb25zL3N0b3JlLWNvbnRlbnQnXHJcbmltcG9ydCB1cGRhdGUgZnJvbSAnLi9pbW11dGFiaWxpdHknXHJcbmltcG9ydCBnZXRTbHVnIGZyb20gJy4vZ2V0LXNsdWcnXHJcblxyXG5mdW5jdGlvbiBub3JtYWxpemVQcm9kdWN0T3B0aW9uKHByb2R1Y3RPcHRpb246IGFueSkge1xyXG4gIGNvbnN0IHtcclxuICAgIG5vZGU6IHtcclxuICAgICAgZW50aXR5SWQsXHJcbiAgICAgIHZhbHVlczogeyBlZGdlcyA9IFtdIH0gPSB7fSxcclxuICAgICAgLi4ucmVzdFxyXG4gICAgfSxcclxuICB9ID0gcHJvZHVjdE9wdGlvblxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgaWQ6IGVudGl0eUlkLFxyXG4gICAgdmFsdWVzOiBlZGdlcz8ubWFwKCh7IG5vZGUgfTogYW55KSA9PiBub2RlKSxcclxuICAgIC4uLnJlc3QsXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplUHJvZHVjdChwcm9kdWN0Tm9kZTogYW55KTogUHJvZHVjdCB7XHJcbiAgY29uc3Qge1xyXG4gICAgZW50aXR5SWQ6IGlkLFxyXG4gICAgcHJvZHVjdE9wdGlvbnMsXHJcbiAgICBwcmljZXMsXHJcbiAgICBwYXRoLFxyXG4gICAgaWQ6IF8sXHJcbiAgICBvcHRpb25zOiBfMCxcclxuICB9ID0gcHJvZHVjdE5vZGVcclxuXHJcbiAgcmV0dXJuIHVwZGF0ZShwcm9kdWN0Tm9kZSwge1xyXG4gICAgaWQ6IHsgJHNldDogU3RyaW5nKGlkKSB9LFxyXG4gICAgaW1hZ2VzOiB7XHJcbiAgICAgICRhcHBseTogKHsgZWRnZXMgfTogYW55KSA9PlxyXG4gICAgICAgIGVkZ2VzPy5tYXAoKHsgbm9kZTogeyB1cmxPcmlnaW5hbCwgYWx0VGV4dCwgLi4ucmVzdCB9IH06IGFueSkgPT4gKHtcclxuICAgICAgICAgIHVybDogdXJsT3JpZ2luYWwsXHJcbiAgICAgICAgICBhbHQ6IGFsdFRleHQsXHJcbiAgICAgICAgICAuLi5yZXN0LFxyXG4gICAgICAgIH0pKSxcclxuICAgIH0sXHJcbiAgICB2YXJpYW50czoge1xyXG4gICAgICAkYXBwbHk6ICh7IGVkZ2VzIH06IGFueSkgPT5cclxuICAgICAgICBlZGdlcz8ubWFwKCh7IG5vZGU6IHsgZW50aXR5SWQsIHByb2R1Y3RPcHRpb25zLCAuLi5yZXN0IH0gfTogYW55KSA9PiAoe1xyXG4gICAgICAgICAgaWQ6IGVudGl0eUlkLFxyXG4gICAgICAgICAgb3B0aW9uczogcHJvZHVjdE9wdGlvbnM/LmVkZ2VzXHJcbiAgICAgICAgICAgID8gcHJvZHVjdE9wdGlvbnMuZWRnZXMubWFwKG5vcm1hbGl6ZVByb2R1Y3RPcHRpb24pXHJcbiAgICAgICAgICAgIDogW10sXHJcbiAgICAgICAgICAuLi5yZXN0LFxyXG4gICAgICAgIH0pKSxcclxuICAgIH0sXHJcbiAgICBvcHRpb25zOiB7XHJcbiAgICAgICRzZXQ6IHByb2R1Y3RPcHRpb25zLmVkZ2VzXHJcbiAgICAgICAgPyBwcm9kdWN0T3B0aW9ucz8uZWRnZXMubWFwKG5vcm1hbGl6ZVByb2R1Y3RPcHRpb24pXHJcbiAgICAgICAgOiBbXSxcclxuICAgIH0sXHJcbiAgICBicmFuZDoge1xyXG4gICAgICAkYXBwbHk6IChicmFuZDogYW55KSA9PiAoYnJhbmQ/LmVudGl0eUlkID8gYnJhbmQ/LmVudGl0eUlkIDogbnVsbCksXHJcbiAgICB9LFxyXG4gICAgc2x1Zzoge1xyXG4gICAgICAkc2V0OiBwYXRoPy5yZXBsYWNlKC9eXFwvK3xcXC8rJC9nLCAnJyksXHJcbiAgICB9LFxyXG4gICAgcHJpY2U6IHtcclxuICAgICAgJHNldDoge1xyXG4gICAgICAgIHZhbHVlOiBwcmljZXM/LnByaWNlLnZhbHVlLFxyXG4gICAgICAgIGN1cnJlbmN5Q29kZTogcHJpY2VzPy5wcmljZS5jdXJyZW5jeUNvZGUsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgJHVuc2V0OiBbJ2VudGl0eUlkJ10sXHJcbiAgfSlcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVBhZ2UocGFnZTogZGVmaW5pdGlvbnNbJ3BhZ2VfRnVsbCddKTogUGFnZSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIGlkOiBTdHJpbmcocGFnZS5pZCksXHJcbiAgICBuYW1lOiBwYWdlLm5hbWUsXHJcbiAgICBpc192aXNpYmxlOiBwYWdlLmlzX3Zpc2libGUsXHJcbiAgICBzb3J0X29yZGVyOiBwYWdlLnNvcnRfb3JkZXIsXHJcbiAgICBib2R5OiBwYWdlLmJvZHksXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplQ2FydChkYXRhOiBCaWdjb21tZXJjZUNhcnQpOiBDYXJ0IHtcclxuICByZXR1cm4ge1xyXG4gICAgaWQ6IGRhdGEuaWQsXHJcbiAgICBjdXN0b21lcklkOiBTdHJpbmcoZGF0YS5jdXN0b21lcl9pZCksXHJcbiAgICBlbWFpbDogZGF0YS5lbWFpbCxcclxuICAgIGNyZWF0ZWRBdDogZGF0YS5jcmVhdGVkX3RpbWUsXHJcbiAgICBjdXJyZW5jeTogZGF0YS5jdXJyZW5jeSxcclxuICAgIHRheGVzSW5jbHVkZWQ6IGRhdGEudGF4X2luY2x1ZGVkLFxyXG4gICAgbGluZUl0ZW1zOiBbXHJcbiAgICAgIC4uLmRhdGEubGluZV9pdGVtcy5waHlzaWNhbF9pdGVtcy5tYXAobm9ybWFsaXplTGluZUl0ZW0pLFxyXG4gICAgICAuLi5kYXRhLmxpbmVfaXRlbXMuZGlnaXRhbF9pdGVtcy5tYXAobm9ybWFsaXplTGluZUl0ZW0pLFxyXG4gICAgXSxcclxuICAgIGxpbmVJdGVtc1N1YnRvdGFsUHJpY2U6IGRhdGEuYmFzZV9hbW91bnQsXHJcbiAgICBzdWJ0b3RhbFByaWNlOiBkYXRhLmJhc2VfYW1vdW50ICsgZGF0YS5kaXNjb3VudF9hbW91bnQsXHJcbiAgICB0b3RhbFByaWNlOiBkYXRhLmNhcnRfYW1vdW50LFxyXG4gICAgZGlzY291bnRzOiBkYXRhLmRpc2NvdW50cz8ubWFwKChkaXNjb3VudCkgPT4gKHtcclxuICAgICAgdmFsdWU6IGRpc2NvdW50LmRpc2NvdW50ZWRfYW1vdW50LFxyXG4gICAgfSkpLFxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gbm9ybWFsaXplTGluZUl0ZW0oaXRlbTogYW55KTogTGluZUl0ZW0ge1xyXG4gIHJldHVybiB7XHJcbiAgICBpZDogaXRlbS5pZCxcclxuICAgIHZhcmlhbnRJZDogU3RyaW5nKGl0ZW0udmFyaWFudF9pZCksXHJcbiAgICBwcm9kdWN0SWQ6IFN0cmluZyhpdGVtLnByb2R1Y3RfaWQpLFxyXG4gICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgcXVhbnRpdHk6IGl0ZW0ucXVhbnRpdHksXHJcbiAgICB2YXJpYW50OiB7XHJcbiAgICAgIGlkOiBTdHJpbmcoaXRlbS52YXJpYW50X2lkKSxcclxuICAgICAgc2t1OiBpdGVtLnNrdSxcclxuICAgICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgICBpbWFnZToge1xyXG4gICAgICAgIHVybDogaXRlbS5pbWFnZV91cmwsXHJcbiAgICAgIH0sXHJcbiAgICAgIHJlcXVpcmVzU2hpcHBpbmc6IGl0ZW0uaXNfcmVxdWlyZV9zaGlwcGluZyxcclxuICAgICAgcHJpY2U6IGl0ZW0uc2FsZV9wcmljZSxcclxuICAgICAgbGlzdFByaWNlOiBpdGVtLmxpc3RfcHJpY2UsXHJcbiAgICB9LFxyXG4gICAgcGF0aDogaXRlbS51cmwuc3BsaXQoJy8nKVszXSxcclxuICAgIGRpc2NvdW50czogaXRlbS5kaXNjb3VudHMubWFwKChkaXNjb3VudDogYW55KSA9PiAoe1xyXG4gICAgICB2YWx1ZTogZGlzY291bnQuZGlzY291bnRlZF9hbW91bnQsXHJcbiAgICB9KSksXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplQ2F0ZWdvcnkoY2F0ZWdvcnk6IEJDQ2F0ZWdvcnkpOiBDYXRlZ29yeSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIGlkOiBgJHtjYXRlZ29yeS5lbnRpdHlJZH1gLFxyXG4gICAgbmFtZTogY2F0ZWdvcnkubmFtZSxcclxuICAgIHNsdWc6IGdldFNsdWcoY2F0ZWdvcnkucGF0aCksXHJcbiAgICBwYXRoOiBjYXRlZ29yeS5wYXRoLFxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IEN1c3RvbWVyU2NoZW1hIH0gZnJvbSAnLi4vLi4vLi4vdHlwZXMvY3VzdG9tZXInXHJcbmltcG9ydCB0eXBlIHsgR2V0QVBJU2NoZW1hIH0gZnJvbSAnLi4vLi4nXHJcblxyXG5pbXBvcnQgeyBDb21tZXJjZUFQSUVycm9yIH0gZnJvbSAnLi4vLi4vdXRpbHMvZXJyb3JzJ1xyXG5pbXBvcnQgaXNBbGxvd2VkT3BlcmF0aW9uIGZyb20gJy4uLy4uL3V0aWxzL2lzLWFsbG93ZWQtb3BlcmF0aW9uJ1xyXG5cclxuY29uc3QgY3VzdG9tZXJFbmRwb2ludDogR2V0QVBJU2NoZW1hPFxyXG4gIGFueSxcclxuICBDdXN0b21lclNjaGVtYTxhbnk+XHJcbj5bJ2VuZHBvaW50J11bJ2hhbmRsZXInXSA9IGFzeW5jIChjdHgpID0+IHtcclxuICBjb25zdCB7IHJlcSwgcmVzLCBoYW5kbGVycyB9ID0gY3R4XHJcblxyXG4gIGlmIChcclxuICAgICFpc0FsbG93ZWRPcGVyYXRpb24ocmVxLCByZXMsIHtcclxuICAgICAgR0VUOiBoYW5kbGVyc1snZ2V0TG9nZ2VkSW5DdXN0b21lciddLFxyXG4gICAgfSlcclxuICApIHtcclxuICAgIHJldHVyblxyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGJvZHkgPSBudWxsXHJcbiAgICByZXR1cm4gYXdhaXQgaGFuZGxlcnNbJ2dldExvZ2dlZEluQ3VzdG9tZXInXSh7IC4uLmN0eCwgYm9keSB9KVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKVxyXG5cclxuICAgIGNvbnN0IG1lc3NhZ2UgPVxyXG4gICAgICBlcnJvciBpbnN0YW5jZW9mIENvbW1lcmNlQVBJRXJyb3JcclxuICAgICAgICA/ICdBbiB1bmV4cGVjdGVkIGVycm9yIG9jdXJyZWQgd2l0aCB0aGUgQ29tbWVyY2UgQVBJJ1xyXG4gICAgICAgIDogJ0FuIHVuZXhwZWN0ZWQgZXJyb3Igb2N1cnJlZCdcclxuXHJcbiAgICByZXMuc3RhdHVzKDUwMCkuanNvbih7IGRhdGE6IG51bGwsIGVycm9yczogW3sgbWVzc2FnZSB9XSB9KVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY3VzdG9tZXJFbmRwb2ludFxyXG4iLCJpbXBvcnQgdHlwZSB7IE5leHRBcGlIYW5kbGVyIH0gZnJvbSAnbmV4dCdcclxuaW1wb3J0IHR5cGUgeyBSZXF1ZXN0SW5pdCwgUmVzcG9uc2UgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5pbXBvcnQgdHlwZSB7IEFQSUVuZHBvaW50LCBBUElIYW5kbGVyIH0gZnJvbSAnLi91dGlscy90eXBlcydcclxuaW1wb3J0IHR5cGUgeyBDYXJ0U2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvY2FydCdcclxuaW1wb3J0IHR5cGUgeyBDdXN0b21lclNjaGVtYSB9IGZyb20gJy4uL3R5cGVzL2N1c3RvbWVyJ1xyXG5pbXBvcnQgdHlwZSB7IExvZ2luU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvbG9naW4nXHJcbmltcG9ydCB0eXBlIHsgTG9nb3V0U2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvbG9nb3V0J1xyXG5pbXBvcnQgdHlwZSB7IFNpZ251cFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzL3NpZ251cCdcclxuaW1wb3J0IHR5cGUgeyBQcm9kdWN0c1NjaGVtYSB9IGZyb20gJy4uL3R5cGVzL3Byb2R1Y3QnXHJcbmltcG9ydCB0eXBlIHsgV2lzaGxpc3RTY2hlbWEgfSBmcm9tICcuLi90eXBlcy93aXNobGlzdCdcclxuaW1wb3J0IHR5cGUgeyBDaGVja291dFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzL2NoZWNrb3V0J1xyXG5pbXBvcnQgdHlwZSB7IEN1c3RvbWVyQ2FyZFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzL2N1c3RvbWVyL2NhcmQnXHJcbmltcG9ydCB0eXBlIHsgQ3VzdG9tZXJBZGRyZXNzU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMvY3VzdG9tZXIvYWRkcmVzcydcclxuaW1wb3J0IHtcclxuICBkZWZhdWx0T3BlcmF0aW9ucyxcclxuICBPUEVSQVRJT05TLFxyXG4gIEFsbE9wZXJhdGlvbnMsXHJcbiAgQVBJT3BlcmF0aW9ucyxcclxufSBmcm9tICcuL29wZXJhdGlvbnMnXHJcblxyXG5leHBvcnQgdHlwZSBBUElTY2hlbWFzID1cclxuICB8IENhcnRTY2hlbWFcclxuICB8IEN1c3RvbWVyU2NoZW1hXHJcbiAgfCBMb2dpblNjaGVtYVxyXG4gIHwgTG9nb3V0U2NoZW1hXHJcbiAgfCBTaWdudXBTY2hlbWFcclxuICB8IFByb2R1Y3RzU2NoZW1hXHJcbiAgfCBXaXNobGlzdFNjaGVtYVxyXG4gIHwgQ2hlY2tvdXRTY2hlbWFcclxuICB8IEN1c3RvbWVyQ2FyZFNjaGVtYVxyXG4gIHwgQ3VzdG9tZXJBZGRyZXNzU2NoZW1hXHJcblxyXG5leHBvcnQgdHlwZSBHZXRBUElTY2hlbWE8XHJcbiAgQyBleHRlbmRzIENvbW1lcmNlQVBJPGFueT4sXHJcbiAgUyBleHRlbmRzIEFQSVNjaGVtYXMgPSBBUElTY2hlbWFzXHJcbj4gPSB7XHJcbiAgc2NoZW1hOiBTXHJcbiAgZW5kcG9pbnQ6IEVuZHBvaW50Q29udGV4dDxDLCBTWydlbmRwb2ludCddPlxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBFbmRwb2ludENvbnRleHQ8XHJcbiAgQyBleHRlbmRzIENvbW1lcmNlQVBJLFxyXG4gIEUgZXh0ZW5kcyBFbmRwb2ludFNjaGVtYUJhc2VcclxuPiA9IHtcclxuICBoYW5kbGVyOiBFbmRwb2ludDxDLCBFPlxyXG4gIGhhbmRsZXJzOiBFbmRwb2ludEhhbmRsZXJzPEMsIEU+XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEVuZHBvaW50U2NoZW1hQmFzZSA9IHtcclxuICBvcHRpb25zOiB7fVxyXG4gIGhhbmRsZXJzOiB7XHJcbiAgICBbazogc3RyaW5nXTogeyBkYXRhPzogYW55OyBib2R5PzogYW55IH1cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEVuZHBvaW50PFxyXG4gIEMgZXh0ZW5kcyBDb21tZXJjZUFQSSxcclxuICBFIGV4dGVuZHMgRW5kcG9pbnRTY2hlbWFCYXNlXHJcbj4gPSBBUElFbmRwb2ludDxDLCBFbmRwb2ludEhhbmRsZXJzPEMsIEU+LCBhbnksIEVbJ29wdGlvbnMnXT5cclxuXHJcbmV4cG9ydCB0eXBlIEVuZHBvaW50SGFuZGxlcnM8XHJcbiAgQyBleHRlbmRzIENvbW1lcmNlQVBJLFxyXG4gIEUgZXh0ZW5kcyBFbmRwb2ludFNjaGVtYUJhc2VcclxuPiA9IHtcclxuICBbSCBpbiBrZXlvZiBFWydoYW5kbGVycyddXTogQVBJSGFuZGxlcjxcclxuICAgIEMsXHJcbiAgICBFbmRwb2ludEhhbmRsZXJzPEMsIEU+LFxyXG4gICAgRVsnaGFuZGxlcnMnXVtIXVsnZGF0YSddLFxyXG4gICAgRVsnaGFuZGxlcnMnXVtIXVsnYm9keSddLFxyXG4gICAgRVsnb3B0aW9ucyddXHJcbiAgPlxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBBUElQcm92aWRlciA9IHtcclxuICBjb25maWc6IENvbW1lcmNlQVBJQ29uZmlnXHJcbiAgb3BlcmF0aW9uczogQVBJT3BlcmF0aW9uczxhbnk+XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIENvbW1lcmNlQVBJPFAgZXh0ZW5kcyBBUElQcm92aWRlciA9IEFQSVByb3ZpZGVyPiA9XHJcbiAgQ29tbWVyY2VBUElDb3JlPFA+ICYgQWxsT3BlcmF0aW9uczxQPlxyXG5cclxuZXhwb3J0IGNsYXNzIENvbW1lcmNlQVBJQ29yZTxQIGV4dGVuZHMgQVBJUHJvdmlkZXIgPSBBUElQcm92aWRlcj4ge1xyXG4gIGNvbnN0cnVjdG9yKHJlYWRvbmx5IHByb3ZpZGVyOiBQKSB7fVxyXG5cclxuICBnZXRDb25maWcodXNlckNvbmZpZzogUGFydGlhbDxQWydjb25maWcnXT4gPSB7fSk6IFBbJ2NvbmZpZyddIHtcclxuICAgIHJldHVybiBPYmplY3QuZW50cmllcyh1c2VyQ29uZmlnKS5yZWR1Y2UoXHJcbiAgICAgIChjZmcsIFtrZXksIHZhbHVlXSkgPT4gT2JqZWN0LmFzc2lnbihjZmcsIHsgW2tleV06IHZhbHVlIH0pLFxyXG4gICAgICB7IC4uLnRoaXMucHJvdmlkZXIuY29uZmlnIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIHNldENvbmZpZyhuZXdDb25maWc6IFBhcnRpYWw8UFsnY29uZmlnJ10+KSB7XHJcbiAgICBPYmplY3QuYXNzaWduKHRoaXMucHJvdmlkZXIuY29uZmlnLCBuZXdDb25maWcpXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29tbWVyY2VBcGk8UCBleHRlbmRzIEFQSVByb3ZpZGVyPihcclxuICBjdXN0b21Qcm92aWRlcjogUFxyXG4pOiBDb21tZXJjZUFQSTxQPiB7XHJcbiAgY29uc3QgY29tbWVyY2UgPSBPYmplY3QuYXNzaWduKFxyXG4gICAgbmV3IENvbW1lcmNlQVBJQ29yZShjdXN0b21Qcm92aWRlciksXHJcbiAgICBkZWZhdWx0T3BlcmF0aW9ucyBhcyBBbGxPcGVyYXRpb25zPFA+XHJcbiAgKVxyXG4gIGNvbnN0IG9wcyA9IGN1c3RvbVByb3ZpZGVyLm9wZXJhdGlvbnNcclxuXHJcbiAgT1BFUkFUSU9OUy5mb3JFYWNoKChrKSA9PiB7XHJcbiAgICBjb25zdCBvcCA9IG9wc1trXVxyXG4gICAgaWYgKG9wKSB7XHJcbiAgICAgIGNvbW1lcmNlW2tdID0gb3AoeyBjb21tZXJjZSB9KSBhcyBBbGxPcGVyYXRpb25zPFA+W3R5cGVvZiBrXVxyXG4gICAgfVxyXG4gIH0pXHJcblxyXG4gIHJldHVybiBjb21tZXJjZVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0RW5kcG9pbnQ8XHJcbiAgUCBleHRlbmRzIEFQSVByb3ZpZGVyLFxyXG4gIFQgZXh0ZW5kcyBHZXRBUElTY2hlbWE8YW55LCBhbnk+XHJcbj4oXHJcbiAgY29tbWVyY2U6IENvbW1lcmNlQVBJPFA+LFxyXG4gIGNvbnRleHQ6IFRbJ2VuZHBvaW50J10gJiB7XHJcbiAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgb3B0aW9ucz86IFRbJ3NjaGVtYSddWydlbmRwb2ludCddWydvcHRpb25zJ11cclxuICB9XHJcbik6IE5leHRBcGlIYW5kbGVyIHtcclxuICBjb25zdCBjZmcgPSBjb21tZXJjZS5nZXRDb25maWcoY29udGV4dC5jb25maWcpXHJcblxyXG4gIHJldHVybiBmdW5jdGlvbiBhcGlIYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgICByZXR1cm4gY29udGV4dC5oYW5kbGVyKHtcclxuICAgICAgcmVxLFxyXG4gICAgICByZXMsXHJcbiAgICAgIGNvbW1lcmNlLFxyXG4gICAgICBjb25maWc6IGNmZyxcclxuICAgICAgaGFuZGxlcnM6IGNvbnRleHQuaGFuZGxlcnMsXHJcbiAgICAgIG9wdGlvbnM6IGNvbnRleHQub3B0aW9ucyA/PyB7fSxcclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgY3JlYXRlRW5kcG9pbnQgPVxyXG4gIDxBUEkgZXh0ZW5kcyBHZXRBUElTY2hlbWE8YW55LCBhbnk+PihlbmRwb2ludDogQVBJWydlbmRwb2ludCddKSA9PlxyXG4gIDxQIGV4dGVuZHMgQVBJUHJvdmlkZXI+KFxyXG4gICAgY29tbWVyY2U6IENvbW1lcmNlQVBJPFA+LFxyXG4gICAgY29udGV4dD86IFBhcnRpYWw8QVBJWydlbmRwb2ludCddPiAmIHtcclxuICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgb3B0aW9ucz86IEFQSVsnc2NoZW1hJ11bJ2VuZHBvaW50J11bJ29wdGlvbnMnXVxyXG4gICAgfVxyXG4gICk6IE5leHRBcGlIYW5kbGVyID0+IHtcclxuICAgIHJldHVybiBnZXRFbmRwb2ludChjb21tZXJjZSwgeyAuLi5lbmRwb2ludCwgLi4uY29udGV4dCB9KVxyXG4gIH1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWVyY2VBUElDb25maWcge1xyXG4gIGxvY2FsZT86IHN0cmluZ1xyXG4gIGxvY2FsZXM/OiBzdHJpbmdbXVxyXG4gIGNvbW1lcmNlVXJsOiBzdHJpbmdcclxuICBhcGlUb2tlbjogc3RyaW5nXHJcbiAgY2FydENvb2tpZTogc3RyaW5nXHJcbiAgY2FydENvb2tpZU1heEFnZTogbnVtYmVyXHJcbiAgY3VzdG9tZXJDb29raWU6IHN0cmluZ1xyXG4gIGZldGNoPERhdGEgPSBhbnksIFZhcmlhYmxlcyA9IGFueT4oXHJcbiAgICBxdWVyeTogc3RyaW5nLFxyXG4gICAgcXVlcnlEYXRhPzogQ29tbWVyY2VBUElGZXRjaE9wdGlvbnM8VmFyaWFibGVzPixcclxuICAgIGZldGNoT3B0aW9ucz86IFJlcXVlc3RJbml0XHJcbiAgKTogUHJvbWlzZTxHcmFwaFFMRmV0Y2hlclJlc3VsdDxEYXRhPj5cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgR3JhcGhRTEZldGNoZXI8XHJcbiAgRGF0YSBleHRlbmRzIEdyYXBoUUxGZXRjaGVyUmVzdWx0ID0gR3JhcGhRTEZldGNoZXJSZXN1bHQsXHJcbiAgVmFyaWFibGVzID0gYW55XHJcbj4gPSAoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBxdWVyeURhdGE/OiBDb21tZXJjZUFQSUZldGNoT3B0aW9uczxWYXJpYWJsZXM+LFxyXG4gIGZldGNoT3B0aW9ucz86IFJlcXVlc3RJbml0XHJcbikgPT4gUHJvbWlzZTxEYXRhPlxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBHcmFwaFFMRmV0Y2hlclJlc3VsdDxEYXRhID0gYW55PiB7XHJcbiAgZGF0YTogRGF0YVxyXG4gIHJlczogUmVzcG9uc2VcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDb21tZXJjZUFQSUZldGNoT3B0aW9uczxWYXJpYWJsZXM+IHtcclxuICB2YXJpYWJsZXM/OiBWYXJpYWJsZXNcclxuICBwcmV2aWV3PzogYm9vbGVhblxyXG59XHJcbiIsImltcG9ydCB0eXBlIHsgU2VydmVyUmVzcG9uc2UgfSBmcm9tICdodHRwJ1xyXG5pbXBvcnQgdHlwZSB7IExvZ2luT3BlcmF0aW9uIH0gZnJvbSAnLi4vdHlwZXMvbG9naW4nXHJcbmltcG9ydCB0eXBlIHsgR2V0QWxsUGFnZXNPcGVyYXRpb24sIEdldFBhZ2VPcGVyYXRpb24gfSBmcm9tICcuLi90eXBlcy9wYWdlJ1xyXG5pbXBvcnQgdHlwZSB7IEdldFNpdGVJbmZvT3BlcmF0aW9uIH0gZnJvbSAnLi4vdHlwZXMvc2l0ZSdcclxuaW1wb3J0IHR5cGUgeyBHZXRDdXN0b21lcldpc2hsaXN0T3BlcmF0aW9uIH0gZnJvbSAnLi4vdHlwZXMvd2lzaGxpc3QnXHJcbmltcG9ydCB0eXBlIHtcclxuICBHZXRBbGxQcm9kdWN0UGF0aHNPcGVyYXRpb24sXHJcbiAgR2V0QWxsUHJvZHVjdHNPcGVyYXRpb24sXHJcbiAgR2V0UHJvZHVjdE9wZXJhdGlvbixcclxufSBmcm9tICcuLi90eXBlcy9wcm9kdWN0J1xyXG5pbXBvcnQgdHlwZSB7IEFQSVByb3ZpZGVyLCBDb21tZXJjZUFQSSB9IGZyb20gJy4nXHJcblxyXG5jb25zdCBub29wID0gKCkgPT4ge1xyXG4gIHRocm93IG5ldyBFcnJvcignTm90IGltcGxlbWVudGVkJylcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IE9QRVJBVElPTlMgPSBbXHJcbiAgJ2xvZ2luJyxcclxuICAnZ2V0QWxsUGFnZXMnLFxyXG4gICdnZXRQYWdlJyxcclxuICAnZ2V0U2l0ZUluZm8nLFxyXG4gICdnZXRDdXN0b21lcldpc2hsaXN0JyxcclxuICAnZ2V0QWxsUHJvZHVjdFBhdGhzJyxcclxuICAnZ2V0QWxsUHJvZHVjdHMnLFxyXG4gICdnZXRQcm9kdWN0JyxcclxuXSBhcyBjb25zdFxyXG5cclxuZXhwb3J0IGNvbnN0IGRlZmF1bHRPcGVyYXRpb25zID0gT1BFUkFUSU9OUy5yZWR1Y2UoKG9wcywgaykgPT4ge1xyXG4gIG9wc1trXSA9IG5vb3BcclxuICByZXR1cm4gb3BzXHJcbn0sIHt9IGFzIHsgW0sgaW4gQWxsb3dlZE9wZXJhdGlvbnNdOiB0eXBlb2Ygbm9vcCB9KVxyXG5cclxuZXhwb3J0IHR5cGUgQWxsb3dlZE9wZXJhdGlvbnMgPSB0eXBlb2YgT1BFUkFUSU9OU1tudW1iZXJdXHJcblxyXG5leHBvcnQgdHlwZSBPcGVyYXRpb25zPFAgZXh0ZW5kcyBBUElQcm92aWRlcj4gPSB7XHJcbiAgbG9naW46IHtcclxuICAgIDxUIGV4dGVuZHMgTG9naW5PcGVyYXRpb24+KG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICByZXM6IFNlcnZlclJlc3BvbnNlXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBMb2dpbk9wZXJhdGlvbj4oXHJcbiAgICAgIG9wdHM6IHtcclxuICAgICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICByZXM6IFNlcnZlclJlc3BvbnNlXHJcbiAgICAgIH0gJiBPcGVyYXRpb25PcHRpb25zXHJcbiAgICApOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuICB9XHJcblxyXG4gIGdldEFsbFBhZ2VzOiB7XHJcbiAgICA8VCBleHRlbmRzIEdldEFsbFBhZ2VzT3BlcmF0aW9uPihvcHRzPzoge1xyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUGFnZXNPcGVyYXRpb24+KFxyXG4gICAgICBvcHRzOiB7XHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRQYWdlOiB7XHJcbiAgICA8VCBleHRlbmRzIEdldFBhZ2VPcGVyYXRpb24+KG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0UGFnZU9wZXJhdGlvbj4oXHJcbiAgICAgIG9wdHM6IHtcclxuICAgICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRTaXRlSW5mbzoge1xyXG4gICAgPFQgZXh0ZW5kcyBHZXRTaXRlSW5mb09wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0U2l0ZUluZm9PcGVyYXRpb24+KFxyXG4gICAgICBvcHRzOiB7XHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRDdXN0b21lcldpc2hsaXN0OiB7XHJcbiAgICA8VCBleHRlbmRzIEdldEN1c3RvbWVyV2lzaGxpc3RPcGVyYXRpb24+KG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBpbmNsdWRlUHJvZHVjdHM/OiBib29sZWFuXHJcbiAgICB9KTogUHJvbWlzZTxUWydkYXRhJ10+XHJcblxyXG4gICAgPFQgZXh0ZW5kcyBHZXRDdXN0b21lcldpc2hsaXN0T3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlczogVFsndmFyaWFibGVzJ11cclxuICAgICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICAgIGluY2x1ZGVQcm9kdWN0cz86IGJvb2xlYW5cclxuICAgICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICAgICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG4gIH1cclxuXHJcbiAgZ2V0QWxsUHJvZHVjdFBhdGhzOiB7XHJcbiAgICA8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RQYXRoc09wZXJhdGlvbj4ob3B0czoge1xyXG4gICAgICB2YXJpYWJsZXM/OiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdFBhdGhzT3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgfSAmIE9wZXJhdGlvbk9wdGlvbnNcclxuICAgICk6IFByb21pc2U8VFsnZGF0YSddPlxyXG4gIH1cclxuXHJcbiAgZ2V0QWxsUHJvZHVjdHM6IHtcclxuICAgIDxUIGV4dGVuZHMgR2V0QWxsUHJvZHVjdHNPcGVyYXRpb24+KG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzPzogVFsndmFyaWFibGVzJ11cclxuICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgcHJldmlldz86IGJvb2xlYW5cclxuICAgIH0pOiBQcm9taXNlPFRbJ2RhdGEnXT5cclxuXHJcbiAgICA8VCBleHRlbmRzIEdldEFsbFByb2R1Y3RzT3BlcmF0aW9uPihcclxuICAgICAgb3B0czoge1xyXG4gICAgICAgIHZhcmlhYmxlcz86IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG5cclxuICBnZXRQcm9kdWN0OiB7XHJcbiAgICA8VCBleHRlbmRzIEdldFByb2R1Y3RPcGVyYXRpb24+KG9wdHM6IHtcclxuICAgICAgdmFyaWFibGVzOiBUWyd2YXJpYWJsZXMnXVxyXG4gICAgICBjb25maWc/OiBQWydjb25maWcnXVxyXG4gICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgfSk6IFByb21pc2U8VFsnZGF0YSddPlxyXG5cclxuICAgIDxUIGV4dGVuZHMgR2V0UHJvZHVjdE9wZXJhdGlvbj4oXHJcbiAgICAgIG9wdHM6IHtcclxuICAgICAgICB2YXJpYWJsZXM6IFRbJ3ZhcmlhYmxlcyddXHJcbiAgICAgICAgY29uZmlnPzogUFsnY29uZmlnJ11cclxuICAgICAgICBwcmV2aWV3PzogYm9vbGVhblxyXG4gICAgICB9ICYgT3BlcmF0aW9uT3B0aW9uc1xyXG4gICAgKTogUHJvbWlzZTxUWydkYXRhJ10+XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBBUElPcGVyYXRpb25zPFAgZXh0ZW5kcyBBUElQcm92aWRlcj4gPSB7XHJcbiAgW0sgaW4ga2V5b2YgT3BlcmF0aW9uczxQPl0/OiAoY3R4OiBPcGVyYXRpb25Db250ZXh0PFA+KSA9PiBPcGVyYXRpb25zPFA+W0tdXHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIEFsbE9wZXJhdGlvbnM8UCBleHRlbmRzIEFQSVByb3ZpZGVyPiA9IHtcclxuICBbSyBpbiBrZXlvZiBBUElPcGVyYXRpb25zPFA+XS0/OiBQWydvcGVyYXRpb25zJ11bS10gZXh0ZW5kcyAoXHJcbiAgICAuLi5hcmdzOiBhbnlcclxuICApID0+IGFueVxyXG4gICAgPyBSZXR1cm5UeXBlPFBbJ29wZXJhdGlvbnMnXVtLXT5cclxuICAgIDogdHlwZW9mIG5vb3BcclxufVxyXG5cclxuZXhwb3J0IHR5cGUgT3BlcmF0aW9uQ29udGV4dDxQIGV4dGVuZHMgQVBJUHJvdmlkZXI+ID0ge1xyXG4gIGNvbW1lcmNlOiBDb21tZXJjZUFQSTxQPlxyXG59XHJcblxyXG5leHBvcnQgdHlwZSBPcGVyYXRpb25PcHRpb25zID1cclxuICB8IHsgcXVlcnk6IHN0cmluZzsgdXJsPzogbmV2ZXIgfVxyXG4gIHwgeyBxdWVyeT86IG5ldmVyOyB1cmw6IHN0cmluZyB9XHJcbiIsImltcG9ydCB0eXBlIHsgUmVzcG9uc2UgfSBmcm9tICdAdmVyY2VsL2ZldGNoJ1xyXG5cclxuZXhwb3J0IGNsYXNzIENvbW1lcmNlQVBJRXJyb3IgZXh0ZW5kcyBFcnJvciB7XHJcbiAgc3RhdHVzOiBudW1iZXJcclxuICByZXM6IFJlc3BvbnNlXHJcbiAgZGF0YTogYW55XHJcblxyXG4gIGNvbnN0cnVjdG9yKG1zZzogc3RyaW5nLCByZXM6IFJlc3BvbnNlLCBkYXRhPzogYW55KSB7XHJcbiAgICBzdXBlcihtc2cpXHJcbiAgICB0aGlzLm5hbWUgPSAnQ29tbWVyY2VBcGlFcnJvcidcclxuICAgIHRoaXMuc3RhdHVzID0gcmVzLnN0YXR1c1xyXG4gICAgdGhpcy5yZXMgPSByZXNcclxuICAgIHRoaXMuZGF0YSA9IGRhdGFcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBDb21tZXJjZU5ldHdvcmtFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBjb25zdHJ1Y3Rvcihtc2c6IHN0cmluZykge1xyXG4gICAgc3VwZXIobXNnKVxyXG4gICAgdGhpcy5uYW1lID0gJ0NvbW1lcmNlTmV0d29ya0Vycm9yJ1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tICduZXh0J1xyXG5cclxuZXhwb3J0IHR5cGUgSFRUUF9NRVRIT0RTID0gJ09QVElPTlMnIHwgJ0dFVCcgfCAnUE9TVCcgfCAnUFVUJyB8ICdERUxFVEUnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc0FsbG93ZWRNZXRob2QoXHJcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcclxuICByZXM6IE5leHRBcGlSZXNwb25zZSxcclxuICBhbGxvd2VkTWV0aG9kczogSFRUUF9NRVRIT0RTW11cclxuKSB7XHJcbiAgY29uc3QgbWV0aG9kcyA9IGFsbG93ZWRNZXRob2RzLmluY2x1ZGVzKCdPUFRJT05TJylcclxuICAgID8gYWxsb3dlZE1ldGhvZHNcclxuICAgIDogWy4uLmFsbG93ZWRNZXRob2RzLCAnT1BUSU9OUyddXHJcblxyXG4gIGlmICghcmVxLm1ldGhvZCB8fCAhbWV0aG9kcy5pbmNsdWRlcyhyZXEubWV0aG9kKSkge1xyXG4gICAgcmVzLnN0YXR1cyg0MDUpXHJcbiAgICByZXMuc2V0SGVhZGVyKCdBbGxvdycsIG1ldGhvZHMuam9pbignLCAnKSlcclxuICAgIHJlcy5lbmQoKVxyXG4gICAgcmV0dXJuIGZhbHNlXHJcbiAgfVxyXG5cclxuICBpZiAocmVxLm1ldGhvZCA9PT0gJ09QVElPTlMnKSB7XHJcbiAgICByZXMuc3RhdHVzKDIwMClcclxuICAgIHJlcy5zZXRIZWFkZXIoJ0FsbG93JywgbWV0aG9kcy5qb2luKCcsICcpKVxyXG4gICAgcmVzLnNldEhlYWRlcignQ29udGVudC1MZW5ndGgnLCAnMCcpXHJcbiAgICByZXMuZW5kKClcclxuICAgIHJldHVybiBmYWxzZVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHRydWVcclxufVxyXG4iLCJpbXBvcnQgdHlwZSB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tICduZXh0J1xyXG5pbXBvcnQgaXNBbGxvd2VkTWV0aG9kLCB7IEhUVFBfTUVUSE9EUyB9IGZyb20gJy4vaXMtYWxsb3dlZC1tZXRob2QnXHJcbmltcG9ydCB7IEFQSUhhbmRsZXIgfSBmcm9tICcuL3R5cGVzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNBbGxvd2VkT3BlcmF0aW9uKFxyXG4gIHJlcTogTmV4dEFwaVJlcXVlc3QsXHJcbiAgcmVzOiBOZXh0QXBpUmVzcG9uc2UsXHJcbiAgYWxsb3dlZE9wZXJhdGlvbnM6IHsgW2sgaW4gSFRUUF9NRVRIT0RTXT86IEFQSUhhbmRsZXI8YW55LCBhbnk+IH1cclxuKSB7XHJcbiAgY29uc3QgbWV0aG9kcyA9IE9iamVjdC5rZXlzKGFsbG93ZWRPcGVyYXRpb25zKSBhcyBIVFRQX01FVEhPRFNbXVxyXG4gIGNvbnN0IGFsbG93ZWRNZXRob2RzID0gbWV0aG9kcy5yZWR1Y2U8SFRUUF9NRVRIT0RTW10+KChhcnIsIG1ldGhvZCkgPT4ge1xyXG4gICAgaWYgKGFsbG93ZWRPcGVyYXRpb25zW21ldGhvZF0pIHtcclxuICAgICAgYXJyLnB1c2gobWV0aG9kKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGFyclxyXG4gIH0sIFtdKVxyXG5cclxuICByZXR1cm4gaXNBbGxvd2VkTWV0aG9kKHJlcSwgcmVzLCBhbGxvd2VkTWV0aG9kcylcclxufVxyXG4iLCJleHBvcnQgdHlwZSBFcnJvckRhdGEgPSB7XHJcbiAgbWVzc2FnZTogc3RyaW5nXHJcbiAgY29kZT86IHN0cmluZ1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBFcnJvclByb3BzID0ge1xyXG4gIGNvZGU/OiBzdHJpbmdcclxufSAmIChcclxuICB8IHsgbWVzc2FnZTogc3RyaW5nOyBlcnJvcnM/OiBuZXZlciB9XHJcbiAgfCB7IG1lc3NhZ2U/OiBuZXZlcjsgZXJyb3JzOiBFcnJvckRhdGFbXSB9XHJcbilcclxuXHJcbmV4cG9ydCBjbGFzcyBDb21tZXJjZUVycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIGNvZGU/OiBzdHJpbmdcclxuICBlcnJvcnM6IEVycm9yRGF0YVtdXHJcblxyXG4gIGNvbnN0cnVjdG9yKHsgbWVzc2FnZSwgY29kZSwgZXJyb3JzIH06IEVycm9yUHJvcHMpIHtcclxuICAgIGNvbnN0IGVycm9yOiBFcnJvckRhdGEgPSBtZXNzYWdlXHJcbiAgICAgID8geyBtZXNzYWdlLCAuLi4oY29kZSA/IHsgY29kZSB9IDoge30pIH1cclxuICAgICAgOiBlcnJvcnMhWzBdXHJcblxyXG4gICAgc3VwZXIoZXJyb3IubWVzc2FnZSlcclxuICAgIHRoaXMuZXJyb3JzID0gbWVzc2FnZSA/IFtlcnJvcl0gOiBlcnJvcnMhXHJcblxyXG4gICAgaWYgKGVycm9yLmNvZGUpIHRoaXMuY29kZSA9IGVycm9yLmNvZGVcclxuICB9XHJcbn1cclxuXHJcbi8vIFVzZWQgZm9yIGVycm9ycyB0aGF0IGNvbWUgZnJvbSBhIGJhZCBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgaG9va3NcclxuZXhwb3J0IGNsYXNzIFZhbGlkYXRpb25FcnJvciBleHRlbmRzIENvbW1lcmNlRXJyb3Ige1xyXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnM6IEVycm9yUHJvcHMpIHtcclxuICAgIHN1cGVyKG9wdGlvbnMpXHJcbiAgICB0aGlzLmNvZGUgPSAndmFsaWRhdGlvbl9lcnJvcidcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBGZXRjaGVyRXJyb3IgZXh0ZW5kcyBDb21tZXJjZUVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlclxyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIG9wdGlvbnM6IHtcclxuICAgICAgc3RhdHVzOiBudW1iZXJcclxuICAgIH0gJiBFcnJvclByb3BzXHJcbiAgKSB7XHJcbiAgICBzdXBlcihvcHRpb25zKVxyXG4gICAgdGhpcy5zdGF0dXMgPSBvcHRpb25zLnN0YXR1c1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBnZXRDb21tZXJjZUFwaSB9IGZyb20gJ0BmcmFtZXdvcmsvYXBpJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZ2V0Q29tbWVyY2VBcGkoKVxyXG4iLCJpbXBvcnQgY3VzdG9tZXJBcGkgZnJvbSAnQGZyYW1ld29yay9hcGkvZW5kcG9pbnRzL2N1c3RvbWVyJ1xyXG5pbXBvcnQgY29tbWVyY2UgZnJvbSAnQGxpYi9hcGkvY29tbWVyY2UnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjdXN0b21lckFwaShjb21tZXJjZSlcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQHZlcmNlbC9mZXRjaFwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiaW1tdXRhYmlsaXR5LWhlbHBlclwiKTs7Il0sInNvdXJjZVJvb3QiOiIifQ==