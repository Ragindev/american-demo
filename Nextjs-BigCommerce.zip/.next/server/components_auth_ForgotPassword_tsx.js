exports.id = "components_auth_ForgotPassword_tsx";
exports.ids = ["components_auth_ForgotPassword_tsx"];
exports.modules = {

/***/ "./components/auth/ForgotPassword.tsx":
/*!********************************************!*\
  !*** ./components/auth/ForgotPassword.tsx ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! email-validator */ "email-validator");
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(email_validator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/ui/context */ "./components/ui/context.tsx");
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/ui */ "./components/ui/index.ts");

var _jsxFileName = "D:\\RAGIN\\AT\\Nextjs-BigCommerce\\components\\auth\\ForgotPassword.tsx";





const ForgotPassword = () => {
  // Form State
  const {
    0: email,
    1: setEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: message,
    1: setMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: dirty,
    1: setDirty
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: disabled,
    1: setDisabled
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    setModalView,
    closeModal
  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_3__.useUI)();

  const handleResetPassword = async e => {
    e.preventDefault();

    if (!dirty && !disabled) {
      setDirty(true);
      handleValidation();
    }
  };

  const handleValidation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
    // Unable to send form unless fields are valid.
    if (dirty) {
      setDisabled(!(0,email_validator__WEBPACK_IMPORTED_MODULE_2__.validate)(email));
    }
  }, [email, dirty]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    handleValidation();
  }, [handleValidation]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("form", {
    onSubmit: handleResetPassword,
    className: "w-80 flex flex-col justify-between p-3",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex justify-center pb-12 ",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_4__.Logo, {
        width: "64px",
        height: "64px"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex flex-col space-y-4",
      children: [message && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-red border border-red p-3",
        children: message
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 11
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_4__.Input, {
        placeholder: "Email",
        onChange: setEmail,
        type: "email"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "pt-2 w-full flex flex-col",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_4__.Button, {
          variant: "slim",
          type: "submit",
          loading: loading,
          disabled: disabled,
          children: "Recover Password"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "pt-3 text-center text-sm",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
          className: "text-accent-7",
          children: "Do you have an account?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined), ` `, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: "text-accent-9 font-bold hover:underline cursor-pointer",
          onClick: () => setModalView('LOGIN_VIEW'),
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ForgotPassword);

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtY29tbWVyY2UvLi9jb21wb25lbnRzL2F1dGgvRm9yZ290UGFzc3dvcmQudHN4Il0sIm5hbWVzIjpbIkZvcmdvdFBhc3N3b3JkIiwiZW1haWwiLCJzZXRFbWFpbCIsInVzZVN0YXRlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsImRpcnR5Iiwic2V0RGlydHkiLCJkaXNhYmxlZCIsInNldERpc2FibGVkIiwic2V0TW9kYWxWaWV3IiwiY2xvc2VNb2RhbCIsInVzZVVJIiwiaGFuZGxlUmVzZXRQYXNzd29yZCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZVZhbGlkYXRpb24iLCJ1c2VDYWxsYmFjayIsInZhbGlkYXRlIiwidXNlRWZmZWN0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUEsY0FBeUIsR0FBRyxNQUFNO0FBQ3RDO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CQywrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0JGLCtDQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDRyxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QkosK0NBQVEsQ0FBQyxFQUFELENBQXRDO0FBQ0EsUUFBTTtBQUFBLE9BQUNLLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CTiwrQ0FBUSxDQUFDLEtBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ08sUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJSLCtDQUFRLENBQUMsS0FBRCxDQUF4QztBQUVBLFFBQU07QUFBRVMsZ0JBQUY7QUFBZ0JDO0FBQWhCLE1BQStCQyw2REFBSyxFQUExQzs7QUFFQSxRQUFNQyxtQkFBbUIsR0FBRyxNQUFPQyxDQUFQLElBQWdEO0FBQzFFQSxLQUFDLENBQUNDLGNBQUY7O0FBRUEsUUFBSSxDQUFDVCxLQUFELElBQVUsQ0FBQ0UsUUFBZixFQUF5QjtBQUN2QkQsY0FBUSxDQUFDLElBQUQsQ0FBUjtBQUNBUyxzQkFBZ0I7QUFDakI7QUFDRixHQVBEOztBQVNBLFFBQU1BLGdCQUFnQixHQUFHQyxrREFBVyxDQUFDLE1BQU07QUFDekM7QUFDQSxRQUFJWCxLQUFKLEVBQVc7QUFDVEcsaUJBQVcsQ0FBQyxDQUFDUyx5REFBUSxDQUFDbkIsS0FBRCxDQUFWLENBQVg7QUFDRDtBQUNGLEdBTG1DLEVBS2pDLENBQUNBLEtBQUQsRUFBUU8sS0FBUixDQUxpQyxDQUFwQztBQU9BYSxrREFBUyxDQUFDLE1BQU07QUFDZEgsb0JBQWdCO0FBQ2pCLEdBRlEsRUFFTixDQUFDQSxnQkFBRCxDQUZNLENBQVQ7QUFJQSxzQkFDRTtBQUNFLFlBQVEsRUFBRUgsbUJBRFo7QUFFRSxhQUFTLEVBQUMsd0NBRlo7QUFBQSw0QkFJRTtBQUFLLGVBQVMsRUFBQyw0QkFBZjtBQUFBLDZCQUNFLDhEQUFDLGdEQUFEO0FBQU0sYUFBSyxFQUFDLE1BQVo7QUFBbUIsY0FBTSxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBT0U7QUFBSyxlQUFTLEVBQUMseUJBQWY7QUFBQSxpQkFDR1QsT0FBTyxpQkFDTjtBQUFLLGlCQUFTLEVBQUMsZ0NBQWY7QUFBQSxrQkFBaURBO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFLRSw4REFBQyxpREFBRDtBQUFPLG1CQUFXLEVBQUMsT0FBbkI7QUFBMkIsZ0JBQVEsRUFBRUosUUFBckM7QUFBK0MsWUFBSSxFQUFDO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEYsZUFNRTtBQUFLLGlCQUFTLEVBQUMsMkJBQWY7QUFBQSwrQkFDRSw4REFBQyxrREFBRDtBQUNFLGlCQUFPLEVBQUMsTUFEVjtBQUVFLGNBQUksRUFBQyxRQUZQO0FBR0UsaUJBQU8sRUFBRUUsT0FIWDtBQUlFLGtCQUFRLEVBQUVNLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GLGVBaUJFO0FBQU0saUJBQVMsRUFBQywwQkFBaEI7QUFBQSxnQ0FDRTtBQUFNLG1CQUFTLEVBQUMsZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsRUFFSSxHQUZKLGVBR0U7QUFDRSxtQkFBUyxFQUFDLHdEQURaO0FBRUUsaUJBQU8sRUFBRSxNQUFNRSxZQUFZLENBQUMsWUFBRCxDQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXNDRCxDQXBFRDs7QUFzRUEsK0RBQWVaLGNBQWYsRSIsImZpbGUiOiJjb21wb25lbnRzX2F1dGhfRm9yZ290UGFzc3dvcmRfdHN4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRkMsIHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHZhbGlkYXRlIH0gZnJvbSAnZW1haWwtdmFsaWRhdG9yJ1xyXG5pbXBvcnQgeyB1c2VVSSB9IGZyb20gJ0Bjb21wb25lbnRzL3VpL2NvbnRleHQnXHJcbmltcG9ydCB7IExvZ28sIEJ1dHRvbiwgSW5wdXQgfSBmcm9tICdAY29tcG9uZW50cy91aSdcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7fVxyXG5cclxuY29uc3QgRm9yZ290UGFzc3dvcmQ6IEZDPFByb3BzPiA9ICgpID0+IHtcclxuICAvLyBGb3JtIFN0YXRlXHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZGlydHksIHNldERpcnR5XSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtkaXNhYmxlZCwgc2V0RGlzYWJsZWRdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IHsgc2V0TW9kYWxWaWV3LCBjbG9zZU1vZGFsIH0gPSB1c2VVSSgpXHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlc2V0UGFzc3dvcmQgPSBhc3luYyAoZTogUmVhY3QuU3ludGhldGljRXZlbnQ8RXZlbnRUYXJnZXQ+KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KClcclxuXHJcbiAgICBpZiAoIWRpcnR5ICYmICFkaXNhYmxlZCkge1xyXG4gICAgICBzZXREaXJ0eSh0cnVlKVxyXG4gICAgICBoYW5kbGVWYWxpZGF0aW9uKClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZhbGlkYXRpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XHJcbiAgICAvLyBVbmFibGUgdG8gc2VuZCBmb3JtIHVubGVzcyBmaWVsZHMgYXJlIHZhbGlkLlxyXG4gICAgaWYgKGRpcnR5KSB7XHJcbiAgICAgIHNldERpc2FibGVkKCF2YWxpZGF0ZShlbWFpbCkpXHJcbiAgICB9XHJcbiAgfSwgW2VtYWlsLCBkaXJ0eV0pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVWYWxpZGF0aW9uKClcclxuICB9LCBbaGFuZGxlVmFsaWRhdGlvbl0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybVxyXG4gICAgICBvblN1Ym1pdD17aGFuZGxlUmVzZXRQYXNzd29yZH1cclxuICAgICAgY2xhc3NOYW1lPVwidy04MCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTNcIlxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcGItMTIgXCI+XHJcbiAgICAgICAgPExvZ28gd2lkdGg9XCI2NHB4XCIgaGVpZ2h0PVwiNjRweFwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc3BhY2UteS00XCI+XHJcbiAgICAgICAge21lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZCBib3JkZXIgYm9yZGVyLXJlZCBwLTNcIj57bWVzc2FnZX08L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJFbWFpbFwiIG9uQ2hhbmdlPXtzZXRFbWFpbH0gdHlwZT1cImVtYWlsXCIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgdy1mdWxsIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cInNsaW1cIlxyXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBSZWNvdmVyIFBhc3N3b3JkXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHQtMyB0ZXh0LWNlbnRlciB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudC03XCI+RG8geW91IGhhdmUgYW4gYWNjb3VudD88L3NwYW4+XHJcbiAgICAgICAgICB7YCBgfVxyXG4gICAgICAgICAgPGFcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtOSBmb250LWJvbGQgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kYWxWaWV3KCdMT0dJTl9WSUVXJyl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIExvZyBJblxyXG4gICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Zvcm0+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb3Jnb3RQYXNzd29yZFxyXG4iXSwic291cmNlUm9vdCI6IiJ9