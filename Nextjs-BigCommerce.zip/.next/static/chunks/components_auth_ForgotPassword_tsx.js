(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([["components_auth_ForgotPassword_tsx"],{

/***/ "./components/auth/ForgotPassword.tsx":
/*!********************************************!*\
  !*** ./components/auth/ForgotPassword.tsx ***!
  \********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! email-validator */ "./node_modules/email-validator/index.js");
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/ui/context */ "./components/ui/context.tsx");
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @components/ui */ "./components/ui/index.ts");
/* module decorator */ module = __webpack_require__.hmd(module);




var _jsxFileName = "D:\\RAGIN\\AT\\Nextjs-BigCommerce\\components\\auth\\ForgotPassword.tsx",
    _this = undefined,
    _s = $RefreshSig$();






var ForgotPassword = function ForgotPassword() {
  _s();

  // Form State
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(''),
      email = _useState[0],
      setEmail = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      loading = _useState2[0],
      setLoading = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(''),
      message = _useState3[0],
      setMessage = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      dirty = _useState4[0],
      setDirty = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      disabled = _useState5[0],
      setDisabled = _useState5[1];

  var _useUI = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_5__.useUI)(),
      setModalView = _useUI.setModalView,
      closeModal = _useUI.closeModal;

  var handleResetPassword = /*#__PURE__*/function () {
    var _ref = (0,D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__.default)( /*#__PURE__*/D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(e) {
      return D_RAGIN_AT_Nextjs_BigCommerce_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              e.preventDefault();

              if (!dirty && !disabled) {
                setDirty(true);
                handleValidation();
              }

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function handleResetPassword(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var handleValidation = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(function () {
    // Unable to send form unless fields are valid.
    if (dirty) {
      setDisabled(!(0,email_validator__WEBPACK_IMPORTED_MODULE_4__.validate)(email));
    }
  }, [email, dirty]);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    handleValidation();
  }, [handleValidation]);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("form", {
    onSubmit: handleResetPassword,
    className: "w-80 flex flex-col justify-between p-3",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex justify-center pb-12 ",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_6__.Logo, {
        width: "64px",
        height: "64px"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex flex-col space-y-4",
      children: [message && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-red border border-red p-3",
        children: message
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 11
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_6__.Input, {
        placeholder: "Email",
        onChange: setEmail,
        type: "email"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "pt-2 w-full flex flex-col",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_ui__WEBPACK_IMPORTED_MODULE_6__.Button, {
          variant: "slim",
          type: "submit",
          loading: loading,
          disabled: disabled,
          children: "Recover Password"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "pt-3 text-center text-sm",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
          className: "text-accent-7",
          children: "Do you have an account?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, _this), " ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: "text-accent-9 font-bold hover:underline cursor-pointer",
          onClick: function onClick() {
            return setModalView('LOGIN_VIEW');
          },
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 5
  }, _this);
};

_s(ForgotPassword, "jnbu9ek9RhfKC9JTyL4j1VlOrxw=", false, function () {
  return [_components_ui_context__WEBPACK_IMPORTED_MODULE_5__.useUI];
});

_c = ForgotPassword;
/* harmony default export */ __webpack_exports__["default"] = (ForgotPassword);

var _c;

$RefreshReg$(_c, "ForgotPassword");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9hdXRoL0ZvcmdvdFBhc3N3b3JkLnRzeCJdLCJuYW1lcyI6WyJGb3Jnb3RQYXNzd29yZCIsInVzZVN0YXRlIiwiZW1haWwiLCJzZXRFbWFpbCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJkaXJ0eSIsInNldERpcnR5IiwiZGlzYWJsZWQiLCJzZXREaXNhYmxlZCIsInVzZVVJIiwic2V0TW9kYWxWaWV3IiwiY2xvc2VNb2RhbCIsImhhbmRsZVJlc2V0UGFzc3dvcmQiLCJlIiwicHJldmVudERlZmF1bHQiLCJoYW5kbGVWYWxpZGF0aW9uIiwidXNlQ2FsbGJhY2siLCJ2YWxpZGF0ZSIsInVzZUVmZmVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxJQUFNQSxjQUF5QixHQUFHLFNBQTVCQSxjQUE0QixHQUFNO0FBQUE7O0FBQ3RDO0FBRHNDLGtCQUVaQywrQ0FBUSxDQUFDLEVBQUQsQ0FGSTtBQUFBLE1BRS9CQyxLQUYrQjtBQUFBLE1BRXhCQyxRQUZ3Qjs7QUFBQSxtQkFHUkYsK0NBQVEsQ0FBQyxLQUFELENBSEE7QUFBQSxNQUcvQkcsT0FIK0I7QUFBQSxNQUd0QkMsVUFIc0I7O0FBQUEsbUJBSVJKLCtDQUFRLENBQUMsRUFBRCxDQUpBO0FBQUEsTUFJL0JLLE9BSitCO0FBQUEsTUFJdEJDLFVBSnNCOztBQUFBLG1CQUtaTiwrQ0FBUSxDQUFDLEtBQUQsQ0FMSTtBQUFBLE1BSy9CTyxLQUwrQjtBQUFBLE1BS3hCQyxRQUx3Qjs7QUFBQSxtQkFNTlIsK0NBQVEsQ0FBQyxLQUFELENBTkY7QUFBQSxNQU0vQlMsUUFOK0I7QUFBQSxNQU1yQkMsV0FOcUI7O0FBQUEsZUFRREMsNkRBQUssRUFSSjtBQUFBLE1BUTlCQyxZQVI4QixVQVE5QkEsWUFSOEI7QUFBQSxNQVFoQkMsVUFSZ0IsVUFRaEJBLFVBUmdCOztBQVV0QyxNQUFNQyxtQkFBbUI7QUFBQSxpVEFBRyxpQkFBT0MsQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzFCQSxlQUFDLENBQUNDLGNBQUY7O0FBRUEsa0JBQUksQ0FBQ1QsS0FBRCxJQUFVLENBQUNFLFFBQWYsRUFBeUI7QUFDdkJELHdCQUFRLENBQUMsSUFBRCxDQUFSO0FBQ0FTLGdDQUFnQjtBQUNqQjs7QUFOeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBbkJILG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxLQUF6Qjs7QUFTQSxNQUFNRyxnQkFBZ0IsR0FBR0Msa0RBQVcsQ0FBQyxZQUFNO0FBQ3pDO0FBQ0EsUUFBSVgsS0FBSixFQUFXO0FBQ1RHLGlCQUFXLENBQUMsQ0FBQ1MseURBQVEsQ0FBQ2xCLEtBQUQsQ0FBVixDQUFYO0FBQ0Q7QUFDRixHQUxtQyxFQUtqQyxDQUFDQSxLQUFELEVBQVFNLEtBQVIsQ0FMaUMsQ0FBcEM7QUFPQWEsa0RBQVMsQ0FBQyxZQUFNO0FBQ2RILG9CQUFnQjtBQUNqQixHQUZRLEVBRU4sQ0FBQ0EsZ0JBQUQsQ0FGTSxDQUFUO0FBSUEsc0JBQ0U7QUFDRSxZQUFRLEVBQUVILG1CQURaO0FBRUUsYUFBUyxFQUFDLHdDQUZaO0FBQUEsNEJBSUU7QUFBSyxlQUFTLEVBQUMsNEJBQWY7QUFBQSw2QkFDRSw4REFBQyxnREFBRDtBQUFNLGFBQUssRUFBQyxNQUFaO0FBQW1CLGNBQU0sRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUpGLGVBT0U7QUFBSyxlQUFTLEVBQUMseUJBQWY7QUFBQSxpQkFDR1QsT0FBTyxpQkFDTjtBQUFLLGlCQUFTLEVBQUMsZ0NBQWY7QUFBQSxrQkFBaURBO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGSixlQUtFLDhEQUFDLGlEQUFEO0FBQU8sbUJBQVcsRUFBQyxPQUFuQjtBQUEyQixnQkFBUSxFQUFFSCxRQUFyQztBQUErQyxZQUFJLEVBQUM7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUxGLGVBTUU7QUFBSyxpQkFBUyxFQUFDLDJCQUFmO0FBQUEsK0JBQ0UsOERBQUMsa0RBQUQ7QUFDRSxpQkFBTyxFQUFDLE1BRFY7QUFFRSxjQUFJLEVBQUMsUUFGUDtBQUdFLGlCQUFPLEVBQUVDLE9BSFg7QUFJRSxrQkFBUSxFQUFFTSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU5GLGVBaUJFO0FBQU0saUJBQVMsRUFBQywwQkFBaEI7QUFBQSxnQ0FDRTtBQUFNLG1CQUFTLEVBQUMsZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsb0JBR0U7QUFDRSxtQkFBUyxFQUFDLHdEQURaO0FBRUUsaUJBQU8sRUFBRTtBQUFBLG1CQUFNRyxZQUFZLENBQUMsWUFBRCxDQUFsQjtBQUFBLFdBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBc0NELENBcEVEOztHQUFNYixjO1VBUWlDWSx5RDs7O0tBUmpDWixjO0FBc0VOLCtEQUFlQSxjQUFmIiwiZmlsZSI6InN0YXRpYy9jaHVua3MvY29tcG9uZW50c19hdXRoX0ZvcmdvdFBhc3N3b3JkX3RzeC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZDLCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB2YWxpZGF0ZSB9IGZyb20gJ2VtYWlsLXZhbGlkYXRvcidcclxuaW1wb3J0IHsgdXNlVUkgfSBmcm9tICdAY29tcG9uZW50cy91aS9jb250ZXh0J1xyXG5pbXBvcnQgeyBMb2dvLCBCdXR0b24sIElucHV0IH0gZnJvbSAnQGNvbXBvbmVudHMvdWknXHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge31cclxuXHJcbmNvbnN0IEZvcmdvdFBhc3N3b3JkOiBGQzxQcm9wcz4gPSAoKSA9PiB7XHJcbiAgLy8gRm9ybSBTdGF0ZVxyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2RpcnR5LCBzZXREaXJ0eV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbZGlzYWJsZWQsIHNldERpc2FibGVkXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG5cclxuICBjb25zdCB7IHNldE1vZGFsVmlldywgY2xvc2VNb2RhbCB9ID0gdXNlVUkoKVxyXG5cclxuICBjb25zdCBoYW5kbGVSZXNldFBhc3N3b3JkID0gYXN5bmMgKGU6IFJlYWN0LlN5bnRoZXRpY0V2ZW50PEV2ZW50VGFyZ2V0PikgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXHJcblxyXG4gICAgaWYgKCFkaXJ0eSAmJiAhZGlzYWJsZWQpIHtcclxuICAgICAgc2V0RGlydHkodHJ1ZSlcclxuICAgICAgaGFuZGxlVmFsaWRhdGlvbigpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVWYWxpZGF0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgLy8gVW5hYmxlIHRvIHNlbmQgZm9ybSB1bmxlc3MgZmllbGRzIGFyZSB2YWxpZC5cclxuICAgIGlmIChkaXJ0eSkge1xyXG4gICAgICBzZXREaXNhYmxlZCghdmFsaWRhdGUoZW1haWwpKVxyXG4gICAgfVxyXG4gIH0sIFtlbWFpbCwgZGlydHldKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaGFuZGxlVmFsaWRhdGlvbigpXHJcbiAgfSwgW2hhbmRsZVZhbGlkYXRpb25dKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm1cclxuICAgICAgb25TdWJtaXQ9e2hhbmRsZVJlc2V0UGFzc3dvcmR9XHJcbiAgICAgIGNsYXNzTmFtZT1cInctODAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcC0zXCJcclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHBiLTEyIFwiPlxyXG4gICAgICAgIDxMb2dvIHdpZHRoPVwiNjRweFwiIGhlaWdodD1cIjY0cHhcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIHttZXNzYWdlICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQgYm9yZGVyIGJvcmRlci1yZWQgcC0zXCI+e21lc3NhZ2V9PC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiRW1haWxcIiBvbkNoYW5nZT17c2V0RW1haWx9IHR5cGU9XCJlbWFpbFwiIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIHctZnVsbCBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzbGltXCJcclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtkaXNhYmxlZH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVjb3ZlciBQYXNzd29yZFxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB0LTMgdGV4dC1jZW50ZXIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnQtN1wiPkRvIHlvdSBoYXZlIGFuIGFjY291bnQ/PC9zcGFuPlxyXG4gICAgICAgICAge2AgYH1cclxuICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYWNjZW50LTkgZm9udC1ib2xkIGhvdmVyOnVuZGVybGluZSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsVmlldygnTE9HSU5fVklFVycpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBMb2cgSW5cclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9mb3JtPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9yZ290UGFzc3dvcmRcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==