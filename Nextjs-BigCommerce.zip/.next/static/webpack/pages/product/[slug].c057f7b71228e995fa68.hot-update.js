self["webpackHotUpdate_N_E"]("pages/product/[slug]",{

/***/ "./components/partials/product/media/media-one.jsx":
/*!*********************************************************!*\
  !*** ./components/partials/product/media/media-one.jsx ***!
  \*********************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ MediaOne; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-image-magnifiers */ "./node_modules/react-image-magnifiers/dist/index.js");
/* harmony import */ var _components_features_custom_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/features/custom-link */ "./components/features/custom-link.jsx");
/* harmony import */ var _components_features_owl_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/features/owl-carousel */ "./components/features/owl-carousel.jsx");
/* harmony import */ var _components_partials_product_thumb_thumb_one__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @components/partials/product/thumb/thumb-one */ "./components/partials/product/thumb/thumb-one.jsx");
/* harmony import */ var _components_partials_product_thumb_thumb_two__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @components/partials/product/thumb/thumb-two */ "./components/partials/product/thumb/thumb-two.jsx");
/* harmony import */ var _components_partials_product_light_box__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @components/partials/product/light-box */ "./components/partials/product/light-box.jsx");
/* harmony import */ var _utils_data_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @utils/data/carousel */ "./utils/data/carousel.js");
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\RAGIN\\AT\\Nextjs-BigCommerce\\components\\partials\\product\\media\\media-one.jsx",
    _s = $RefreshSig$();









function MediaOne(props) {
  _s();

  var _this = this;

  var product = props.product;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
      index = _useState[0],
      setIndex = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      isOpen = _useState2[0],
      setOpenState = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('null'),
      mediaRef = _useState3[0],
      setMediaRef = _useState3[1];

  var lgImages = product.large_pictures ? product.large_pictures : product.pictures;
  console.log(product);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    setIndex(0);
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    if (mediaRef !== 'null' && mediaRef.current !== 'null' && index >= 0) {
      mediaRef.current.$car.to(index, 300, true);
    }
  }, [index]);

  var setIndexHandler = function setIndexHandler(mediaIndex) {
    if (mediaIndex !== index) {
      setIndex(mediaIndex);
    }
  };

  var changeRefHandler = function changeRefHandler(carRef) {
    if (carRef.current !== undefined) {
      setMediaRef(carRef);
    }
  };

  var changeOpenState = function changeOpenState(openState) {
    setOpenState(openState);
  };

  var openLightBox = function openLightBox() {
    setOpenState(true);
  };

  var events = {
    onTranslate: function onTranslate(e) {
      if (!e.target) return;

      if (document.querySelector('.product-thumbs')) {
        document.querySelector('.product-thumbs').querySelector('.product-thumb.active').classList.remove('active');
        document.querySelector('.product-thumbs').querySelectorAll('.product-thumb')[e.item.index].classList.add('active');
      }
    }
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "product-gallery pg-vertical media-default",
      style: {
        top: "88px"
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "product-label-group",
        children: [product.stock === 0 ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("label", {
          className: "product-label label-out",
          children: "out"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 29
        }, this) : "", product.is_top ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("label", {
          className: "product-label label-top",
          children: "top"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 29
        }, this) : "", product.is_new ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("label", {
          className: "product-label label-new",
          children: "new"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 29
        }, this) : "", product.discount ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("label", {
          className: "product-label label-sale",
          children: "sale"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 29
        }, this) : ""]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_features_owl_carousel__WEBPACK_IMPORTED_MODULE_3__.default, {
        adClass: "product-single-carousel owl-theme owl-nav-inner",
        options: _utils_data_carousel__WEBPACK_IMPORTED_MODULE_4__.mainSlider3,
        onChangeIndex: setIndexHandler,
        onChangeRef: changeRefHandler,
        events: events,
        children: lgImages.map(function (image, index) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_image_magnifiers__WEBPACK_IMPORTED_MODULE_2__.Magnifier, {
              imageSrc: images.url,
              imageAlt: "magnifier",
              largeImageSrc: images.url,
              dragToMove: false,
              mouseActivation: "hover",
              cursorStyleActive: "crosshair",
              className: "product-image large-image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 95,
              columnNumber: 33
            }, _this)
          }, image + '-' + index, false, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 29
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_features_custom_link__WEBPACK_IMPORTED_MODULE_5__.default, {
        href: "#",
        className: "product-image-full",
        onClick: openLightBox,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
          className: "d-icon-zoom"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 89
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_partials_product_thumb_thumb_one__WEBPACK_IMPORTED_MODULE_6__.default, {
        product: product,
        index: index,
        onChangeIndex: setIndexHandler
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 110,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_partials_product_thumb_thumb_two__WEBPACK_IMPORTED_MODULE_7__.default, {
        product: product,
        index: index,
        onChangeIndex: setIndexHandler
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_partials_product_light_box__WEBPACK_IMPORTED_MODULE_8__.default, {
      images: lgImages,
      isOpen: isOpen,
      changeOpenState: changeOpenState,
      index: index,
      product: product
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 114,
      columnNumber: 13
    }, this)]
  }, void 0, true);
}

_s(MediaOne, "qCG8sOHr5HP3U+R7OQo2JGpCuVk=");

_c = MediaOne;

var _c;

$RefreshReg$(_c, "MediaOne");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9wYXJ0aWFscy9wcm9kdWN0L21lZGlhL21lZGlhLW9uZS5qc3giXSwibmFtZXMiOlsiTWVkaWFPbmUiLCJwcm9wcyIsInByb2R1Y3QiLCJ1c2VTdGF0ZSIsImluZGV4Iiwic2V0SW5kZXgiLCJpc09wZW4iLCJzZXRPcGVuU3RhdGUiLCJtZWRpYVJlZiIsInNldE1lZGlhUmVmIiwibGdJbWFnZXMiLCJsYXJnZV9waWN0dXJlcyIsInBpY3R1cmVzIiwiY29uc29sZSIsImxvZyIsInVzZUVmZmVjdCIsImN1cnJlbnQiLCIkY2FyIiwidG8iLCJzZXRJbmRleEhhbmRsZXIiLCJtZWRpYUluZGV4IiwiY2hhbmdlUmVmSGFuZGxlciIsImNhclJlZiIsInVuZGVmaW5lZCIsImNoYW5nZU9wZW5TdGF0ZSIsIm9wZW5TdGF0ZSIsIm9wZW5MaWdodEJveCIsImV2ZW50cyIsIm9uVHJhbnNsYXRlIiwiZSIsInRhcmdldCIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsImNsYXNzTGlzdCIsInJlbW92ZSIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJpdGVtIiwiYWRkIiwidG9wIiwic3RvY2siLCJpc190b3AiLCJpc19uZXciLCJkaXNjb3VudCIsIm1haW5TbGlkZXIzIiwibWFwIiwiaW1hZ2UiLCJpbWFnZXMiLCJ1cmwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBRWUsU0FBU0EsUUFBVCxDQUFtQkMsS0FBbkIsRUFBMkI7QUFBQTs7QUFBQTs7QUFBQSxNQUM5QkMsT0FEOEIsR0FDbEJELEtBRGtCLENBQzlCQyxPQUQ4Qjs7QUFBQSxrQkFFVkMsK0NBQVEsQ0FBRSxDQUFGLENBRkU7QUFBQSxNQUU5QkMsS0FGOEI7QUFBQSxNQUV2QkMsUUFGdUI7O0FBQUEsbUJBR0xGLCtDQUFRLENBQUUsS0FBRixDQUhIO0FBQUEsTUFHOUJHLE1BSDhCO0FBQUEsTUFHdEJDLFlBSHNCOztBQUFBLG1CQUlKSiwrQ0FBUSxDQUFFLE1BQUYsQ0FKSjtBQUFBLE1BSTlCSyxRQUo4QjtBQUFBLE1BSXBCQyxXQUpvQjs7QUFNdEMsTUFBSUMsUUFBUSxHQUFHUixPQUFPLENBQUNTLGNBQVIsR0FBeUJULE9BQU8sQ0FBQ1MsY0FBakMsR0FBa0RULE9BQU8sQ0FBQ1UsUUFBekU7QUFDSkMsU0FBTyxDQUFDQyxHQUFSLENBQVlaLE9BQVo7QUFDSWEsa0RBQVMsQ0FBRSxZQUFNO0FBQ2JWLFlBQVEsQ0FBRSxDQUFGLENBQVI7QUFDSCxHQUZRLEVBRU4sRUFGTSxDQUFUO0FBSUFVLGtEQUFTLENBQUUsWUFBTTtBQUNiLFFBQUtQLFFBQVEsS0FBSyxNQUFiLElBQXVCQSxRQUFRLENBQUNRLE9BQVQsS0FBcUIsTUFBNUMsSUFBc0RaLEtBQUssSUFBSSxDQUFwRSxFQUF3RTtBQUNwRUksY0FBUSxDQUFDUSxPQUFULENBQWlCQyxJQUFqQixDQUFzQkMsRUFBdEIsQ0FBMEJkLEtBQTFCLEVBQWlDLEdBQWpDLEVBQXNDLElBQXRDO0FBQ0g7QUFDSixHQUpRLEVBSU4sQ0FBRUEsS0FBRixDQUpNLENBQVQ7O0FBTUEsTUFBTWUsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFFQyxVQUFGLEVBQWtCO0FBQ3RDLFFBQUtBLFVBQVUsS0FBS2hCLEtBQXBCLEVBQTRCO0FBQ3hCQyxjQUFRLENBQUVlLFVBQUYsQ0FBUjtBQUNIO0FBQ0osR0FKRDs7QUFNQSxNQUFNQyxnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUVDLE1BQUYsRUFBYztBQUNuQyxRQUFLQSxNQUFNLENBQUNOLE9BQVAsS0FBbUJPLFNBQXhCLEVBQW9DO0FBQ2hDZCxpQkFBVyxDQUFFYSxNQUFGLENBQVg7QUFDSDtBQUNKLEdBSkQ7O0FBTUEsTUFBTUUsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFBQyxTQUFTLEVBQUk7QUFDakNsQixnQkFBWSxDQUFFa0IsU0FBRixDQUFaO0FBQ0gsR0FGRDs7QUFJQSxNQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFNO0FBQ3ZCbkIsZ0JBQVksQ0FBRSxJQUFGLENBQVo7QUFDSCxHQUZEOztBQUlBLE1BQUlvQixNQUFNLEdBQUc7QUFDVEMsZUFBVyxFQUFFLHFCQUFXQyxDQUFYLEVBQWU7QUFDeEIsVUFBSyxDQUFDQSxDQUFDLENBQUNDLE1BQVIsRUFBaUI7O0FBQ2pCLFVBQUtDLFFBQVEsQ0FBQ0MsYUFBVCxDQUF3QixpQkFBeEIsQ0FBTCxFQUFtRDtBQUMvQ0QsZ0JBQVEsQ0FBQ0MsYUFBVCxDQUF3QixpQkFBeEIsRUFBNENBLGFBQTVDLENBQTJELHVCQUEzRCxFQUFxRkMsU0FBckYsQ0FBK0ZDLE1BQS9GLENBQXVHLFFBQXZHO0FBQ0FILGdCQUFRLENBQUNDLGFBQVQsQ0FBd0IsaUJBQXhCLEVBQTRDRyxnQkFBNUMsQ0FBOEQsZ0JBQTlELEVBQWtGTixDQUFDLENBQUNPLElBQUYsQ0FBT2hDLEtBQXpGLEVBQWlHNkIsU0FBakcsQ0FBMkdJLEdBQTNHLENBQWdILFFBQWhIO0FBQ0g7QUFDSjtBQVBRLEdBQWI7QUFVQSxzQkFDSTtBQUFBLDRCQUNJO0FBQUssZUFBUyxFQUFDLDJDQUFmO0FBQTJELFdBQUssRUFBRztBQUFFQyxXQUFHLEVBQUU7QUFBUCxPQUFuRTtBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyxxQkFBZjtBQUFBLG1CQUVRcEMsT0FBTyxDQUFDcUMsS0FBUixLQUFrQixDQUFsQixnQkFDSTtBQUFPLG1CQUFTLEVBQUMseUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLEdBQzZELEVBSHJFLEVBT1FyQyxPQUFPLENBQUNzQyxNQUFSLGdCQUNJO0FBQU8sbUJBQVMsRUFBQyx5QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosR0FDNkQsRUFSckUsRUFZUXRDLE9BQU8sQ0FBQ3VDLE1BQVIsZ0JBQ0k7QUFBTyxtQkFBUyxFQUFDLHlCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixHQUM2RCxFQWJyRSxFQWlCUXZDLE9BQU8sQ0FBQ3dDLFFBQVIsZ0JBQ0k7QUFBTyxtQkFBUyxFQUFDLDBCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixHQUMrRCxFQWxCdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUF1QkksOERBQUMsc0VBQUQ7QUFBYSxlQUFPLEVBQUMsaURBQXJCO0FBQ0ksZUFBTyxFQUFHQyw2REFEZDtBQUVJLHFCQUFhLEVBQUd4QixlQUZwQjtBQUdJLG1CQUFXLEVBQUdFLGdCQUhsQjtBQUlJLGNBQU0sRUFBR00sTUFKYjtBQUFBLGtCQU9RakIsUUFBUSxDQUFDa0MsR0FBVCxDQUFjLFVBQUVDLEtBQUYsRUFBU3pDLEtBQVQ7QUFBQSw4QkFDVjtBQUFBLG1DQUNJLDhEQUFDLDZEQUFEO0FBQ0ksc0JBQVEsRUFBRTBDLE1BQU0sQ0FBQ0MsR0FEckI7QUFFSSxzQkFBUSxFQUFDLFdBRmI7QUFHSSwyQkFBYSxFQUFFRCxNQUFNLENBQUNDLEdBSDFCO0FBSUksd0JBQVUsRUFBRyxLQUpqQjtBQUtJLDZCQUFlLEVBQUMsT0FMcEI7QUFNSSwrQkFBaUIsRUFBQyxXQU50QjtBQU9JLHVCQUFTLEVBQUM7QUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosYUFBV0YsS0FBSyxHQUFHLEdBQVIsR0FBY3pDLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRFU7QUFBQSxTQUFkO0FBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXZCSixlQTZDSSw4REFBQyxxRUFBRDtBQUFPLFlBQUksRUFBQyxHQUFaO0FBQWdCLGlCQUFTLEVBQUMsb0JBQTFCO0FBQStDLGVBQU8sRUFBR3NCLFlBQXpEO0FBQUEsK0JBQXdFO0FBQUcsbUJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTdDSixlQStDSSw4REFBQyxpRkFBRDtBQUFVLGVBQU8sRUFBR3hCLE9BQXBCO0FBQThCLGFBQUssRUFBR0UsS0FBdEM7QUFBOEMscUJBQWEsRUFBR2U7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQS9DSixlQWdESSw4REFBQyxpRkFBRDtBQUFVLGVBQU8sRUFBR2pCLE9BQXBCO0FBQThCLGFBQUssRUFBR0UsS0FBdEM7QUFBOEMscUJBQWEsRUFBR2U7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESixlQW9ESSw4REFBQywyRUFBRDtBQUFlLFlBQU0sRUFBR1QsUUFBeEI7QUFBbUMsWUFBTSxFQUFHSixNQUE1QztBQUFxRCxxQkFBZSxFQUFHa0IsZUFBdkU7QUFBeUYsV0FBSyxFQUFHcEIsS0FBakc7QUFBeUcsYUFBTyxFQUFHRjtBQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcERKO0FBQUEsa0JBREo7QUF3REg7O0dBeEd1QkYsUTs7S0FBQUEsUSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9wcm9kdWN0L1tzbHVnXS5jMDU3ZjdiNzEyMjhlOTk1ZmE2OC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTWFnbmlmaWVyIH0gZnJvbSAncmVhY3QtaW1hZ2UtbWFnbmlmaWVycyc7XHJcblxyXG5pbXBvcnQgQUxpbmsgZnJvbSAnQGNvbXBvbmVudHMvZmVhdHVyZXMvY3VzdG9tLWxpbmsnO1xyXG5pbXBvcnQgT3dsQ2Fyb3VzZWwgZnJvbSAnQGNvbXBvbmVudHMvZmVhdHVyZXMvb3dsLWNhcm91c2VsJztcclxuXHJcbmltcG9ydCBUaHVtYk9uZSBmcm9tICdAY29tcG9uZW50cy9wYXJ0aWFscy9wcm9kdWN0L3RodW1iL3RodW1iLW9uZSc7XHJcbmltcG9ydCBUaHVtYlR3byBmcm9tICdAY29tcG9uZW50cy9wYXJ0aWFscy9wcm9kdWN0L3RodW1iL3RodW1iLXR3byc7XHJcbmltcG9ydCBNZWRpYUxpZ2h0Qm94IGZyb20gJ0Bjb21wb25lbnRzL3BhcnRpYWxzL3Byb2R1Y3QvbGlnaHQtYm94JztcclxuXHJcbmltcG9ydCB7IG1haW5TbGlkZXIzIH0gZnJvbSAnQHV0aWxzL2RhdGEvY2Fyb3VzZWwnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWVkaWFPbmUoIHByb3BzICkge1xyXG4gICAgY29uc3QgeyBwcm9kdWN0IH0gPSBwcm9wcztcclxuICAgIGNvbnN0IFsgaW5kZXgsIHNldEluZGV4IF0gPSB1c2VTdGF0ZSggMCApO1xyXG4gICAgY29uc3QgWyBpc09wZW4sIHNldE9wZW5TdGF0ZSBdID0gdXNlU3RhdGUoIGZhbHNlICk7XHJcbiAgICBjb25zdCBbIG1lZGlhUmVmLCBzZXRNZWRpYVJlZiBdID0gdXNlU3RhdGUoICdudWxsJyApO1xyXG5cclxuICAgIGxldCBsZ0ltYWdlcyA9IHByb2R1Y3QubGFyZ2VfcGljdHVyZXMgPyBwcm9kdWN0LmxhcmdlX3BpY3R1cmVzIDogcHJvZHVjdC5waWN0dXJlcztcclxuY29uc29sZS5sb2cocHJvZHVjdCk7XHJcbiAgICB1c2VFZmZlY3QoICgpID0+IHtcclxuICAgICAgICBzZXRJbmRleCggMCApO1xyXG4gICAgfSwgWyAgXSApXHJcblxyXG4gICAgdXNlRWZmZWN0KCAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCBtZWRpYVJlZiAhPT0gJ251bGwnICYmIG1lZGlhUmVmLmN1cnJlbnQgIT09ICdudWxsJyAmJiBpbmRleCA+PSAwICkge1xyXG4gICAgICAgICAgICBtZWRpYVJlZi5jdXJyZW50LiRjYXIudG8oIGluZGV4LCAzMDAsIHRydWUgKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbIGluZGV4IF0gKVxyXG5cclxuICAgIGNvbnN0IHNldEluZGV4SGFuZGxlciA9ICggbWVkaWFJbmRleCApID0+IHtcclxuICAgICAgICBpZiAoIG1lZGlhSW5kZXggIT09IGluZGV4ICkge1xyXG4gICAgICAgICAgICBzZXRJbmRleCggbWVkaWFJbmRleCApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBjaGFuZ2VSZWZIYW5kbGVyID0gKCBjYXJSZWYgKSA9PiB7XHJcbiAgICAgICAgaWYgKCBjYXJSZWYuY3VycmVudCAhPT0gdW5kZWZpbmVkICkge1xyXG4gICAgICAgICAgICBzZXRNZWRpYVJlZiggY2FyUmVmICk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGNoYW5nZU9wZW5TdGF0ZSA9IG9wZW5TdGF0ZSA9PiB7XHJcbiAgICAgICAgc2V0T3BlblN0YXRlKCBvcGVuU3RhdGUgKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBvcGVuTGlnaHRCb3ggPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0T3BlblN0YXRlKCB0cnVlICk7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGV2ZW50cyA9IHtcclxuICAgICAgICBvblRyYW5zbGF0ZTogZnVuY3Rpb24gKCBlICkge1xyXG4gICAgICAgICAgICBpZiAoICFlLnRhcmdldCApIHJldHVybjtcclxuICAgICAgICAgICAgaWYgKCBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLnByb2R1Y3QtdGh1bWJzJyApICkge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJy5wcm9kdWN0LXRodW1icycgKS5xdWVyeVNlbGVjdG9yKCAnLnByb2R1Y3QtdGh1bWIuYWN0aXZlJyApLmNsYXNzTGlzdC5yZW1vdmUoICdhY3RpdmUnICk7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCAnLnByb2R1Y3QtdGh1bWJzJyApLnF1ZXJ5U2VsZWN0b3JBbGwoICcucHJvZHVjdC10aHVtYicgKVsgZS5pdGVtLmluZGV4IF0uY2xhc3NMaXN0LmFkZCggJ2FjdGl2ZScgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1nYWxsZXJ5IHBnLXZlcnRpY2FsIG1lZGlhLWRlZmF1bHRcIiBzdHlsZT17IHsgdG9wOiBcIjg4cHhcIiB9IH0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtbGFiZWwtZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3Quc3RvY2sgPT09IDAgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInByb2R1Y3QtbGFiZWwgbGFiZWwtb3V0XCI+b3V0PC9sYWJlbD4gOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2R1Y3QuaXNfdG9wID9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJwcm9kdWN0LWxhYmVsIGxhYmVsLXRvcFwiPnRvcDwvbGFiZWw+IDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0LmlzX25ldyA/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZHVjdC1sYWJlbCBsYWJlbC1uZXdcIj5uZXc8L2xhYmVsPiA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdC5kaXNjb3VudCA/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHJvZHVjdC1sYWJlbCBsYWJlbC1zYWxlXCI+c2FsZTwvbGFiZWw+IDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxPd2xDYXJvdXNlbCBhZENsYXNzPVwicHJvZHVjdC1zaW5nbGUtY2Fyb3VzZWwgb3dsLXRoZW1lIG93bC1uYXYtaW5uZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9eyBtYWluU2xpZGVyMyB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2VJbmRleD17IHNldEluZGV4SGFuZGxlciB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2VSZWY9eyBjaGFuZ2VSZWZIYW5kbGVyIH1cclxuICAgICAgICAgICAgICAgICAgICBldmVudHM9eyBldmVudHMgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGdJbWFnZXMubWFwKCAoIGltYWdlLCBpbmRleCApID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17IGltYWdlICsgJy0nICsgaW5kZXggfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFnbmlmaWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlU3JjPXtpbWFnZXMudXJsIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VBbHQ9XCJtYWduaWZpZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXJnZUltYWdlU3JjPXtpbWFnZXMudXJsIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZHJhZ1RvTW92ZT17IGZhbHNlIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW91c2VBY3RpdmF0aW9uPVwiaG92ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3JTdHlsZUFjdGl2ZT1cImNyb3NzaGFpclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2R1Y3QtaW1hZ2UgbGFyZ2UtaW1hZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSB9XHJcbiAgICAgICAgICAgICAgICA8L093bENhcm91c2VsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxBTGluayBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInByb2R1Y3QtaW1hZ2UtZnVsbFwiIG9uQ2xpY2s9eyBvcGVuTGlnaHRCb3ggfT48aSBjbGFzc05hbWU9XCJkLWljb24tem9vbVwiPjwvaT48L0FMaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgIDxUaHVtYk9uZSBwcm9kdWN0PXsgcHJvZHVjdCB9IGluZGV4PXsgaW5kZXggfSBvbkNoYW5nZUluZGV4PXsgc2V0SW5kZXhIYW5kbGVyIH0gLz5cclxuICAgICAgICAgICAgICAgIDxUaHVtYlR3byBwcm9kdWN0PXsgcHJvZHVjdCB9IGluZGV4PXsgaW5kZXggfSBvbkNoYW5nZUluZGV4PXsgc2V0SW5kZXhIYW5kbGVyIH0gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8TWVkaWFMaWdodEJveCBpbWFnZXM9eyBsZ0ltYWdlcyB9IGlzT3Blbj17IGlzT3BlbiB9IGNoYW5nZU9wZW5TdGF0ZT17IGNoYW5nZU9wZW5TdGF0ZSB9IGluZGV4PXsgaW5kZXggfSBwcm9kdWN0PXsgcHJvZHVjdCB9IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn0iXSwic291cmNlUm9vdCI6IiJ9