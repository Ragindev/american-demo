import customerApi from '@framework/api/endpoints/customer'
import commerce from '@lib/api/commerce'

export default customerApi(commerce)
