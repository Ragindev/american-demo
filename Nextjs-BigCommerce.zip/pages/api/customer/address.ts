import customerAddressApi from '@framework/api/endpoints/customer/address'
import commerce from '@lib/api/commerce'

export default customerAddressApi(commerce)
