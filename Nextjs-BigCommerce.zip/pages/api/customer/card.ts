import customerCardApi from '@framework/api/endpoints/customer/card'
import commerce from '@lib/api/commerce'

export default customerCardApi(commerce)
