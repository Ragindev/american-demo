import checkoutApi from '@framework/api/endpoints/checkout'
import commerce from '@lib/api/commerce'

export default checkoutApi(commerce)
