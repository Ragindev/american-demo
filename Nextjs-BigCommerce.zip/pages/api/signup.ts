import singupApi from '@framework/api/endpoints/signup'
import commerce from '@lib/api/commerce'

export default singupApi(commerce)
