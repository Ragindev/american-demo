import loginApi from '@framework/api/endpoints/login'
import commerce from '@lib/api/commerce'

export default loginApi(commerce)
