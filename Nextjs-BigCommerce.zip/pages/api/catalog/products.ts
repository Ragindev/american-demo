import productsApi from '@framework/api/endpoints/catalog/products'
import commerce from '@lib/api/commerce'

export default productsApi(commerce)
