import cartApi from '@framework/api/endpoints/cart'
import commerce from '@lib/api/commerce'

export default cartApi(commerce)
